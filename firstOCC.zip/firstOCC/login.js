		$(document).ready(function(){          
            //login javascript
            $("#un").focusin(function(){
              $("#un").css("border","1px solid blue");
              $("#un").animate({width:"295px"},"slow");
            });
            $("#un").focusout(function(){
              $("#un").css("border","1px solid #0e8c7a");
              $("#un").animate({width:"200px"},"slow");
            });
            $("#pw").focusin(function(){
              $("#pw").css("border","1px solid blue");
              $("#pw").animate({width:"295px"},"slow");
            });
            $("#pw").focusout(function(){
              $("#pw").css("border","1px solid #0e8c7a");
              $("#pw").animate({width:"200px"},"slow");
            });
          });