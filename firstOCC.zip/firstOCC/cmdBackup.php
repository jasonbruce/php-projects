<?php 

	$tday  = date("Ymdhisu");
	$bfile = '/var/www/html/dbBackUps/tblUsers' . $tday . '.backup';
	$tbl = 'tblUsers';
	$query = "SELECT * INTO OUTFILE '$bfile' FROM $tbl";
	$result = mysql_query($query) or die(mysql_error());
	echo '<div class="assistHeaderDiv"><label class="titleLink">' . $tbl .' has been backed up to ' . $bfile . '!</label></div>';


?>