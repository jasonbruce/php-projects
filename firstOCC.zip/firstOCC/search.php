<?php

 include 'header.php';
 include 'modules.php';
 
 if ($_SESSION['loggedin'] == "true"){
  	 	include 'navimenu.php';
 		
  		$search = $_GET['search'];
 		searchBar($search);
 		userInfo();
 		floatComments();
 		if ($search ==''){
 			showInformation('Search Error', 'Please enter a search criteria');
 		}else{
 			searchForIt($search);
 		}
 }else{
	$action = $_POST['action'];
 	login($action, 'index.php');
 }
 


?>
