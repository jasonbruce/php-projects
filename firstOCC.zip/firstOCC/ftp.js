$(document).ready(function(){	
			$("input").focusin(function() {
				 $(this).css("border-color", "blue");
			}); 
			$("input").focusout(function() { 
				 $(this).css("border-color", "black");	
			}); 
			$("textarea").focusin(function() { 
				 $(this).css("border-color", "blue");
			}); 
			$("textarea").focusout(function() { 
				 $(this).css("border-color", "black");
			});
			$("#ddSingMulti").change(function(){
					var e = document.getElementById("ddSingMulti"); 
					var strValue = e.options[e.selectedIndex].text;
					if (strValue=="Multi"){
						$("#lblLS_FILENAME").fadeOut(1000);
						$("#txtLS_FILENAME").fadeOut(1000);
						$("#multiDiv").fadeIn(1000);						
					}else{
						$("#lblLS_FILENAME").fadeIn(1000);
						$("#txtLS_FILENAME").fadeIn(1000);
						$("#multiDiv").fadeOut(1000);
						
					}
            });		
			$("#helpBtn").click(function(){
				$("#helpSection").slideToggle("fast");
            });
			$("#RS_PROTOCOL").change(function(){
					var e = document.getElementById("RS_PROTOCOL"); 
					var strValue = e.options[e.selectedIndex].text;
					if (strValue=="SMB"){
						$("#smbRDiv").fadeIn(1000);
					}else{
						$("#smbRDiv").fadeOut(1000);
					}
            });
			$("#LS_PROTOCOL").change(function(){
					var e = document.getElementById("LS_PROTOCOL"); 
					var strValue = e.options[e.selectedIndex].text;
					if (strValue=="SMB"){
						$("#smbLDiv").fadeIn(1000);
					}else{
						$("#smbLDiv").fadeOut(1000);
					}
            });
			$("#lstHour").change(function(){
					var e = document.getElementById("lstMinute"); 
					var lstMin = e.options[e.selectedIndex].text;
					var e = document.getElementById("lstHour"); 
					var lstHour = e.options[e.selectedIndex].text;
					var e = document.getElementById("lstDayOfMonth"); 
					var lstDayMonth = e.options[e.selectedIndex].text;
					var e = document.getElementById("lstDayOfWeek"); 
					var lstDayWeek = e.options[e.selectedIndex].text;
					
					switch(lstMin)
					{
						case 'Every Minute':
							lstMin = "*";
						break;
					}
					switch(lstHour)
					{
						case 'Every Hour':
							lstHour = "*";
						break;
					}
					switch(lstDayMonth)
					{
						case 'Every Day':
							lstDayMonth = "*";
						break;
					}
					switch(lstDayWeek)
					{
						case 'Every Day':
							lstDayWeek = "*";
						break;
						case 'Sunday':
							lstDayWeek = "0";
						break;
						case 'Monday':
							lstDayWeek = "1";
						break;
						case 'Tuesday':
							lstDayWeek = "2";
						break;
						case 'Wednesday':
							lstDayWeek = "3";
						break;
						case 'Thursday':
							lstDayWeek = "4";
						break;
						case 'Friday':
							lstDayWeek = "5";
						break;
						case 'Saturday':
							lstDayWeek = "6";
						break;
						case 'Mon-Fri':
							lstDayWeek = "1,2,3,4,5";
						break;
					}									
					var tbox = document.getElementById('cronTabData');
                	if (tbox)
                	{
						tbox.value = lstMin + " " + lstHour + " " + lstDayMonth + " * " + lstDayWeek;
                	}
            });
			$("#lstMinute").change(function(){
					var e = document.getElementById("lstMinute"); 
					var lstMin = e.options[e.selectedIndex].text;
					var e = document.getElementById("lstHour"); 
					var lstHour = e.options[e.selectedIndex].text;
					var e = document.getElementById("lstDayOfMonth"); 
					var lstDayMonth = e.options[e.selectedIndex].text;
					var e = document.getElementById("lstDayOfWeek"); 
					var lstDayWeek = e.options[e.selectedIndex].text;
					
					switch(lstMin)
					{
						case 'Every Minute':
							lstMin = "*";
						break;
					}
					switch(lstHour)
					{
						case 'Every Hour':
							lstHour = "*";
						break;
					}
					switch(lstDayMonth)
					{
						case 'Every Day':
							lstDayMonth = "*";
						break;
					}
					switch(lstDayWeek)
					{
						case 'Every Day':
							lstDayWeek = "*";
						break;
						case 'Sunday':
							lstDayWeek = "0";
						break;
						case 'Monday':
							lstDayWeek = "1";
						break;
						case 'Tuesday':
							lstDayWeek = "2";
						break;
						case 'Wednesday':
							lstDayWeek = "3";
						break;
						case 'Thursday':
							lstDayWeek = "4";
						break;
						case 'Friday':
							lstDayWeek = "5";
						break;
						case 'Saturday':
							lstDayWeek = "6";
						break;
						case 'Mon-Fri':
							lstDayWeek = "1,2,3,4,5";
						break;
					}									
					var tbox = document.getElementById('cronTabData');
                	if (tbox)
                	{
						tbox.value = lstMin + " " + lstHour + " " + lstDayMonth + " * " + lstDayWeek;
                	}
            });
			$("#lstDayOfMonth").change(function(){
					var e = document.getElementById("lstMinute"); 
					var lstMin = e.options[e.selectedIndex].text;
					var e = document.getElementById("lstHour"); 
					var lstHour = e.options[e.selectedIndex].text;
					var e = document.getElementById("lstDayOfMonth"); 
					var lstDayMonth = e.options[e.selectedIndex].text;
					var e = document.getElementById("lstDayOfWeek"); 
					var lstDayWeek = e.options[e.selectedIndex].text;
					
					switch(lstMin)
					{
						case 'Every Minute':
							lstMin = "*";
						break;
					}
					switch(lstHour)
					{
						case 'Every Hour':
							lstHour = "*";
						break;
					}
					switch(lstDayMonth)
					{
						case 'Every Day':
							lstDayMonth = "*";
						break;
					}
					switch(lstDayWeek)
					{
						case 'Every Day':
							lstDayWeek = "*";
						break;
						case 'Sunday':
							lstDayWeek = "0";
						break;
						case 'Monday':
							lstDayWeek = "1";
						break;
						case 'Tuesday':
							lstDayWeek = "2";
						break;
						case 'Wednesday':
							lstDayWeek = "3";
						break;
						case 'Thursday':
							lstDayWeek = "4";
						break;
						case 'Friday':
							lstDayWeek = "5";
						break;
						case 'Saturday':
							lstDayWeek = "6";
						break;
						case 'Mon-Fri':
							lstDayWeek = "1,2,3,4,5";
						break;
					}									
					var tbox = document.getElementById('cronTabData');
                	if (tbox)
                	{
						tbox.value = lstMin + " " + lstHour + " " + lstDayMonth + " * " + lstDayWeek;
                	}
            });
			$("#lstDayOfWeek").change(function(){
					var e = document.getElementById("lstMinute"); 
					var lstMin = e.options[e.selectedIndex].text;
					var e = document.getElementById("lstHour"); 
					var lstHour = e.options[e.selectedIndex].text;
					var e = document.getElementById("lstDayOfMonth"); 
					var lstDayMonth = e.options[e.selectedIndex].text;
					var e = document.getElementById("lstDayOfWeek"); 
					var lstDayWeek = e.options[e.selectedIndex].text;
					
					switch(lstMin)
					{
						case 'Every Minute':
							lstMin = "*";
						break;
					}
					switch(lstHour)
					{
						case 'Every Hour':
							lstHour = "*";
						break;
					}
					switch(lstDayMonth)
					{
						case 'Every Day':
							lstDayMonth = "*";
						break;
					}
					switch(lstDayWeek)
					{
						case 'Every Day':
							lstDayWeek = "*";
						break;
						case 'Sunday':
							lstDayWeek = "0";
						break;
						case 'Monday':
							lstDayWeek = "1";
						break;
						case 'Tuesday':
							lstDayWeek = "2";
						break;
						case 'Wednesday':
							lstDayWeek = "3";
						break;
						case 'Thursday':
							lstDayWeek = "4";
						break;
						case 'Friday':
							lstDayWeek = "5";
						break;
						case 'Saturday':
							lstDayWeek = "6";
						break;
						case 'Mon-Fri':
							lstDayWeek = "1,2,3,4,5";
						break;
					}									
					var tbox = document.getElementById('cronTabData');
                	if (tbox)
                	{
						tbox.value = lstMin + " " + lstHour + " " + lstDayMonth + " * " + lstDayWeek;
                	}
            });
			$("#ddInternExtern").change(function(){
					var e = document.getElementById("ddInternExtern"); 
					var lstVal = e.options[e.selectedIndex].text;
					
					switch(lstVal)
					{
						case 'Internal':
							$("#remoteDiv").fadeOut(1000);
							$("#txtLS_REMOTE_FOLDER").fadeIn(1000);
							$("#lblLS_REMOTE_FOLDER").fadeIn(1000);
						break;
						case 'External':
							$("#remoteDiv").fadeIn(1000);
							$("#txtLS_REMOTE_FOLDER").fadeOut(1000);
							$("#lblLS_REMOTE_FOLDER").fadeOut(1000);
						break;
					}
					
            });
			
		
			$("#txtSYS_FTPNAME").focusout(function() {		
				if ($("#txtSYS_FTPNAME").val() == ""){
					$("#errorSYS_FTPNAME").fadeIn(1000);
					$("#txtSYS_FTPNAME").css("border-color","red");
					$("#txtSYS_FTPNAME").css("background-color","pink");
				}else{
					$("#errorSYS_FTPNAME").fadeOut(500);
					$("#txtSYS_FTPNAME").css("border-color","black");
					$("#txtSYS_FTPNAME").css("background-color","white");
				}
			});
			
			$("#txtarrFile1").focusout(function() {		
				if ($("#txtarrFile1").val() == ""){
					$("#errorarrFile1").fadeIn(1000);
					$("#txtarrFile1").css("border-color","red");
					$("#txtarrFile1").css("background-color","pink");
				}else{
					$("#errorarrFile1").fadeOut(500);
					$("#txtarrFile1").css("border-color","black");
					$("#txtarrFile1").css("background-color","white");
				}
			});
			$("#txtarrFile2").focusout(function() {		
				if ($("#txtarrFile2").val() == ""){
					$("#errorarrFile2").fadeIn(1000);
					$("#txtarrFile2").css("border-color","red");
					$("#txtarrFile2").css("background-color","pink");
				}else{
					$("#errorarrFile2").fadeOut(500);
					$("#txtarrFile2").css("border-color","black");
					$("#txtarrFile2").css("background-color","white");
				}
			});
			
			
			
			
			
			$("#txtLS_EMAIL").focusout(function() {		
				if ($("#txtLS_EMAIL").val() == ""){
					$("#errorLS_EMAIL").fadeIn(1000);
					$("#txtLS_EMAIL").css("border-color","red");
					$("#txtLS_EMAIL").css("background-color","pink");
				}else{				
					$("#errorLS_EMAIL").fadeOut(500);
					$("#txtLS_EMAIL").css("border-color","black");
					$("#txtLS_EMAIL").css("background-color","white");
				}
			});
			$("#txtLS_FILENAME").focusout(function() {		
				if ($("#txtLS_FILENAME").val() == ""){
					$("#errorLS_FILENAME").fadeIn(1000);
					$("#txtLS_FILENAME").css("border-color","red");
					$("#txtLS_FILENAME").css("background-color","pink");
				}else{
					$("#errorLS_FILENAME").fadeOut(500);
					$("#txtLS_FILENAME").css("border-color","black");
					$("#txtLS_FILENAME").css("background-color","white");
				}
			});
			$("#LS_LABEL").focusout(function() {		
				if ($("#LS_LABEL").val() == ""){
					$("#errorLS_LABEL").fadeIn(1000);
					$("#LS_LABEL").css("border-color","red");
					$("#LS_LABEL").css("background-color","pink");
				}else{
					$("#errorLS_LABEL").fadeOut(500);
					$("#LS_LABEL").css("border-color","black");
					$("#LS_LABEL").css("background-color","white");
				}
			});
			$("#txtLS_HOST").focusout(function() {		
				if ($("#txtLS_HOST").val() == ""){
					$("#errorLS_HOST").fadeIn(1000);
					$("#txtLS_HOST").css("border-color","red");
					$("#txtLS_HOST").css("background-color","pink");
				}else{
					$("#errorLS_HOST").fadeOut(500);
					$("#txtLS_HOST").css("border-color","black");
					$("#txtLS_HOST").css("background-color","white");
				}
			});
			$("#txtLS_LOGIN").focusout(function() {		
				if ($("#txtLS_LOGIN").val() == ""){
					$("#errorLS_LOGIN").fadeIn(1000);
					$("#txtLS_LOGIN").css("border-color","red");
					$("#txtLS_LOGIN").css("background-color","pink");
				}else{
					$("#errorLS_LOGIN").fadeOut(500);
					$("#txtLS_LOGIN").css("border-color","black");
					$("#txtLS_LOGIN").css("background-color","white");
				}
			});
			$("#txtLS_PWD").focusout(function() {		
				if ($("#txtLS_PWD").val() == ""){
					$("#errorLS_PWD").fadeIn(1000);
					$("#txtLS_PWD").css("border-color","red");
					$("#txtLS_PWD").css("background-color","pink");
				}else{
					$("#errorLS_PWD").fadeOut(500);
					$("#txtLS_PWD").css("border-color","black");
					$("#txtLS_PWD").css("background-color","white");
				}
			});
			$("#txtLS_NET_FOLDER").focusout(function() {		
				if ($("#txtLS_NET_FOLDER").val() == ""){
					$("#errorLS_NET_FOLDER").fadeIn(1000);
					$("#txtLS_NET_FOLDER").css("border-color","red");
					$("#txtLS_NET_FOLDER").css("background-color","pink");
				}else{
					$("#errorLS_NET_FOLDER").fadeOut(500);
					$("#txtLS_NET_FOLDER").css("border-color","black");
					$("#txtLS_NET_FOLDER").css("background-color","white");
				}
			});
			$("#txtRS_LOGIN").focusout(function() {		
				if ($("#txtRS_LOGIN").val() == ""){
					$("#errorRS_LOGIN").fadeIn(1000);
					$("#txtRS_LOGIN").css("border-color","red");
					$("#txtRS_LOGIN").css("background-color","pink");
				}else{
					$("#errorRS_LOGIN").fadeOut(500);
					$("#txtRS_LOGIN").css("border-color","black");
					$("#txtRS_LOGIN").css("background-color","white");
				}
			});
			$("#txtRS_PWD").focusout(function() {		
				if ($("#txtRS_PWD").val() == ""){
					$("#errorRS_PWD").fadeIn(1000);
					$("#txtRS_PWD").css("border-color","red");
					$("#txtRS_PWD").css("background-color","pink");
				}else{
					$("#errorRS_PWD").fadeOut(500);
					$("#txtRS_PWD").css("border-color","black");
					$("#txtRS_PWD").css("background-color","white");
				}
			});
			$("#txtRS_REMOTE_FOLDER").focusout(function() {		
				if ($("#txtRS_REMOTE_FOLDER").val() == ""){
					$("#errorRS_REMOTE_FOLDER").fadeIn(1000);
					$("#txtRS_REMOTE_FOLDER").css("border-color","red");
					$("#txtRS_REMOTE_FOLDER").css("background-color","pink");
				}else{
					$("#errorRS_REMOTE_FOLDER").fadeOut(500);
					$("#txtRS_REMOTE_FOLDER").css("border-color","black");
					$("#txtRS_REMOTE_FOLDER").css("background-color","white");
				}
			});
			$("#txtRS_").focusout(function() {		
				if ($("#txtRS_").val() == ""){
					$("#errorRS_").fadeIn(1000);
					$("#txtRS_").css("border-color","red");
					$("#txtRS_").css("background-color","pink");
				}else{
					$("#errorRS_").fadeOut(500);
					$("#txtRS_").css("border-color","black");
					$("#txtRS_").css("background-color","white");
				}
			});
			$("#txtRS_EMAIL").focusout(function() {		
				if ($("#txtRS_EMAIL").val() == ""){
					$("#errorRS_EMAIL").fadeIn(1000);
					$("#txtRS_EMAIL").css("border-color","red");
					$("#txtRS_EMAIL").css("background-color","pink");
				}else{
					$("#errorRS_EMAIL").fadeOut(500);
					$("#txtRS_EMAIL").css("border-color","black");
					$("#txtRS_EMAIL").css("background-color","white");
				}
			});
			$("#txtRS_HOST").focusout(function() {		
				if ($("#txtRS_HOST").val() == ""){
					$("#errorRS_HOST").fadeIn(1000);
					$("#txtRS_HOST").css("border-color","red");
					$("#txtRS_HOST").css("background-color","pink");
				}else{
					$("#errorRS_HOST").fadeOut(500);
					$("#txtRS_HOST").css("border-color","black");
					$("#txtRS_HOST").css("background-color","white");
				}
			});
			$("#txtRS_NET_FOLDER").focusout(function() {		
				if ($("#txtRS_NET_FOLDER").val() == ""){
					$("#errorRS_NET_FOLDER").fadeIn(1000);
					$("#txtRS_NET_FOLDER").css("border-color","red");
					$("#txtRS_NET_FOLDER").css("background-color","pink");
				}else{
					$("#errorRS_NET_FOLDER").fadeOut(500);
					$("#txtRS_NET_FOLDER").css("border-color","black");
					$("#txtRS_NET_FOLDER").css("background-color","white");
				}
			});
			$("#txtRS_PGPKEY").focusout(function() {		
				if ($("#txtRS_PGPKEY").val() == ""){
					$("#errorRS_PGPKEY").fadeIn(1000);
					$("#txtRS_PGPKEY").css("border-color","red");
					$("#txtRS_PGPKEY").css("background-color","pink");
				}else{
					$("#errorRS_PGPKEY").fadeOut(500);
					$("#txtRS_PGPKEY").css("border-color","black");
					$("#txtRS_PGPKEY").css("background-color","white");
				}
			});
			$("#txtRS_PORT").focusout(function() {		
				if ($("#txtRS_PORT").val() == ""){
					$("#errorRS_PORT").fadeIn(1000);
					$("#txtRS_PORT").css("border-color","red");
					$("#txtRS_PORT").css("background-color","pink");
				}else{
					$("#errorRS_PORT").fadeOut(500);
					$("#txtRS_PORT").css("border-color","black");
					$("#txtRS_PORT").css("background-color","white");
				}
			});
			$("#txtRS_REMOTE_FOLDER").focusout(function() {		
				if ($("#txtRS_REMOTE_FOLDER").val() == ""){
					$("#errorRS_REMOTE_FOLDER").fadeIn(1000);
					$("#txtRS_REMOTE_FOLDER").css("border-color","red");
					$("#txtRS_REMOTE_FOLDER").css("background-color","pink");
				}else{
					$("#errorRS_REMOTE_FOLDER").fadeOut(500);
					$("#txtRS_REMOTE_FOLDER").css("border-color","black");
					$("#txtRS_REMOTE_FOLDER").css("background-color","white");
				}
			});
		
		});