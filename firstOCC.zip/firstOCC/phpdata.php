<?php

	phpinfo();


?>
