<?php
 include 'header.php';
 include 'modules.php';
 
  if ($_SESSION['loggedin'] == "true"){
  	 	include 'navimenu.php';
 		searchBar('');
		userInfo();
		floatComments();
		$updateID = $_GET['updateComment'];
		if ($updateID <> ''){deactivateComment($updateID);}
  		$addNew = $_GET['addComment'];
  		$txtToAdd = mysql_real_escape_string ($_GET['txtComments']);
  		$un = $_SESSION['un'];
		if ($addNew == 'new'){insertComment($txtToAdd, $un);}
		tasks();
		$action = $_GET['action'];
		$uid = $_SESSION['uID'];
		if ($action == "changePW"){changePW($uid, 'index.php');}
		$newPW = $_GET['newPW'];
  		if ($action == "newPWSubmitted"){updatePW($uid, $newPW);}
  		
 }else{
	$action = $_POST['action'];
 	login($action, 'index.php');
 }
 
 
 

 
 

 
 
 
?>
