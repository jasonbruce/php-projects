<?php
	include 'headTag.php';


	//variable list: $SYS_FTPNAME,$LS_ARRAY_FILE,$LS_EMAIL,$LS_FILENAME,$LS_HOST,$LS_LABEL,$LS_LOGIN,$LS_NET_FOLDER,$LS_PORT,$LS_PROTOCOL,$LS_PWD,$LS_REMOTE_FOLDER,$LS_SMB_FOLDER,$LS_SMB_HOST,$LS_SMB_SHARE,$RS_EMAIL,$RS_LOGIN,$RS_HOST,$RS_NET_FOLDER,$RS_PGPKEY,$RS_PORT,$RS_PROTOCOL,$RS_PWD,$RS_REMOTE_FOLDER,$RS_SMB_FOLDER,$RS_SMB_HOST,$RS_SMB_SHARE,$RS_SMB_USER,$RS_SMB_PASS
	$singMulti = $_GET['ddSingMulti'];
	$SYS_FTPNAME=$_GET['SYS_FTPNAME'];
	$LS_ARRAY_FILE='';
	$LS_EMAIL=$_GET['LS_EMAIL'];
	$LS_FILENAME=$_GET['LS_FILENAME'];
	$LS_HOST=$_GET['LS_HOST'];
	$LS_LABEL=$_GET['LS_LABEL'];
	$LS_LOGIN=$_GET['LS_LOGIN'];
	$LS_NET_FOLDER=$_GET['LS_NET_FOLDER'];
	$LS_PORT=$_GET['LS_PORT'];
	$LS_PROTOCOL=$_GET['LS_PROTOCOL'];
	$LS_PWD=$_GET['LS_PWD'];
	$LS_REMOTE_FOLDER=$_GET['LS_REMOTE_FOLDER'];
	$LS_SMB_FOLDER=$_GET['LS_SMB_FOLDER'];
	$LS_SMB_HOST=$_GET['LS_SMB_HOST'];
	$LS_SMB_SHARE=$_GET['LS_SMB_SHARE'];
	$RS_EMAIL=$_GET['RS_EMAIL'];
	$RS_LOGIN=$_GET['RS_LOGIN'];
	$RS_HOST=$_GET['RS_HOST'];
	$RS_NET_FOLDER=$_GET['RS_NET_FOLDER'];
	$RS_PGPKEY=$_GET['RS_PGPKEY'];
	$RS_PORT=$_GET['RS_PORT'];
	$RS_PROTOCOL=$_GET['RS_PROTOCOL'];
	$RS_PWD=$_GET['RS_PWD'];
	$RS_REMOTE_FOLDER=$_GET['RS_REMOTE_FOLDER'];
	$RS_SMB_FOLDER=$_GET['RS_SMB_FOLDER'];
	$RS_SMB_HOST=$_GET['RS_SMB_HOST'];
	$RS_SMB_SHARE=$_GET['RS_SMB_SHARE'];
	$RS_SMB_USER=$_GET['RS_SMB_USER'];
	$RS_SMB_PASS=$_GET['RS_SMB_PASS'];
	$formName      = $_GET['formName'];
	$action		   = $_GET['action'];
	$department    = $_GET['ddDepartment'];
	$cronTab	   = $_GET['cronTabData'];
	$arrayFile[0]  = $_GET['arrFile1'];
	$arrayFile[1]  = $_GET['arrFile2'];
	$arrayFile[2]  = $_GET['arrFile3'];
	$arrayFile[3]  = $_GET['arrFile4'];
	$arrayFile[4]  = $_GET['arrFile5'];
	$arrayFile[5]  = $_GET['arrFile6'];
	$arrayFile[6]  = $_GET['arrFile7'];
	$arrayFile[7]  = $_GET['arrFile8'];
	$arrayFile[8]  = $_GET['arrFile9'];
	$arrayFile[9 ] = $_GET['arrFile10'];	
	
//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------	
		switch ($formName){
		
			case "form1":
				$err = validateFields($SYS_FTPNAME,$LS_ARRAY_FILE,$LS_EMAIL,$LS_FILENAME,$LS_HOST,$LS_LABEL,$LS_LOGIN,$LS_NET_FOLDER,$LS_PORT,$LS_PROTOCOL,$LS_PWD,$LS_REMOTE_FOLDER,$LS_SMB_FOLDER,$LS_SMB_HOST,$LS_SMB_SHARE,$RS_EMAIL,$RS_LOGIN,$RS_HOST,$RS_NET_FOLDER,$RS_PGPKEY,$RS_PORT,$RS_PROTOCOL,$RS_PWD,$RS_REMOTE_FOLDER,$RS_SMB_FOLDER,$RS_SMB_HOST,$RS_SMB_SHARE,$RS_SMB_USER,$RS_SMB_PASS);
				if ($err=="0"){
					displaySchedule();
				}else{
					displayError($err);
					displayFtpForm($SYS_FTPNAME,$LS_ARRAY_FILE,$LS_EMAIL,$LS_FILENAME,$LS_HOST,$LS_LABEL,$LS_LOGIN,$LS_NET_FOLDER,$LS_PORT,$LS_PROTOCOL,$LS_PWD,$LS_REMOTE_FOLDER,$LS_SMB_FOLDER,$LS_SMB_HOST,$LS_SMB_SHARE,$RS_EMAIL,$RS_LOGIN,$RS_HOST,$RS_NET_FOLDER,$RS_PGPKEY,$RS_PORT,$RS_PROTOCOL,$RS_PWD,$RS_REMOTE_FOLDER,$RS_SMB_FOLDER,$RS_SMB_HOST,$RS_SMB_SHARE,$RS_SMB_USER,$RS_SMB_PASS);							
				}
				break;		
			case "cronTab":
				$LS_ARRAY_FILE = checkArrayFile($singMulti);
				if ($LS_ARRAY_FILE == 'array_files.ini'){
					buildArrayFile($arrayFile, $SYS_FTPNAME, $department);
				}
				buildIniFile($SYS_FTPNAME,$LS_ARRAY_FILE,$LS_EMAIL,$LS_FILENAME,$LS_HOST,$LS_LABEL,$LS_LOGIN,$LS_NET_FOLDER,$LS_PORT,$LS_PROTOCOL,$LS_PWD,$LS_REMOTE_FOLDER,$LS_SMB_FOLDER,$LS_SMB_HOST,$LS_SMB_SHARE,$RS_EMAIL,$RS_LOGIN,$RS_HOST,$RS_NET_FOLDER,$RS_PGPKEY,$RS_PORT,$RS_PROTOCOL,$RS_PWD,$RS_REMOTE_FOLDER,$RS_SMB_FOLDER,$RS_SMB_HOST,$RS_SMB_SHARE,$RS_SMB_USER,$RS_SMB_PASS, $department, $singMulti);					
				buildCronTab($cronTab,$SYS_FTPNAME,$department);
				break;
			default:
				displayFtpForm($SYS_FTPNAME,$LS_ARRAY_FILE,$LS_EMAIL,$LS_FILENAME,$LS_HOST,$LS_LABEL,$LS_LOGIN,$LS_NET_FOLDER,$LS_PORT,$LS_PROTOCOL,$LS_PWD,$LS_REMOTE_FOLDER,$LS_SMB_FOLDER,$LS_SMB_HOST,$LS_SMB_SHARE,$RS_EMAIL,$RS_LOGIN,$RS_HOST,$RS_NET_FOLDER,$RS_PGPKEY,$RS_PORT,$RS_PROTOCOL,$RS_PWD,$RS_REMOTE_FOLDER,$RS_SMB_FOLDER,$RS_SMB_HOST,$RS_SMB_SHARE,$RS_SMB_USER,$RS_SMB_PASS);							
		}
//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------		
	function buildArrayFile($arrayFile, $SYS_FTPNAME, $department){
		if ($department == 'FIN'){
			$ftpName = "pi.$SYS_FTPNAME";
		}else{
			$ftpName = "pa.$SYS_FTPNAME";
		}
		$path = "/home/devdata/.testSite/";
		$folderName = $path . $ftpName;
		$fileName = "$folderName/array_files.ini";
		
		$file = fopen($fileName,"w");
				$stringToWrite .= $arrayFile[0];				
				$stringToWrite .= "\r\n";
				$stringToWrite .= $arrayFile[1];				
				$stringToWrite .= "\r\n";
				$stringToWrite .= $arrayFile[2];				
				$stringToWrite .= "\r\n";
				$stringToWrite .= $arrayFile[3];				
				$stringToWrite .= "\r\n";
				$stringToWrite .= $arrayFile[4];				
				$stringToWrite .= "\r\n";
				$stringToWrite .= $arrayFile[5];				
				$stringToWrite .= "\r\n";
				$stringToWrite .= $arrayFile[6];				
				$stringToWrite .= "\r\n";
				$stringToWrite .= $arrayFile[7];				
				$stringToWrite .= "\r\n";
				$stringToWrite .= $arrayFile[8];				
				$stringToWrite .= "\r\n";
				$stringToWrite .= $arrayFile[9];				
				$stringToWrite .= "\r\n";
				$stringToWrite .= $arrayFile[10];				
				$stringToWrite .= "\r\n";
		fwrite($file, $stringToWrite);
		fclose($file);	
	}	
	function checkArrayFile($singMulti){	
		if ($singMulti == 'Multi'){
			return "array_files.ini";
		}
	}
	function buildCronTab($data,$SYS_FTPNAME,$department){
		if ($department == 'FIN'){
			$ftpName = "pi.$SYS_FTPNAME";
		}else{
			$ftpName = "pa.$SYS_FTPNAME";
		}
		
		$path = "/home/devdata/.testSite/";
		$folderName = $path . $ftpName;
		$fileName = "$folderName/$ftpName.cron";
		echo "Cron Tab File Created: <b>$fileName</b><br>";
		$file = fopen($fileName,"w");
		fwrite($file, $data);
		fclose($file);
		
	}
	function displaySchedule(){
			echo '<div id="cronTabDiv" class="conTabDiv"><table>';
				echo '<tr><td><label class=frmLabel>Minute</label></td><td><label class=frmLabel>Hour</label></td><td><label class=frmLabel>Day of Month</label></td><td><label class=frmLabel>Day of Week</label></td></tr>';
				echo '<tr>';
				showListBox("", 			   	"lstMinute",					"Every Minute,5,10,15,20,25,30,35,40,45,50,55");
				showListBox("", 			   	"lstHour",						"Every Hour,0,1,2,3,4,5,6,7,8,9,10,12,13,14,15,16,17,18,19,20,21,22,23");
				showListBox("", 		"lstDayOfMonth",				"Every Day,1,2,3,4,5,6,7,8,9,10,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31");
				showListBox("", 			"lstDayOfWeek",					"Every Day,Mon-Fri,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday");
				echo '</tr>';
				//showTextBox('Scheduled Task Data:', 'cronTabData',					'* * * * *');
				insertHiddenValue('cronTabData','* * * * *');
				insertHiddenValue('formName','cronTab');
				insertHiddenValue('action','submitted');
			echo '</table></div>';	
	}
	function displayError($errTxt){
		echo '<div class="errorDiv">';
			echo $errTxt;
		echo '</div>';
	}										
	function validateFields($SYS_FTPNAME,$LS_ARRAY_FILE,$LS_EMAIL,$LS_FILENAME,$LS_HOST,$LS_LABEL,$LS_LOGIN,$LS_NET_FOLDER,$LS_PORT,$LS_PROTOCOL,$LS_PWD,$LS_REMOTE_FOLDER,$LS_SMB_FOLDER,$LS_SMB_HOST,$LS_SMB_SHARE,$RS_EMAIL,$RS_LOGIN,$RS_HOST,$RS_NET_FOLDER,$RS_PGPKEY,$RS_PORT,$RS_PROTOCOL,$RS_PWD,$RS_REMOTE_FOLDER,$RS_SMB_FOLDER,$RS_SMB_HOST,$RS_SMB_SHARE,$RS_SMB_USER,$RS_SMB_PASS){
		return '0';
	}										
	function displayMultiForm(){
		echo '<div id="multiDiv" class="multiDiv" id="multiDiv">';
		echo "<form method=get action=testftp.php>";
		  echo "<table>";
			showTextBox('File 1',						'arrFile1',				$arrFile1);
				errorDiv("FTP NAME", "Can not be blank, No special characters (!@#$%^&)", "errorarrFile1");
			showTextBox('File 2',						'arrFile2',				$arrFile2);
				errorDiv("FTP NAME", "Can not be blank, No special characters (!@#$%^&)", "errorarrFile2");
			showTextBox('File 3',						'arrFile3',				$arrFile3);
				errorDiv("FTP NAME", "No special characters (!@#$%^&)", "errorarrFile3");
			showTextBox('File 4',						'arrFile4',				$arrFile4);
				errorDiv("FTP NAME", "No special characters (!@#$%^&)", "errorarrFile4");
			showTextBox('File 5',						'arrFile5',				$arrFile5);
				errorDiv("FTP NAME", "No special characters (!@#$%^&)", "errorarrFile5");
			showTextBox('File 6',						'arrFile6',				$arrFile6);
				errorDiv("FTP NAME", "No special characters (!@#$%^&)", "errorarrFile6");
			showTextBox('File 7',						'arrFile7',				$arrFile7);
				errorDiv("FTP NAME", "No special characters (!@#$%^&)", "errorarrFile7");
			showTextBox('File 8',						'arrFile8',				$arrFile8);
				errorDiv("FTP NAME", "No special characters (!@#$%^&)", "errorarrFile8");
			showTextBox('File 9',						'arrFile9',				$arrFile9);
				errorDiv("FTP NAME", "No special characters (!@#$%^&)", "errorarrFile9");
			showTextBox('File 10',					'arrFile10',			$arrFile10);
				errorDiv("FTP NAME", "No special characters (!@#$%^&)", "errorarrFile10");
		  echo "</table>";	
		echo "</div>";
		  
	}	
	function displayLocalSMB(){
		echo '<div id="smbLDiv" class="smbLDiv">';
		  echo "<table>";
					showTextBox('SMB Folder',					'LS_SMB_FOLDER',			$LS_SMB_FOLDER);
					showTextBox('SMB Host',						'LS_SMB_HOST',				$LS_SMB_HOST);
					showTextBox('SMB Share',					'LS_SMB_SHARE',				$LS_SMB_SHARE);				
		  echo "</table>";	
		echo "</div>";
	}
	function displayRemoteSMB(){
		echo '<div id="smbRDiv" class="smbRDiv">';
		  echo "<table>";				
					showTextBox('SMB Folder',					'RS_SMB_FOLDER',			$RS_SMB_FOLDER);
					showTextBox('SMB Host',						'RS_SMB_HOST',				$RS_SMB_HOST);
					showTextBox('SMB Share',					'RS_SMB_SHARE',				$RS_SMB_SHARE);
					showTextBox('SMB User',						'RS_SMB_USER',				$RS_SMB_USER);
					showTextBox('SMB Pass',						'RS_SMB_PASS',				$RS_SMB_PASS);
		  echo "</table>";	
		echo "</div>";
	}
	function displayFtpForm($SYS_FTPNAME,$LS_ARRAY_FILE,$LS_EMAIL,$LS_FILENAME,$LS_HOST,$LS_LABEL,$LS_LOGIN,$LS_NET_FOLDER,$LS_PORT,$LS_PROTOCOL,$LS_PWD,$LS_REMOTE_FOLDER,$LS_SMB_FOLDER,$LS_SMB_HOST,$LS_SMB_SHARE,$RS_EMAIL,$RS_LOGIN,$RS_HOST,$RS_NET_FOLDER,$RS_PGPKEY,$RS_PORT,$RS_PROTOCOL,$RS_PWD,$RS_REMOTE_FOLDER,$RS_SMB_FOLDER,$RS_SMB_HOST,$RS_SMB_SHARE,$RS_SMB_USER,$RS_SMB_PASS){
		$helpComments = getHelp();
		
		echo "<form method=get action=testftp.php id=ftpForm>";
		  echo "<table class=ftpFrmTable>";
					
					echo '<tr><td></td><td></td><td rowspan=40 align=left><div id="helpBtn" class="helpBtn"><img src="img/showhide.png"></div></td><td rowspan=40><div id="helpSection" class="helpSection">' . $helpComments . '</div></td></tr>';
					showDropDown("Internal/External", 			   	'ddInternExtern',					"Internal,External");
					showDropDown("Orignal Source System", 			"ddDepartment",				"CLN,FIN");
					showTextBox('Ftp Name',				'SYS_FTPNAME',				$SYS_FTPNAME);
						errorDiv("FTP NAME", "Can not be blank, No special characters (!@#$%^&) or Numbers!", "errorSYS_FTPNAME");
					showDropDown("Single/Multi", 		"ddSingMulti",				"Single,Multi");
						echo '<tr><td colspan="2">';
							displayMultiForm();
						echo '</td><td></td><td></td></tr>';
					showTextBox('Email',				'LS_EMAIL',					$LS_EMAIL);
						errorDiv("EMAIL", "Can not be blank, must match typical email standards XXXX@XXXX.XXX", "errorLS_EMAIL");
					showTextBox('File Name',			'LS_FILENAME',				$LS_FILENAME);
						errorDiv("FILE NAME", "(ONLY APPLICABLE IF SINGLE FILE FTP) Can not be blank, No special characters.", "errorLS_FILENAME");
					showTextBox('Host',					'LS_HOST',					$LS_HOST);
						errorDiv("HOSTNAME", "Can not be blank, No special characters.", "errorLS_HOST");
					showTextArea('Email Body',			'LS_LABEL',					$LS_LABEL);
						errorDiv("Email Body", "Can not be blank.", "errorLS_LABEL");
					showTextBox('LS Username',	'LS_LOGIN',					$LS_LOGIN);
						errorDiv("LOCALHOST USERNAME", "Can not be blank, No special characters.", "errorLS_LOGIN");
					showTextBox('LS Password',	'LS_PWD',					$LS_PWD);
						errorDiv("LOCALHOST PASSWORD", "Can not be blank.", "errorLS_PWD");							
					showTextBox('LS Start Folder',				'LS_NET_FOLDER',			$LS_NET_FOLDER);
						errorDiv("FOLDER", "Can not be blank, No special characters.", "errorLS_NET_FOLDER");
					
					showTextBox('LS End Folder',				'LS_REMOTE_FOLDER',			$LS_REMOTE_FOLDER);
						errorDiv("FOLDER", "Can not be blank, No special characters.", "errorLS_REMOTE_FOLDER");	
					showDropDown("LS Port", 			   	'LS_PORT',					"21,22");
					showDropDown("LS Protocol", 			'LS_PROTOCOL',				"FTP,SFTP,SMB");
						echo '<tr><td colspan="2">';
							displayLocalSMB();
						echo '</td></tr>';
						
						displayRemoteSystem($RS_LOGIN,$RS_PWD,$RS_REMOTE_FOLDER,$RS_EMAIL,$RS_HOST,$RS_NET_FOLDER,$RS_PGPKEY);
					insertHiddenValue('formName','form1');
					insertHiddenValue('action','submitted');
					echo '<tr><td colspan=2>';
							displaySchedule();
					echo '</td></tr>';
					showSubmit();
					
		  echo "</table>";	
		echo "</form>";		
	}
	function errorDiv($title, $description, $id){
		echo '<tr>';
			echo '<td colspan=2>';
				echo '<div id='.$id.' name='.$id.' class=errorDiv><b><u><center>'.$title.'</u></b><br>'.$description.'</center></div>';
			echo '</td>';
		echo '</tr>';
	}
	
	
	function displayRemoteSystem($RS_LOGIN,$RS_PWD,$RS_REMOTE_FOLDER,$RS_EMAIL,$RS_HOST,$RS_NET_FOLDER,$RS_PGPKEY){
				echo '<tr><td colspan=2><div class=remoteSystemDiv id=remoteDiv><table>';
					showTextBox('RS Login',				'RS_LOGIN',					$RS_LOGIN);
						errorDiv("Remote Login", "Can not be blank.", "errorRS_LOGIN");				
					showTextBox('Password',				'RS_PWD',					$RS_PWD);
						errorDiv("Password", "Can not be blank.", "errorRS_PWD");
					showTextBox('Remote Folder',		'RS_REMOTE_FOLDER',			$RS_REMOTE_FOLDER);
						errorDiv("Remote Folder", "Can not be blank.", "errorRS_REMOTE_FOLDER");
					showTextBox('RS Email',				'RS_EMAIL',					$RS_EMAIL);
						errorDiv("Remote Email", "Can not be blank, must match typical email standards XXXX@XXXX.XXX", "errorRS_EMAIL");
					showTextBox('RS Host',				'RS_HOST',					$RS_HOST);
						errorDiv("Remote Host", "Can not be blank.", "errorRS_HOST");
					showTextBox('Net Folder',			'RS_NET_FOLDER',			$RS_NET_FOLDER);
						errorDiv("Remote Net Folder", "Can not be blank.", "errorRS_NET_FOLDER");
					showTextBox('PGP Key',				'RS_PGPKEY',				$RS_PGPKEY);
						errorDiv("PGP", "Can not be blank.", "errorRS_PGPKEY");
					showTextBox('RS Port',				'RS_PORT',					$RS_PORT);
						errorDiv("Remote System Port", "Can only be numbers.  Can not be blank.", "errorRS_PORT");
					showDropDown("RS Protocol", 		'RS_PROTOCOL',				"FTP,SFTP,SMB");
						echo '<tr><td colspan="2">';
							displayRemoteSMB();
						echo '</td></tr></table></div></td></tr>';
	}
	function insertHiddenValue($strName, $strVal){
		echo '<input type=hidden name='.$strName.' value='.$strVal.'>';
	}
	function showTextBox($lblText, $elementName, $elementValue){
		echo "<tr>";
			echo '<td class=labelTD><label class=frmLabel id="lbl'.$elementName.'">'.$lblText.'</label></td>';
			echo '<td class=fieldTD><input type="text" name="' . $elementName . '" value="' . $elementValue . '" class=frmText id=txt'.$elementName.'></td>';
		echo "</tr>";
	}
	function showTextArea($lblText, $elementName, $elementValue){
		echo "<tr>";
			echo '<td class=labelTD><label class=frmLabel id=lbl'.$elementName.'>'.$lblText.'</label></td>';
			echo '<td class=fieldTD><textarea name="' . $elementName . '" class=frmTextArea rows=4 cols=30 id='.$elementName.'>' . $elementValue . '</textarea></td>';
		echo "</tr>";
	}
	function showDropDown($lblText, $elementName, $values){
		$dropDownArray = "";
		
		echo "<tr>";
			echo '<td class=labelTD><label class=frmLabel id=lbl'.$elementName.'>'.$lblText.'</label></td>';
			echo "<td class=fieldTD>";
					echo '<select id="'. $elementName .'" name="' . $elementName . '" class=frmSelect>';
						$dropDownArray = split(",", $values);
						foreach ($dropDownArray as $ddVal){
							echo "<option>$ddVal</option>";
						}
					echo "</select>";
			echo "</td>";
		echo "</tr>";
	
	}
	function showListBox($lblText, $elementName, $values){
		$dropDownArray = "";		
		
			echo "<td class=fieldTD>";
					echo '<select id="'. $elementName .'" name="' . $elementName . '" size="13" class="lstBox">';
						$dropDownArray = split(",", $values);
						foreach ($dropDownArray as $ddVal){
							if (substr($ddVal,0,4) == "Ever"){
								echo "<option selected=selected>$ddVal</option>";
							}else{
								echo "<option>$ddVal</option>";
							}
						}
					echo "</select>";
			echo "</td>";
	
	}
	function showSubmit(){
		echo "<tr>";
			echo '<td class=labelTD></td><td><input type="submit" value="Enter Data"></td>';
		echo '</tr>';
	}
	function buildIniFile($SYS_FTPNAME,$LS_ARRAY_FILE,$LS_EMAIL,$LS_FILENAME,$LS_HOST,$LS_LABEL,$LS_LOGIN,$LS_NET_FOLDER,$LS_PORT,$LS_PROTOCOL,$LS_PWD,$LS_REMOTE_FOLDER,$LS_SMB_FOLDER,$LS_SMB_HOST,$LS_SMB_SHARE,$RS_EMAIL,$RS_LOGIN,$RS_HOST,$RS_NET_FOLDER,$RS_PGPKEY,$RS_PORT,$RS_PROTOCOL,$RS_PWD,$RS_REMOTE_FOLDER,$RS_SMB_FOLDER,$RS_SMB_HOST,$RS_SMB_SHARE,$RS_SMB_USER,$RS_SMB_PASS, $department, $singMulti){
		
		if ($department == 'FIN'){
			$ftpName = "pi.$SYS_FTPNAME";
		}else{
			$ftpName = "pa.$SYS_FTPNAME";
		}
		if ($singMulti == "Single"){
			$LS_ARRAY_FILE = $LS_FILENAME;
		}
		$path = "/home/devdata/.testSite/";
		$folderName = $path . $ftpName;
		echo "INI File Created: <b>$folderName</b><br>";
		
		mkdir($folderName, 0777);
		$fileName = "$folderName/$ftpName.ini";
		$file = fopen($fileName,"w");
		
		$stringToWrite='#!/bin/ksh';
		$stringToWrite .= "\r\n";
		$stringToWrite = $stringToWrite . '#Description: !LIVE! pi.advisory.board !LIVE!' .chr(27);
		$stringToWrite .= "\r\n";
		$stringToWrite = $stringToWrite . '#Standard System Settings';
		$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'SYS_FTPNAME='.$SYS_FTPNAME.'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'SYS_DATE=$(date +" %b %d ")';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'SYS_DATE_BAK=$(date +""%m%d")';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'SYS_FTP_HOST=$(hostname)';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'SYS_FTPDIR=${SYS_IDATA}/${SYS_FTPNAME}';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'SYS_SFTP_GET=${SYS_IFACE}/bin/sftp.get';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'SYS_SFTP_PUT=${SYS_IFACE}/bin/sftp.put';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'SYS_SMB_DOMAIN=firsthealth';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'SYS_SMB_CLIENT=/usr/bin/smbclient';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'SYS_SMB_USER=devdata';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'SYS_SMB_PASS=D3vDa7a99y';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'SYS_PGP_CMD=/usr/bin/gpg';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'SYS_LOG_DIR=/nfs/shared/logs/${SYS_FTPNAME}';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'SYS_LOG_FILE=${SYS_LOG_DIR}/${SYS_FTPNAME}-${SYS_FTP_HOST}.$(date +%m%d").log"';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'SYS_FTP_LOG=${SYS_LOG_DIR}/${SYS_FTPNAME}-${SYS_FTP_HOST}.$(date +%m%d")-ftp.log"';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'SYS_FTP_LOGTMP=${SYS_IDATA}/${SYS_FTPNAME}/tmp/${SYS_FTPNAME}.$$.log';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'SYS_CRON=${SYS_IFACE}/${SYS_FTPNAME}/${SYS_FTPNAME}.hourly.cron';
			$stringToWrite .= "\r\n";
			$stringToWrite .= "\r\n";
		$stringToWrite = $stringToWrite . '#Local Settings';
		$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_ARRAY_FILE=' . $LS_ARRAY_FILE .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_EMAIL=' . $LS_EMAIL .''; 
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_FILENAME=' . $LS_FILENAME .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_HOST=' . $LS_HOST .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_LABEL=' . $LS_LABEL .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_LOGIN=' . $LS_LOGIN .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_MTIME=14';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_NET_FOLDER=' . $LS_NET_FOLDER .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_OVERWRITE=TRUE';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_PORT=' . $LS_PORT .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_PROTOCOL=' . $LS_PROTOCOL .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_PWD=' . $LS_PWD .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_REMOTE_FOLDER=' . $LS_REMOTE_FOLDER .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_SMB_FOLDER=' . $LS_SMB_FOLDER .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_SMB_HOST=' . $LS_SMB_HOST .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_SMB_SHARE=' . $LS_SMB_SHARE .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_SMB_USER=devdata';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_SMB_PASS=D3vDa7a99y';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'LS_STRIP=';
			$stringToWrite .= "\r\n";
			$stringToWrite .= "\r\n";
		$stringToWrite = $stringToWrite . '#Remote Settings';
		$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'RS_EMAIL=' . $RS_EMAIL .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'RS_LOGIN=' . $RS_LOGIN .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'RS_HOST=' . $RS_HOST .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'RS_NET_FOLDER=' . $RS_NET_FOLDER .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'RS_PGPKEY=' . $RS_PGPKEY .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'RS_PORT=' . $RS_PORT .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'RS_PROTOCOL=' . $RS_PROTOCOL .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'RS_PWD=' . $RS_PWD .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'RS_REMOTE_FOLDER=' . $RS_REMOTE_FOLDER .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'RS_SMB_FOLDER=' . $RS_SMB_FOLDER .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'RS_SMB_HOST=' . $RS_SMB_HOST .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'RS_SMB_SHARE=' . $RS_SMB_SHARE .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'RS_SMB_USER=' . $RS_SMB_USER .'';
			$stringToWrite .= "\r\n";
			$stringToWrite = $stringToWrite . 'RS_SMB_PASS=' . $RS_SMB_PASS .'';
			$stringToWrite .= "\r\n";
		
		fwrite($file, $stringToWrite);
		fclose($file);
	}
	function getHelp(){
		$help = "";
		$help = "<ul class=help>
					<b><u>Form Help</u></b>
					<li><b><u>Department:</b></u> 			Defining clinicals or finacials<br>
					<li><b><u>FTP Name Field:</b></u> 		This is the name you are giving to the ftp, this will also be what the folders/files are named for the ftp scripts that run. <b><i>Validation Rules:</b></i> No special characters and no numbers.<br>
					<li><b><u>Single/Multi</b></u>			This field is for if you are doing a single file or multiple file FTP<br>
					<li><b><u>Multiple File FTP</b></u>		If you select Multiple  File FTP then you must provide more than one file name.<br>
					
					
					<br><br>
					<br><br>
					<b><u>Definitions</u></b>
					<li><b><u>RS</b></u>		<i>Remote System</i><br>
					<li><b><u>LS</b></u>		<i>Local System</i><br>
					<li><b><u>PGP</b></u>		<i>Pretty Good Privacy. Encryption method that is preferred here at FirstHealth.</i><br>
				 </ul>
				 
		";
		
		return $help;
	}
	
?>