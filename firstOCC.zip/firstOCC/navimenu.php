<?php
   echo '
    <div class="divHeader">
     <img src="img/logo.png" height="50" width="425">	<hr width="100%">
      <ul id="minitabs">
		<li><a href="index.php" id="link">Home</a></li>
		<li><a href="EnterNewPatient.php" id="link1">New Patient</a></li>
		<li><a href="ViewAssist.php" id="link">Assistance Data</a></li>
        <li><a href="search.php" id="link">Search</a></li>
		<li><a href="reports.php" id="link">Reports</a></li>';
   		if ($_SESSION['role']=='Admin'){echo '<li><a href="admin.php" id="link">Site Administration</a></li>';}
   		echo '<li></li>
      </ul>
    </div>	
  <br> ';
?>
