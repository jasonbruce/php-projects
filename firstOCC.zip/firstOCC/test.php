<html>
<head>

<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript"> 
$(document).ready(function(){
  $(".flip").click(function(){
    $(".panel").slideToggle("fast");
  });
  
  $(".panel").click(function(){
    $("div").animate({height:0},"slow"); 
  });
 
 
});

</script>
 
<style type="text/css"> 
div.panel,p.flip
{
margin:0px;
padding:5px;
text-align:center;
background:#e5eecc;
border:solid 1px #c3c3c3;
width: 200px;
}
div.panel
{
height:120px;
display:none;
}
</style>
</head>
 
<body>
 
<p class="flip">Show/Hide Panel</p>
<div class="panel">
<p>Because time is valuable, we deliver quick and easy learning.</p>
<p>At W3Schools, you can study everything you need to learn, in an accessible and handy format.</p>
</div>


 
</body>
</html>








<?php









?>
