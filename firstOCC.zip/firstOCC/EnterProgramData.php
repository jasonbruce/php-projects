<?php

 include 'header.php';
 include 'functions.php';
 include 'modules.php';
 include 'navimenu.php';
 searchBar('');
 userInfo();
 floatComments();
 
 $submitted    = "false";
 $pID          = $_GET['id'];
 $userID = $_SESSION['uID'];
 		$yr    =  $_GET['yr'];
		$mo    =  $_GET['mo'];
		$da    =  $_GET['da'];
 $company      = $_GET['company'];
 $doctor       = $_GET['doctor'];
 $insurance    = $_GET['insurance'];
 $medicine     = $_GET['medicine'];
 $dosage       = $_GET['dosage'];
 $qty          = $_GET['qty'];
 $dateReceived = $_GET['dateReceived'];
 $cost         = $_GET['cost'];
 $comments     = mysql_real_escape_string ($_GET['comments']);
 $fname        = $_GET['fname'];
 $lname        = $_GET['lname'];
 $submitted    = $_GET['submitted'];
 $oralOrInfs	= $_GET['oralOrInfs'];
 		
 		if ($yr == '' || $mo == '' || $da ==''){
			$programDate ='';
		}else{
			$programDate = $yr . '-' . $mo . '-' . $da;	
		}
 
 
 if ($pID == ''){
 	echo showinformation("ERROR", "An error has occurred please try again");
 }else{
 	if ($programDate=='' or $dosage=='' or $qty=='' or $dateReceived=='' or $cost=='' or $oralOrInfs == ''){
 		enterProgramDataForm($programDate, $company, $doctor, $insurance, $medicine, $dosage, $qty, $dateReceived, $cost, $comments, $oralOrInfs);
 		if ($submitted == "true"){
 			showInformation('ERROR', 'You must fill out <br><li>Program Date<li>Dosage<li>qty<li>Date Received <li>Cost!');
 		}
 	}else{
	 	enterProgramDataForm('', '', '', '', '', '', '', '', '', '', '', '', '');
 		enterProgramDataQuery($pID, $userID, $programDate, $company, $doctor, $insurance, $medicine, $dosage, $qty, $dateReceived, $cost, $comments, $oralOrInfs);
 			showInformation('Information', 'Your Program data has been entered!');
 	}
 }



?>
