<?php


echo <<< END
<head><title></title>
	<link rel="stylesheet" type="text/css" href="ftp.css" media="all">	
	<script type="text/javascript" src="jquery.js"></script>
	<script type="text/javascript" src="ftp.js"></script>		  
</head>			  

END;



?>