<?php

 include 'header.php';
 include 'modules.php';
 	if ($_SESSION['loggedin'] == "true"){
  	 	include 'navimenu.php';
 		searchBar('');
 		userInfo();
 		floatComments();
 		$action = $_GET['delete'];
 	
 		if ($action == "true"){
 			$id = $_GET['assistid'];
 			deleteAssistance($id);
 			showPrograms();
 		}else{
 			$action = $_GET['copyit'];
 			if ($action == "true"){
 				$id = $_GET['assistid'];
 				copyAssistance($id);
 				showPrograms(); 				
 			}else{
 				showPrograms();
 			}
 		}
 	 }else{
		$action = $_POST['action'];
 		login($action, 'index.php');
 	}
 
 
 
 
?>