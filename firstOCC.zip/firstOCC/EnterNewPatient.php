<?php
 include 'header.php';
 include 'modules.php';
 
 if ($_SESSION['loggedin'] == "true"){
  	 	include 'navimenu.php';
 		searchBar('');
 		userInfo();
 		floatComments();
  		$fname =  mysql_real_escape_string (strtoupper($_GET['fName']));
 		$lname =  mysql_real_escape_string (strtoupper($_GET['lName']));
 		$yr    =  $_GET['yr'];
		$mo    =  $_GET['mo'];
		$da    =  $_GET['da'];
		
		
		if ($yr == '' || $mo == '' || $da ==''){
			$dob ='';
		}else{
			$dob = $yr . '-' . $mo . '-' . $da;	
		}
 		if ($fname == '' and $lname == '') {
   			enterPatientForm($fname,$lname,$dob);
 		} else {
    		if ($fname == '' or $lname == '') {	
      			enterPatientForm($fname,$lname,$dob);
      			showInformation("Missing Information", "You are missing information in the form");
    		} else {
      			enterPatientQuery($fname, $lname, $dob);
      			enterPatientForm('','','');	
      			showInformation('Information', 'Your Patient has been entered!');
    		}  
 		}
 		
 		footer();
 }else{
	$action = $_POST['action'];
 	login($action, 'index.php');
 }
 


 
?>
