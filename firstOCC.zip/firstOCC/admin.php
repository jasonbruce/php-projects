<?php
 include 'header.php';
 include 'modules.php';
 
 if ($_SESSION['loggedin'] == "true"){
  	 	include 'navimenu.php';
 		searchBar('');
 		userInfo();
 		floatComments();
 		$action = $_GET['action'];
		$id		= $_GET['id'];
 	
	
 	switch ($action){
 		case "edituser":
 			adminTable();
 			showGreyDivStart();
 				startEditForm();
 					showEditUserForm($action, $id, "Edit User Information");
 				endEditForm();
 			endDiv();
 			break;
 		case "adduser":
 			adminTable();
 			showGreyDivStart();
 				startEditForm();
 					showEditUserForm($action, '0', "Add New User");
 				endEditForm();
 			endDiv();
 			break;
 		case "adddoctor":
 			adminTable();
 			showGreyDivStart();
 				startEditForm();
 					showEditDoctorForm($action, '0', "Add New Doctor");
 				endEditForm();
 			endDiv();
 			break;
 		case "addcompany":
 			adminTable();
 			showGreyDivStart();
 				startEditForm();
 					showEditCompanyForm($action, '0', "Add New Company");
 				endEditForm();
 			endDiv();
 			break;
 		case "addinsurance":
 			adminTable();
 			showGreyDivStart();
 				startEditForm();
 					showEditInsuranceForm($action, '0', "Add New Insurance");
 				endEditForm();
 			endDiv();
 			break; 		
 		case "addmedicine":
 			adminTable();
 			showGreyDivStart();
 				startEditForm();
 					showEditMedicineForm($action, '0', "Add New Medicine");
 				endEditForm();
 			endDiv();
 			break; 		
 		case "adddemographics":
 			adminTable();
 			showGreyDivStart();
 				startEditForm();
 					showEditPatientsForm($action, '0', "Add New Patient");
 				endEditForm();
 			endDiv();
 			break;
 		
 		case "editdoctor":
 			adminTable();
 			showGreyDivStart();
 				startEditForm();
 					showEditDoctorForm($action, $id, "Edit Doctor Information");
 				endEditForm();
 			endDiv();
 			break;
 		case "editinsurance":
 			adminTable();
 			showGreyDivStart();
 				startEditForm();
 					showEditInsuranceForm($action, $id, "Edit Insurance Information");
 				endEditForm();
 			endDiv();
 			break;
 		case "editmedicine":
 			adminTable();
 			showGreyDivStart();
 				startEditForm();
 					showEditMedicineForm($action, $id, "Edit Medicine Information");
 				endEditForm();
 			endDiv();
 			break;
 		case "editdemographics":
 			adminTable();
 			showGreyDivStart();
 				startEditForm();
 					showEditPatientsForm($action, $id, "Edit Patient Information");
 				endEditForm();
 			endDiv();
 			break;
 		case "editcompany":
 			adminTable();
 			showGreyDivStart();
 				startEditForm();
 					showEditCompanyForm($action, $id, "Edit Company Information");
 				endEditForm();
 			endDiv();
 			break;
 		case "edituserSubmitted": 			
 			$userName 	= $_GET['userName'];
 			$email 		= $_GET['email'];
 			$type		= $_GET['type'];
 			editUsers($id,$userName,$email, $type, "edit");
 			adminTable();
 			showInformation("User Updated", "The user has been updated!");
 			break;
 		case "editdemographicsSubmitted": 			
 			$firstName 	= $_GET['firstName'];
 			$lastName	= $_GET['lastName'];
 			$dob		= $_GET['dob'];
 			editDemographics($id,$firstName,$lastName, $dob, "edit");
 			adminTable();
 			showInformation("Patient Updated", "The patient has been updated!");
 			break;
 		case "editmedicineSubmitted": 			
 			$Medicine	= $_GET['Medicine'];
 			editMedicine($id, $Medicine, "edit");
 			adminTable();
 			showInformation("Medicine Updated", "The Medicine has been updated!");
 			break;
 		case "editdoctorSubmitted": 			
 			$firstName	= $_GET['drfirstName'];
 			$lastName	= $_GET['drlastName'];
 			editDoctors($id, $firstName, $lastName, "edit");
 			adminTable();
 			showInformation("Doctor Updated", "The Doctor has been updated!");
 			break;
 		case "editinsuranceSubmitted": 			
 			$insuranceName	= $_GET['insuranceName'];
 			editInsurance($id, $insuranceName, "edit");
 			adminTable();
 			showInformation("Insurance Updated", "The Insurance has been updated!");
 			break;
 		case "editcompanySubmitted": 			
 			$companyName	= $_GET['companyName'];
 			editCompany($id, $companyName, "edit");
 			adminTable();
 			showInformation("Company Updated", "The Company has been updated!");
 			break;
 		case "adduserSubmitted": 			
 			$userName 	= $_GET['userName'];
 			$email 		= $_GET['email'];
 			$type		= $_GET['type'];
 			editUsers($id,$userName,$email, $type, "add");
 			adminTable();
 			showInformation("User Updated", "The user has been updated!");
 			break;
 		case "adddemographicsSubmitted": 			
 			$firstName 	= $_GET['firstName'];
 			$lastName	= $_GET['lastName'];
 			$dob		= $_GET['dob'];
 			editDemographics($id,$firstName,$lastName, $dob, "add");
 			adminTable();
 			showInformation("Patient Updated", "The patient has been updated!");
 			break;
 		case "addmedicineSubmitted": 			
 			$Medicine	= $_GET['Medicine'];
 			editMedicine($id, $Medicine, "add");
 			adminTable();
 			showInformation("Medicine Updated", "The Medicine has been updated!");
 			break;
 		case "adddoctorSubmitted": 			
 			$firstName	= $_GET['drfirstName'];
 			$lastName	= $_GET['drlastName'];
 			editDoctors($id, $firstName, $lastName, "add");
 			adminTable();
 			showInformation("Doctor Updated", "The Doctor has been updated!");
 			break;
 		case "addinsuranceSubmitted": 			
 			$insuranceName	= $_GET['insuranceName'];
 			editInsurance($id, $insuranceName, "add");
 			adminTable();
 			showInformation("Insurance Updated", "The Insurance has been updated!");
 			break;
 		case "addcompanySubmitted": 			
 			$companyName	= $_GET['companyName'];
 			editCompany($id, $companyName, "add");
 			adminTable();
 			showInformation("Company Updated", "The Company has been updated!");
 			break;
 		case "deletecompany": 			
 			editCompany($id, $companyName, "delete");
 			adminTable();
 			showInformation("Company Deleted", "The Company has been deleted!");
 			break;
 		case "deleteinsurance": 			
 			editInsurance($id, $insuranceName, "delete");
 			adminTable();
 			showInformation("Insurance Deleted", "The Insurance has been Deleted!");
 			break;
 		case "deletedoctor": 			
 			editDoctors($id, $firstName, $lastName, "delete");
 			adminTable();
 			showInformation("Doctor deleted", "The Doctor has been Deleted!");
 			break;
 		case "deletemedicine": 			
 			editMedicine($id, $Medicine, "delete");
 			adminTable();
 			showInformation("Medicine Deleted", "The Medicine has been deleted!");
 			break;
  		case "deleteddemographics": 			
 			editDemographics($id,$firstName,$lastName, $dob, "delete");
 			adminTable();
 			showInformation("Patient Deleted", "The patient has been deleted!");
 			break;
 		case "deleteuser": 			
 			editUsers($id,$userName,$email, $type, "delete");
 			adminTable();
 			showInformation("User Deleted", "The user has been deleted!");
 			break;
 		case "changePW": 			
 			changePW($id, 'admin.php');
 			adminTable();
 			break;
 		case "newPWSubmitted":
 			$newPW = $_GET['newPW']; 			
 			updatePW($id, $newPW);
 			adminTable();	
 			showInformation("Password Changed", "The Users PW has been updated!!");
 			break;
 		default:
 			adminTable();
 			break;
 	}
 		
 
 		
 	
 
 
 footer();
 		
 		
 		
 		
 }else{
	$action = $_POST['action'];
 	login($action, 'index.php');
 }
 
 
 	
 
?>
