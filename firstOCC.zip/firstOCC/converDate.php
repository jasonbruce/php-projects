<?php 

 include 'header.php';
 include 'modules.php';

 $query = 'SELECT assistID, date from tblAssistance';
 $result = mysql_query($query) or die(mysql_error());
			
 echo '<table>';
 	
 			while($row = mysql_fetch_array($result))
			{	
				echo '<tr>';
 					echo '<td>';
 						echo $row['assistID'];
 						$id = $row['assistID'];
 					echo '</td>';
 					echo '<td>';
 						echo $row['date'];
 					echo '</td>';
 					echo '<td>';
 						if (substr($row['date'],1,1) == "/"){
 							$mon = "0" . substr($row['date'],0,1);
 						}else{
 							$mon = substr($row['date'],0,2);
 						}
 						
						if (substr($row['date'],3,1) == "/"){
 							$da = "0" . substr($row['date'],2,1);
 						}else{
 							if (substr($row['date'],5,1) == "/"){
 								$da = substr($row['date'],3,2);
 							}else{
 								$da = substr($row['date'],2,2);
 							}
 						}
 						
 						$yr =  substr($row['date'],-4, 4);
 						echo $mon . '-' . $da . '-' . $yr;
 						$newDate = $mon . '-' . $da . '-' . $yr;
 						$nquery = "$nquery  update tblAssistance set date = '$newDate' where assistID = '$id' \r";
 					echo '</td>';
 					echo '<td>';
 						echo '<a href="converDate.php?id=' . $id .'&ndate='. $newDate .'" style="color:black;"> update date</a>';
 					echo'</td>';
 					echo '<td>';
 					echo'</td>';
 					echo '<td>';
 					echo'</td>';
 					echo '<td>';
 					echo'</td>';
 					echo '<td>';
 					echo'</td>';
 				echo '</tr>';				
			}
		echo '<tr><td colspan="6">' . $nquery .'</td></tr></table>';


?>