		$(document).ready(function(){	
			
      	  var txt = 'NA';
			
			$("#programDate").focusin(function(){
              $("#programDate").css("border","1px solid blue");
              $("#programDate").animate({width:"295px"},"slow")
            });
            $("#programDate").focusout(function(){
              $("#programDate").css("border", "1px solid #0e8c7a");
              $("#programDate").animate({width:"200px"},"slow")
                if (document.getElementById("programDate").value==""){
              	  $("#programDateError").slideDown("fast");
              	  	var tbox = document.getElementById('programDate');
              		if (tbox)
              			{
              				tbox.value = txt;
              			}
                }else{
              	  $("#programDateError").slideUp("fast");
                }
            });
            
            $("#dosage").focusin(function(){
                $("#dosage").css("border","1px solid blue");
                $("#dosage").animate({width:"295px"},"slow")
              });
              $("#dosage").focusout(function(){
                $("#dosage").css("border", "1px solid #0e8c7a");
                $("#dosage").animate({width:"200px"},"slow")
                  if (document.getElementById("dosage").value==""){
                	  $("#dosageError").slideDown("fast");
                	  var tbox = document.getElementById('dosage');
                	  if (tbox)
                	  {
                		  tbox.value = txt;
                	  }
                  }else{
                	  $("#dosageError").slideUp("fast");
                  }
              });
            
              $("#qty").focusin(function(){
                  $("#qty").css("border","1px solid blue");
                  $("#qty").animate({width:"295px"},"slow")
                });
                $("#qty").focusout(function(){
                  $("#qty").css("border", "1px solid #0e8c7a");
                  $("#qty").animate({width:"200px"},"slow")
                    if (document.getElementById("qty").value==""){
                  	  $("#qtyError").slideDown("fast");
                	  	var tbox = document.getElementById('qty');
                  		if (tbox)
                  			{
                  				tbox.value = txt;
                  			}                  	  
                    }else{
                  	  $("#qtyError").slideUp("fast");
                    }
                });
                
                $("#dateReceived").focusin(function(){
                    $("#dateReceived").css("border","1px solid blue");
                    $("#dateReceived").animate({width:"295px"},"slow")
                  });
                  $("#dateReceived").focusout(function(){
                    $("#dateReceived").css("border", "1px solid #0e8c7a");
                    $("#dateReceived").animate({width:"200px"},"slow")
                      if (document.getElementById("dateReceived").value==""){
                    	  $("#dateReceivedError").slideDown("fast");
                    	  var tbox = document.getElementById('dateReceived');
                    	  if (tbox)
                    	  {
                    		  tbox.value = txt;
                    	  }               
                      }else{
                    	  $("#dateReceivedError").slideUp("fast");
                      }
                  });
                  
                  $("#cost").focusin(function(){
                      $("#cost").css("border","1px solid blue");
                      $("#cost").animate({width:"295px"},"slow")
                    });
                    $("#cost").focusout(function(){
                      $("#cost").css("border", "1px solid #0e8c7a");
                      $("#cost").animate({width:"200px"},"slow")
                        if (document.getElementById("cost").value==""){
                      	  $("#costError").slideDown("fast");
                    	  var tbox = document.getElementById('cost');
                    	  if (tbox)
                    	  {
                    		  tbox.value = '00.00';
                    	  }                      	  
                        }else{
                      	  $("#costError").slideUp("fast");
                        }
                    });
            
		});