<?php
$database="localhost";
$dbun="root";
$dbpw="";
$con = mysql_connect($database, $dbun, $dbpw) or die("uh o--houston we have a database problem!");
mysql_select_db("firstOCC", $con);

 
function userInfo(){
  echo '
	<p class="menuBtn"><b>Welcome Back '. $_SESSION['un'] . '</b></p>
	<div class="adminPanel">
		<center><b><u>FirstOCC v1.0 Beta</b></u></center>
		 <b>User ID#:</b><i> '. $_SESSION['uID'] . '</i><br>
		 <b>User Name:</b><i> '. $_SESSION['un'] . '</i><br>
		 <b>Email:</b><i> '. $_SESSION['email'] . '</i><br>
		 <b>User Type:</b><i> '. $_SESSION['role'] . '</i><br>
		 <a href="index.php?action=changePW" id="link"><center><b><u>Change PW</b></u></center></a>
	</div>
  ';
}
function footer(){
    echo '</body></html>';
 }
function searchBar($searchQuery){

     echo '<div class="searchDivContainer">';
       echo '<div class="searchDivContent">';
        echo '<form action="search.php" method="GET">
                <input type="TEXT" name="search" class="txtSearchForm" value=' . $searchQuery . '><input type="submit" value="" class="btnSearch"></form>';
       echo '</div>';
     echo '</div>';
}
function loginForm($page){
     echo '<div class="smallDivContainer">';
      echo '<div class="smallDivTop"><div class="smallDivHeader"></div></div>';
       echo '<div class="smallDivMiddle">';
        echo '<div class="smallDivContent">';
		echo '<form action="'.$page.'" method="POST">';
                 echo '<table>';
                  echo '<tr><td colspan="4"><label class="lblHeader">FirstOCC Login</label></td></tr>';
                  echo '<tr><td><label class="lblForm">User Name:</label></td><td><input type="text" name="un" id="un" class="txtForm"></td></tr>';
                  echo '<tr><td><label class="lblForm">Password:</label></td><td><input type="password" name="pw" id="pw" class="txtForm"></td></tr>';
                  echo '<input type="hidden" name="action" value="loggingin">';
                  echo '<tr><td></td><td><input type="submit" value="Login" class="btnForm"></td></tr>';
                 echo '</table>';
                echo '</form>';
        echo '</div>';
       echo '</div>';
      echo '<div class="smallDivBottom"></div>';
     echo '</div>';
}
function enterPatientForm($firstName, $lastName, $dob){
     echo '<div class="smallDivContainer">';
      echo '<div class="smallDivTop"><div class="smallDivHeader"></div></div>';
       echo '<div class="smallDivMiddle">';
        echo '<div class="smallDivContent">';
                echo '<form action="EnterNewPatient.php" method="GET">';
                 echo '<table>';
                  echo '<tr><td colspan="8"><label class="lblHeader">Enter New Patient</label></td></tr>';
                  echo '<tr><td><label class="lblForm">First Name:</label></td><td><input type="text" name="fName" id="fn" value="'. $firstName  .'" class="txtForm"></td></tr>';
                  echo '<tr><td colspan="8"><div id="fNameError" class="frmError"><center>First Name is a Required Field</center></div></td></tr>';
                  echo '<tr><td><label class="lblForm">Last Name:</label></td><td><input type="text" name="lName" id="ln" value="'. $lastName  .'"  class="txtForm"></td></tr>';
                  echo '<tr><td colspan="8"><div id="lNameError" class="frmError"><center>Last Name is a Required Field</center></div></td></tr>';
                  echo '<tr><td><label class="lblForm">DOB(mm-dd-yyyy):</label></td><td><input type="text" name="mo" id="mo" class="txtForm" maxlength="2" style="width: 30px;">-
                  																		<input type="text" name="da" id="da" class="txtForm" maxlength="2" style="width: 30px;">-
                  																		<input type="text" name="yr" id="yr" class="txtForm" maxlength="4" style="width: 60px;">
                  	    </td></tr>';
                  echo '<tr><td></td><td><input type="submit" value="Enter Patient" class="btnForm" name="btnEnterPat"></td></tr>';
                 echo '</table>';
                echo '</form>';
        echo '</div>';
       echo '</div>';
      echo '<div class="smallDivBottom"></div>';
     echo '</div>';
}
function enterProgramDataForm($programDate, $company, $doctor, $insurance, $medicine, $dosage, $qty, $dateReceived, $cost, $comments, $fname, $lname, $oralOrInfs){
$id = $_GET['id'];
	
	echo '<div class="smallDivContainer">';
      echo '<div class="smallDivTop"><div class="smallDivHeader"></div></div>';
       echo '<div class="smallDivMiddle">';
        echo '<div class="smallDivContent">';
                echo '<form action="EnterProgramData.php" method="GET">';
                 echo '<table>';
                  echo '<tr><td colspan="4"><label class="lblHeader">Enter Program Data</label></td></tr>';
                  echo '<tr><td colspan="4"><label class="lblHeader">' . $fname . ' '  . $lname . '</label></td></tr>';
                  echo '<tr><td><label class="lblForm">Date:</label></td>           <td><input type="text" name="mo" id="mo" class="txtForm" maxlength="2" style="width: 30px;">-
                  																		<input type="text" name="da" id="da" class="txtForm" maxlength="2" style="width: 30px;">-
                  																		<input type="text" name="yr" id="yr" class="txtForm" maxlength="4" style="width: 60px;">
                  	    </td></tr>';                  
                  echo '<tr><td colspan="4"><div class="frmError" id="programDateError"><center>Please enter a date!</center></div>';
                  if ($oralOrInfs == 'O'){$oCheck = "checked";}
				  if ($oralOrInfs == 'I'){$iCheck = "checked";}
                  echo '<tr><td colspan="2">
                  																			<center><fieldset class="fsForm">
																							   <legend class="lblForm">Oral/Infusion</legend>
																								<input type="radio" name="oralOrInfs" value="O" ' . $oCheck . '>Oral
																								<input type="radio" name="oralOrInfs" value="I" ' . $iCheck . '>Infusion
																							</fieldset></center>
                  </td>';
                  echo '<tr><td><label class="lblForm">Doctor:</label></td>         <td>';
                        populateDropDown('doctor', 'tblMD', 'lastName', 'mdID', 'ddForm', '');
                  echo '</td></tr>';
                  echo '<tr><td><label class="lblForm">Medicine:</label></td>       <td>';
                        populateDropDown('medicine', 'tblMeds', 'medicine', 'medID', 'ddForm', '');
                  echo '</td></tr>';
                  echo '<tr><td><label class="lblForm">Dosage:</label></td>         <td><input id="dosage" type="text" name="dosage"          value="' . $dosage . '"          class="txtForm"></td>';
                  echo '<tr><td colspan="4"><div class="frmError" id="dosageError"><center>Please enter a dosage!</center></div>';
                  echo '<tr><td><label class="lblForm">Quantity:</label></td>       <td><input id="qty" type="text" name="qty"             value="' . $qty . '"             class="txtForm"></td>';
                  echo '<tr><td colspan="4"><div class="frmError" id="qtyError"><center>Please enter a quantity!</center></div>';          
                  echo '<tr><td><label class="lblForm">Insurance:</label></td>      <td>';
                        populateDropDown('insurance', 'tblInsurance', 'insuranceName', 'inID', 'ddForm', '');
                  echo '</td></tr>';
                  echo '<tr><td><label class="lblForm">Company:</label></td>        <td>';
						populateDropDown('company', 'tblCompany', 'companyName', 'companyID', 'ddForm', '');	          
                  echo '</td></tr>';
                  echo '<tr><td><label class="lblForm">Date Received:</label></td>  <td><input id="dateReceived" type="text" name="dateReceived"    value="' . $dateReceived . '"    class="txtForm"></td>';
                  echo '<tr><td colspan="4"><div class="frmError" id="dateReceivedError"><center>Please enter the date recevied!</center></div>';
                  echo '<tr><td><label class="lblForm">Cost:</label></td>           <td><input id="cost" type="text" name="cost"            value="' . $cost . '"            class="txtForm"></td>';
                  echo '<tr><td colspan="4"><div class="frmError" id="costError"><center>Please enter the cost!</center></div>';
                  echo '<tr><td><label class="lblForm">Comments:</label></td>       <td><textarea id="comments" name="comments"                                         class="txtAreaForm">' . $comments  . '</textarea></td>';
                  echo '<tr><td></td><td><input type="submit" value="Enter Program Data" class="btnForm"></td></tr>';
                  echo '<input type="hidden" name="id" value="'. $id .'">';
                  echo '<input type="hidden" name="submitted" value="true">';
                 echo '</table>';
                echo '</form>';
        echo '</div>';
       echo '</div>';
      echo '<div class="smallDivBottom"></div>';
     echo '</div>';
}
function enterPatientQuery($firstName, $lastName, $dob){
    strtoupper(mysql_real_escape_string ($firstName));
    strtoupper(mysql_real_escape_string ($lastName));
    strtoupper(mysql_real_escape_string ($dob));

    $query = "INSERT INTO tblDemographics (firstName, lastName, dob, active) VALUES ('$firstName', '$lastName', '$dob', 'Y')";
    mysql_query($query) or die("An Error occurred and your patient was not entered!!!");
    
    $id = mysql_insert_id();
    
    echo '<div class="enterAssistance">';
    		showInformation("Enter Assistance Data", 'You may now enter this patients assistance information by clicking the link below:<br><a href="EnterProgramData.php?id=' . $id .'"><img src="img/add.png" class="LrgIcon">Add Assitance</a><br>');
    		header('location: http://dev-occ-mrh/EnterProgramData.php?id=' . $id);
    echo '</div>';
    
}
function enterProgramDataQuery($pID, $userID, $programDate, $company, $doctor, $insurance, $medicine, $dosage, $qty, $dateReceived, $cost, $comments, $oralOrInfs){
    $programDate 		= strtoupper(mysql_real_escape_string ($programDate));
    $company 			= strtoupper(mysql_real_escape_string ($company));
    $doctor 			= strtoupper(mysql_real_escape_string ($doctor));
	$insurance 			= strtoupper(mysql_real_escape_string ($insurance));
	$medicine 			= strtoupper(mysql_real_escape_string ($medicine));
	$dosage 			= strtoupper(mysql_real_escape_string ($dosage));
	$qty 				= strtoupper(mysql_real_escape_string ($qty));
	$dateRecieved		= strtoupper(mysql_real_escape_string ($dateRecieved));
	$cost 				= str_replace(",","",strtoupper(mysql_real_escape_string ($cost)));
	$comments 			= strtoupper(mysql_real_escape_string ($comments));
	
	
	
	$query = "INSERT INTO tblAssistance (companyID, pID, mdID, medID, dose, qty, dateReceived, date, comments, cost, userID, inID, medtype) VALUES ('$company', '$pID', '$doctor', '$medicine', '$dosage', '$qty', '$dateReceived', '$programDate', '$comments', '$cost', '$userID', '$insurance', '$oralOrInfs')";
   // echo '<br>' . $query .'<br>';
	mysql_query($query) or die("ERROR: Your data has not been entered!");
}
function login($action, $page){
	if ($action == 'loggingin'){
 	  $uName = $_POST['un'];
 	  $pWord = $_POST['pw'];
 	
 		if ($uName == ''){
 		  loginForm($page);
 		  showInformation("Missing Info", "Please enter your user name!");
 		}else{
 			if ($pWord == ''){
 				loginForm('index.php');
 				showInformation("Missing Info", "Please enter your password!");
 			}else{
 				$found = checkLogin($uName, $pWord);
 					if ($found <> "true"){
 							echo 'Access Denied!!!!';
 					}
 			}
 		}
    } else {
 		if ($action == ''){
 			loginForm('index.php');
 		}
 	}
}
function checkLogin($un, $pw){
	$query = "SELECT * FROM tblUsers where active='Y'";
	$result = mysql_query($query);
	$found == "false";
	
	while($row = mysql_fetch_array($result)){
		if ($un == $row['userName'] && sha1($pw) == $row['password']){
			$found = "true";
			$_SESSION['role'] = $row['type'];
			$_SESSION['un'] = $row['userName'];
			$_SESSION['loggedin'] = "true";
			$_SESSION['uID'] = $row['userID']; 
			$_SESSION['email'] = $row['email'];
				include 'navimenu.php';
 				include 'adminMenu.php';
 				searchBar('');
 				tasks();
		}		
	}
	return $found;
}
function showInformation($title, $info){
    echo '<div class="infoDivContainer">';
      echo '<div class="infoDivTop"><div class="infoDivHeader"><label class="lblInfoHeader">' . $title  . '</label></div></div>';
       echo '<div class="infoDivMiddle">';
        echo '<div class="infoDivContent">';
         echo '<label class="lblInfo">' . $info . '</label>';
        echo '</div>';
       echo '</div>';
      echo '<div class="infoDivBottom"></div>';
     echo '</div>';
}
function populateDropDown($ddName, $tbl, $fld, $fldID, $className, $selectedVal){
                $query = "SELECT $fld, $fldID FROM $tbl where active='Y' order by $fld asc";
                echo '<select id="' . $ddName . '" name="'. $ddName . '" class="selectFrm">';
                $result = mysql_query($query);
                while($row = mysql_fetch_array($result)){
                	if ($selectedVal == $row[$fld]){
                		echo '<option value="'.$row[$fldID].'" selected="selected">'.$row[$fld].'</option>';
                	}else{
                     	echo '<option value="'.$row[$fldID].'">'.$row[$fld].'</option>';
                	}
                }
                echo '</select>';
}
function changePW($id, $page){
	
 showGreyDivStart();
  startEditForm($page);
 					
	echo '<form action="' . $page . '" method="get">';
	 echo '<table class="editFrmTbl">';
		echo '<tr><th colspan="2" class="admlblHeaderFrm">Change PW</th></tr>';
		echo '<tr><td><label>New PW:</label></td>		<td><input 	type="password" 		name="newPW" ></td></tr>';
		echo '<tr><td><input type="hidden" name="action" value="newPWSubmitted"></td><td><input type="submit" value="Submit" class="btnForm"><input type="hidden" name="id" value="'.$id.'"></td></tr>';
	 echo '</table>';
	echo '</form>';

  endEditForm();
 endDiv();
 die;

}
function updatePW($id, $nPW){
	if ($nPW == '' || $id == ''){
		showInformation('Missing Data / Error', 'An Error Occurred! Please close browser and try again');
	}else{
		$nPW = sha1($nPW);
		$query = "update tblUsers set password = '$nPW' where userID = '$id'";
		$result = mysql_query($query);
	}
}
//----------------admin page modules------------------ 
function adminTable(){
	echo '<table>';
     echo '<tr>		<td><div class="adminHeader" id="editUsers">Edit Users - - - - - - - - - - - - - - - <a href="admin.php?action=adduser"><img src="img/add.png" class="LrgIcon">Add New</a></div><div class="adminEditDiv" id="userDiv">			';
     		showEditUsers();     
     echo '</div></td></tr>';
     echo '<tr>		<td><div class="adminHeader" id="editPatients">Edit Patients- - - - - - - - - - - - - - <a href="admin.php?action=adddemographics"><img src="img/add.png" class="LrgIcon">Add New</a></div>		<div class="adminEditDiv" id="patientsDiv">		'; 
     		showEditPatients();
     echo '</div></td></tr>';
     echo '<tr>		<td><div class="adminHeader" id="editDoctors">Edit Doctors- - - - - - - - - - - - - - <a href="admin.php?action=adddoctor"><img src="img/add.png" class="LrgIcon">Add New</a></div>		<div class="adminEditDiv" id="doctorsDiv">		';
     		showEditDoctors(); 
     echo '</div></td></tr>';
     echo '<tr>		<td><div class="adminHeader" id="editCompanies">Edit Companies- - - - - - - - - - - - <a href="admin.php?action=addcompany"><img src="img/add.png" class="LrgIcon">Add New</a></div>	<div class="adminEditDiv" id="companiesDiv">	'; 
     		showEditCompanies();
     echo  '</div></td></tr>';
     echo '<tr>		<td><div class="adminHeader" id="editInsurances">Edit Insurances- - - - - - - - - - - - - <a href="admin.php?action=addinsurance"><img src="img/add.png" class="LrgIcon">Add New</a></div>	<div class="adminEditDiv" id="insurancesDiv">	'; 
     		showEditInsurance();
     echo  '</div></td></tr>';
     echo '<tr>		<td><div class="adminHeader" id="editMedicines">Edit Medicines- - - - - - - - - - - - - <a href="admin.php?action=addmedicine"><img src="img/add.png" class="LrgIcon">Add New</a></div>	<div class="adminEditDiv" id="medicinesDiv">	'; 
     		showEditMedicine();
     echo  '</div></td></tr>';
    echo '</table>';
}
function showEditUsers(){
	echo '<div class="editTablesDiv"><table class="editTables">';
	  echo '<tr>';
	    echo '<th class="editTables">Action</th><th class="editTables">User Name</th><th class="editTables">Email</th><th class="editTables">Type</th>';
	  echo '</tr>';
	  echo '<tr>';
	   		$query = "Select * from tblUsers WHERE active='Y'   ORDER BY userName ASC";
			$result = mysql_query($query) or die(mysql_error());
				while($row = mysql_fetch_array($result))
				{
					echo '<tr><td class="editTables"><a href="admin.php?action=edituser&id=' . $row['userID'] . '"><img src="img/edit.png" class="icon"></a>&nbsp;&nbsp;<a href="admin.php?action=deleteuser&id=' . $row['userID'] . '"><img src="img/delete.jpg" class="icon"></a>&nbsp;&nbsp;<a href="admin.php?action=changePW&id=' . $row['userID'] . '"><img src="img/changePW.png" class="icon"></a></td><td class="editTables">'. $row['userName'].'</td><td class="editTables">'.$row['email'].'</td><td class="editTables">'.$row['type'].'</td></tr>';
				}
	  echo  '</tr>';
	  echo  '<tr><td colspan=4 class="editTables"><a href="admin.php?action=adduser"><img src="img/add.png" class="LrgIcon"></a>Add New User</td></tr>'; 
	echo '</table></div>';
}	
function showEditDoctors(){
	echo '<div class="editTablesDiv"><table class="editTables">';
	  echo '<tr>';
	    echo '<th class="editTables">Action</th><th class="editTables">First Name</th><th class="editTables">Last Name</th>';
	  echo '</tr>';
	  echo '<tr>';
	   		$query = "Select * from tblMD  WHERE active='Y'  ORDER BY lastName ASC";
			$result = mysql_query($query) or die(mysql_error());
				while($row = mysql_fetch_array($result))
				{
					echo '<tr><td class="editTables"><a href="admin.php?action=editdoctor&id=' . $row['mdID'] . '"><img src="img/edit.png" class="icon"></a>&nbsp;&nbsp;<a href="admin.php?action=deletedoctor&id=' . $row['mdID'] . '"><img src="img/delete.jpg" class="icon"></a></td><td class="editTables">'. $row['firstName'].'</td><td class="editTables">'.$row['lastName'].'</td></tr>';
				}
	  echo  '</tr>';
	  echo  '<tr><td colspan=3 class="editTables"><a href="admin.php?action=adddoctor"><img src="img/add.png" class="LrgIcon"></a>Add New Doctor</td></tr>'; 
	echo '</table></div>';
}
function showEditPatients(){
	echo '<div class="editTablesDiv"><table class="editTables">';
	  echo '<tr>';
	    echo '<th class="editTables">Action</th><th class="editTables">First Name</th><th class="editTables">Last Name</th><th class="editTables">DOB</th>';
	  echo '</tr>';
	  echo '<tr>';
	   		$query = "Select * from tblDemographics WHERE active='Y'   ORDER BY firstName ASC";
			$result = mysql_query($query) or die(mysql_error());
				while($row = mysql_fetch_array($result))
				{
					echo '<tr><td class="editTables"><a href="admin.php?action=editdemographics&id=' . $row['pID'] . '"><img src="img/edit.png" class="icon"></a>&nbsp;&nbsp;<a href="admin.php?action=deleteddemographics&id=' . $row['pID'] . '"><img src="img/delete.jpg" class="icon"></a></td><td class="editTables">'. $row['firstName'].'</td><td class="editTables">'.$row['lastName'].'</td><td class="editTables">'.$row['dob'].'</td></tr>';
				}
	  echo  '</tr>';
	  echo  '<tr><td colspan=4 class="editTables"><a href="admin.php?action=adddemographics"><img src="img/add.png" class="LrgIcon"></a>Add New Patient</td></tr>'; 
	echo '</table></div>';
}	
function showEditCompanies(){
	echo '<div class="editTablesDiv"><table class="editTables">';
	  echo '<tr>';
	    echo '<th class="editTables">Action</th><th class="editTables">Company Name</th>';
	  echo '</tr>';
	  echo '<tr>';
	   		$query = "Select * from tblCompany WHERE active='Y'  ORDER BY companyName ASC";
			$result = mysql_query($query) or die(mysql_error());
				while($row = mysql_fetch_array($result))
				{
					echo '<tr><td class="editTables"><a href="admin.php?action=editcompany&id=' . $row['companyID'] . '"><img src="img/edit.png" class="icon"></a>&nbsp;&nbsp;<a href="admin.php?action=deletecompany&id=' . $row['companyID'] . '"><img src="img/delete.jpg" class="icon"></a></td><td class="editTables">'. $row['companyName'].'</td></tr>';
				}
	  echo  '</tr>';
	  echo  '<tr><td colspan=4 class="editTables"><a href="admin.php?action=addcompany"><img src="img/add.png" class="LrgIcon"></a>Add New Company</td></tr>'; 
	echo '</table></div>';	
}
function showEditInsurance(){
	echo '<div class="editTablesDiv"><table class="editTables">';
	  echo '<tr>';
	    echo '<th class="editTables">Action</th><th class="editTables">Insurance Name</th>';
	  echo '</tr>';
	  echo '<tr>';
	   		$query = "select * from tblInsurance WHERE active='Y' ORDER BY insuranceName ASC";
			$result = mysql_query($query) or die(mysql_error());
				while($row = mysql_fetch_array($result))
				{
					echo '<tr><td class="editTables"><a href="admin.php?action=editinsurance&id=' . $row['inID'] . '"><img src="img/edit.png" class="icon"></a>&nbsp;&nbsp;<a href="admin.php?action=deleteinsurance&id=' . $row['inID'] . '"><img src="img/delete.jpg" class="icon"></a></td><td class="editTables">'. $row['insuranceName'].'</td></tr>';
				}
	  echo  '</tr>';
	  echo  '<tr><td colspan=4 class="editTables"><a href="admin.php?action=addinsurance"><img src="img/add.png" class="LrgIcon"></a>Add New Insurance</td></tr>'; 
	echo '</table></div>';	
}
function showEditMedicine(){
	echo '<div class="editTablesDiv"><table class="editTables">';
	  echo '<tr>';
	    echo '<th class="editTables">Action</th><th class="editTables">Medicine</th>';
	  echo '</tr>';
	  echo '<tr>';
	   		$query = "Select * from tblMeds WHERE active='Y' order by Medicine asc";
			$result = mysql_query($query) or die(mysql_error());
				while($row = mysql_fetch_array($result))
				{
					echo '<tr><td class="editTables"><a href="admin.php?action=editmedicine&id=' . $row['medID'] . '"><img src="img/edit.png" class="icon"></a>&nbsp;&nbsp;<a href="admin.php?action=deletemedicine&id=' . $row['medID'] . '"><img src="img/delete.jpg" class="icon"></a></td><td class="editTables">'. $row['Medicine'].'</td></tr>';
				}
	  echo  '</tr>';
	  echo  '<tr><td colspan=4 class="editTables"><a href="admin.php?action=addmedicine"><img src="img/add.png" class="LrgIcon"></a>Add New Medicine</td></tr>'; 
	echo '</table></div>';	
}
function showGreyDivStart(){
	echo '<div class="wholeScreenDiv">';
}
function endDiv(){
	echo '</div>';
}
function startEditForm($page){
	if ($page == ''){$page='admin.php';}
	echo '
	  <div class="admFormContainer">            
        <div class="admFormTop"><div class="admFormClose"><a href="'. $page .'?action=close"><img src="img/close.png" class="LrgIcon"></a></div></div>
        <div class="admFormMiddle">
            <div class="admFormContent">
    ';
}          
function endEditForm(){               
	echo '
		</div>
        </div>
        	<div class="admFormBottom"></div>
        </div>
    	</div>
    ';   
}
function showEditUserForm($action, $id, $headerTit){
	if ($id > 0){
		$query = "Select * from tblUsers where userID='$id' AND active='Y'";
		$result = mysql_query($query) or die(mysql_error());
			while($row = mysql_fetch_array($result))
			{
				$userName 	= $row['userName'];
				$email 		= $row['email'];
				$type 		= $row['type'];
			}
	}else{
		$userName 	= '';
		$email 		= '';
		$type		= '';
	}
	echo '<form action="admin.php" method="get">';
	echo '<table class="editFrmTbl">';
		echo '<tr><th colspan="2" class="admlblHeaderFrm">' . $headerTit . '</th></tr>';
		echo '<tr><td><label>User Name:</label></td>	<td><input 	type="text" 		name="userName" 	id="userName" 	value="' . $userName . '"></td></tr>';
		echo '<tr><td><label>Email:</label></td>		<td><input 	type="text" 		name="email" 		id="email" 		value="' . $email . '"></td></tr>';
		echo '<tr><td><label>Type:</label></td>			<td><select name="type"><option>User</option><option>Admin</option></select></td></tr>';
		echo '<tr><td><input type="hidden" name="action" value="' . $action . 'Submitted"><input type="hidden" name="id" value="' . $id . '"></td><td><input type="submit" value="Submit" class="btnForm"></td></tr>';
	echo '</table>';
	echo '</form>';
}
function sendEMail($to, $body, $subject){
 	
$headers = 'From: firstOCC' . "\r\n" .
   'Reply-To: jbruce@firsthealth.org' . "\r\n" .
   'X-Mailer: PHP/' . phpversion();


if (mail($to, $subject, $body, $headers)) {
  } else {
   echo("<p>Message delivery failed... Please check email address entered.</p>");
  }
}
function showEditDoctorForm($action, $id, $headerTit){
	if ($id > 0){
		$query = "Select * from tblMD where mdID='$id' AND active='Y'";
		$result = mysql_query($query) or die(mysql_error());
			while($row = mysql_fetch_array($result))
			{
				$firstName 	= $row['firstName'];
				$lastName	= $row['lastName'];
			}
	}else{
		$firstName 	= '';
		$lastName 	= '';
	}
	echo '<form action="admin.php" method="get">';
	echo '<table class="editFrmTbl">';
		echo '<tr><th colspan="2" class="admlblHeaderFrm">' . $headerTit . '</th></tr>';
		echo '<tr><td><label>First Name:</label></td>		<td><input 	type="text" 		name="drfirstName" 		id="drfirstname" 	value="' . $firstName . '"></td></tr>';
		echo '<tr><td><label>Last Name:</label></td>		<td><input 	type="text" 		name="drlastName" 		id="drlastname" 		value="' . $lastName . '"></td></tr>';
		echo '<tr><td><input type="hidden" name="action" value="' . $action . 'Submitted"><input type="hidden" name="id" value="' . $id . '"></td><td><input type="submit" value="Submit" class="btnForm"></td></tr>';
	echo '</table>';
	echo '</form>';
}
function showEditCompanyForm($action, $id, $headerTit){
	if ($id > 0){
		$query = "Select * from tblCompany where companyID='$id' AND active='Y'";
		$result = mysql_query($query) or die(mysql_error());
			while($row = mysql_fetch_array($result))
			{
				$companyName 	= $row['companyName'];
			}
	}else{
		$companyName 	= '';
	}
	echo '<form action="admin.php" method="get">';
	echo '<table class="editFrmTbl">';
		echo '<tr><th colspan="2" class="admlblHeaderFrm">' . $headerTit . '</th></tr>';
		echo '<tr><td><label>Company Name:</label></td>		<td><input 	type="text" 		name="companyName" 	id="companyName" 	value="' . $companyName . '"></td></tr>';
		echo '<tr><td><input type="hidden" name="action" value="' . $action . 'Submitted"><input type="hidden" name="id" value="' . $id . '"></td><td><input type="submit" value="Submit" class="btnForm"></td></tr>';
	echo '</table>';
	echo '</form>';
}
function showEditInsuranceForm($action, $id, $headerTit){
	if ($id > 0){
		$query = "Select * from tblInsurance where inID='$id'";
		$result = mysql_query($query) or die(mysql_error());
			while($row = mysql_fetch_array($result))
			{
				$insuranceName 	= $row['insuranceName'];
			}
	}else{
		$insuranceName 	= '';
	}
	echo '<form action="admin.php" method="get">';
	echo '<table class="editFrmTbl">';
		echo '<tr><th colspan="2" class="admlblHeaderFrm">' . $headerTit . '</th></tr>';
		echo '<tr><td><label>Insurance Name:</label></td>		<td><input 	type="text" 		name="insuranceName" 	id="insuranceName" 	value="' . $insuranceName . '"></td></tr>';
		echo '<tr><td><input type="hidden" name="action" value="' . $action . 'Submitted"><input type="hidden" name="id" value="' . $id . '"></td><td><input type="submit" value="Submit" class="btnForm"></td></tr>';
	echo '</table>';
	echo '</form>';
}
function showEditMedicineForm($action, $id, $headerTit){
	if ($id > 0){
		$query = "Select * from tblMeds where medID='$id' AND active='Y'";
		$result = mysql_query($query) or die(mysql_error());
			while($row = mysql_fetch_array($result))
			{
				$Medicine 	= $row['Medicine'];
			}
	}else{
		$Medicine 	= '';
	}
	echo '<form action="admin.php" method="get">';
	echo '<table class="editFrmTbl">';
		echo '<tr><th colspan="2" class="admlblHeaderFrm">' . $headerTit . '</th></tr>';
		echo '<tr><td><label>Medicine:</label></td>		<td><input 	type="text" 		name="Medicine" 	id="Medicine" 	value="' . $Medicine . '"></td></tr>';
		echo '<tr><td><input type="hidden" name="action" value="' . $action . 'Submitted"><input type="hidden" name="id" value="' . $id . '"></td><td><input type="submit" value="Submit" class="btnForm"></td></tr>';
	echo '</table>';
	echo '</form>';
}
function showEditPatientsForm($action, $id, $headerTit){
	if ($id > 0){
		$query = "Select * from tblDemographics where pID='$id' AND active='Y'";
		$result = mysql_query($query) or die(mysql_error());
			while($row = mysql_fetch_array($result))
			{
				$firstName 	= $row['firstName'];
				$lastName 	= $row['lastName'];
				$dob 		= $row['dob'];
			}
	}else{
		$firstName 	= '';
		$lastName 	= '';
		$dob		= '';
	}
	echo '<form action="admin.php" method="get">';
	echo '<table class="editFrmTbl">';
		echo '<tr><th colspan="2" class="admlblHeaderFrm">' . $headerTit . '</th></tr>';
		echo '<tr><td><label>First Name:</label></td>	<td><input 	type="text" 		name="firstName" 	id="firstName" 	value="' . $firstName . '"></td></tr>';
		echo '<tr><td><label>Last Name:</label></td>		<td><input 	type="text" 		name="lastName" 		id="lastName" 		value="' . $lastName . '"></td></tr>';
		echo '<tr><td><label>Dob:</label></td>			<td><input 	type="text" 		name="dob" 		id="dob" 		value="' . $dob . '"></td></tr>';
		echo '<tr><td><input type="hidden" name="action" value="' . $action . 'Submitted"><input type="hidden" name="id" value="' . $id . '"></td><td><input type="submit" value="Submit" class="btnForm"></td></tr>';
	echo '</table>';
	echo '</form>';
}
function editUsers		($id, $userName, $email, $type, $action){
$pw = sha1('temp1');
	if ($action == "edit") {
		$query = "UPDATE tblUsers SET userName = '$userName', email = '$email', type='$type' where userid='$id'";
	}else{
		if ($action=="delete"){
			$query = "UPDATE tblUsers SET active='N' WHERE userid='$id'";
		}else{
			$query = "INSERT INTO tblUsers (userName, email, type, password, active) VALUES ('$userName', '$email', '$type', '$pw' , 'Y')";
			$to = $email;
			$body = 'Welcome to FirstOCC! ' . chr(13) . chr(13) . ' You can now log in to http://firstOCC/ using the information listed below.' . chr(13) . chr(13) . ' Username: ' . $userName .  chr(13) . 'Temporary Password: temp1';
			$subj = "First Out Patient Cancer Center Database - New User";
			sendEMail($to, $body, $subj);
		}
	}
	mysql_query($query) or die("User has not been edited!");
}
function editDoctors	($id, $firstName, $lastName, $action){
	if ($action == "edit") {
		$query = "UPDATE tblMD SET firstName = '$firstName', lastName = '$lastName' where mdID='$id'";
	}else{
		if ($action=="delete"){
			$query = "UPDATE tblMD  SET active='N' WHERE mdID='$id'";
		}else{
			$query = "INSERT INTO tblMD(firstName, lastName, active) VALUES ('$firstName', '$lastName', 'Y')";
		}
	}
	mysql_query($query) or die("Doctor has not been edited!");
}
function editMedicine	($id, $Medicine, $action){
	if ($action == "edit") {
		$query = "UPDATE tblMeds SET Medicine = '$Medicine' where medID ='$id'";
	}else{
		if ($action=="delete"){
			$query = "UPDATE tblMeds SET active='N' where medID='$id'";
		}else{
			$query = "INSERT INTO tblMeds (Medicine, active) VALUES ('$Medicine', 'Y')";
		}
	}
	mysql_query($query) or die("Medicine has not been edited!");
}
function editInsurance	($id, $insuranceName, $action){
	if ($action == "edit") {
		$query = "UPDATE tblInsurance SET insuranceName = '$insuranceName' where inID ='$id'";
	}else{
		if ($action=="delete"){
			$query = "UPDATE tblInsurance SET active='N' tblInsurance where inID='$id'";
		}else{
			$query = "INSERT INTO tblInsurance (insuranceName, active) VALUES ('$insuranceName', 'Y')";
		}
	}
	mysql_query($query) or die("Insurance has not been edited!");
}
function editCompany	($id, $companyName, $action){
	if ($action == "edit") {
		$query = "UPDATE tblCompany SET companyName = '$companyName' where companyID ='$id'";
	}else{
		if ($action=="delete"){
			$query = "UPDATE tblCompany SET active='N'  where companyID='$id'";
		}else{
			$query = "INSERT INTO tblCompany(companyName, active) VALUES ('$companyName', 'Y')";
		}
	}
	mysql_query($query) or die("Company has not been edited!");
}
function editDemographics($id, $firstName, $lastName, $dob, $action){
	if ($action == "edit") {
		$query = "UPDATE tblDemographics SET firstName = '$firstName', lastName = '$lastName', dob='$dob' where pid='$id'";
	}else{
		if ($action=="delete"){
			$query = "UPDATE tblDemographics  SET active='N' where pid='$id'";
		}else{
			$query = "INSERT INTO tblDemographics (firstName, lastName, dob, active) VALUES ('$firstName', '$lastName', '$dob', 'Y')";
		}
	}
	mysql_query($query) or die("Patient has not been edited!");
}
//-----------------------------------------------------------------
//-----------------------view assist modules-----------------------
function showPrograms(){
	$view = $_GET['view'];
	$tbl = $_GET['tbl'];
	$action = $_GET['action'];
	
	
	
	echo '<div class="viewTitle">SELECT VIEW:</label></div><div class="assistNav"><table class="assistTbl">';
	echo '<tr><td><a href="ViewAssist.php?view=patient&tbl=tblDemographics">Patient</td><td><a href="ViewAssist.php?view=company&tbl=tblCompany">Company</a></td><td><a href="ViewAssist.php?view=meds&tbl=tblMeds">Medication</a></td><td><a href="ViewAssist.php?view=doctor&tbl=tblMD">Doctor</a></td></tr>';
	echo '</table></div>';
	if ($view==''){	
	}else{
		echo '<div class="viewTitle">' . strtoupper($view) . ' VIEW </Div>';
	}
	
	switch ($action){
		case "edit":
				
				$assistID 				= strtoupper(mysql_real_escape_string ($_GET['assistID']));
				$assistDate 			= strtoupper(mysql_real_escape_string ($_GET['assistDate']));
				$company 				= strtoupper(mysql_real_escape_string ($_GET['company']));
				$medicine 				= strtoupper(mysql_real_escape_string ($_GET['medicine']));
				$doctor 				= strtoupper(mysql_real_escape_string ($_GET['doctor']));
				$insurance 				= strtoupper(mysql_real_escape_string ($_GET['insurance']));
				$assistDose 			= strtoupper(mysql_real_escape_string ($_GET['assistDose']));
				$assistQty 				= strtoupper(mysql_real_escape_string ($_GET['assistQty']));
				$assistDateReceived 	= strtoupper(mysql_real_escape_string ($_GET['assistDateReceived']));
				$assistCost 			= strtoupper(mysql_real_escape_string ($_GET['assistCost']));
				$assistComments 		= strtoupper(mysql_real_escape_string ($_GET['assistComments']));
				$medType		 		= strtoupper(mysql_real_escape_string ($_GET['oralOrInfs']));
				
				$id = $_GET['id'];
				updateAssist($view, $id, $assistID, $assistDate, $company, $medicine, $doctor, $insurance, $assistDose, $assistQty, $assistDateReceived, $assistCost, $assistComments, $action, $medType);
				showInformation('Assistance Updated', 'Your record has been updated!');
				showAssistOnPageLoad($assistID, $id);
				$id = "";			
			break;
		case "copy":
				$assistID 				= strtoupper(mysql_real_escape_string ($_GET['assistID']));
				showAssistOnPageLoad($assistID, $id);
			break;
		
	}
	
	//get unique views
	switch ($view) {
		case "patient":
			$query = "SELECT distinct(tblAssistance.pid), tblDemographics.firstName, tblDemographics.lastName from tblAssistance inner join tblDemographics on tblDemographics.pid = tblAssistance.pid order by lastName asc";
			$result = mysql_query($query) or die(mysql_error());
			while($row = mysql_fetch_array($result))
			{
				$id			= $row['pid'];
				$firstName 	= $row['firstName'];
				$lastName 	= $row['lastName'];
				$title = $firstName . ' ' . $lastName;
				buildAssistTblHeader($id, $title, $view, 'popup', $id .'Div');
				buildDataDiv($id .'Div', $id, $view, 'tblAssistance.pid', '');
			}
			break;
		case "company":
			$query = "SELECT distinct(tblAssistance.companyID), tblCompany.companyName from tblAssistance inner join tblCompany on tblCompany.companyID = tblAssistance.companyID order by companyName asc";
			$result = mysql_query($query) or die(mysql_error());
			while($row = mysql_fetch_array($result))
			{
				$id				= $row['companyID'];
				$companyName 	= $row['companyName'];
				buildAssistTblHeader($id, $companyName, $view, 'popup', $id .'Div');
				buildDataDiv($id .'Div', $id, $view, 'tblAssistance.companyID', '');
			}
			break;
		case "meds":
			$query = "SELECT distinct(tblAssistance.medID), tblMeds.Medicine from tblAssistance inner join tblMeds on tblMeds.medID = tblAssistance.medID order by medicine asc";
			$result = mysql_query($query) or die(mysql_error());
			while($row = mysql_fetch_array($result))
			{
				$id				= $row['medID'];
				$companyName 	= $row['Medicine'];
				buildAssistTblHeader($id, $companyName, $view, 'popup', $id .'Div');
				buildDataDiv($id .'Div', $id, $view, 'tblAssistance.MedID', '');
			}
			break;
		case "doctor":
			$query = "SELECT distinct(tblAssistance.mdID), tblMD.firstname, tblMD.lastname from tblAssistance inner join tblMD on tblMD.mdID = tblAssistance.mdID order by lastname asc";
			$result = mysql_query($query) or die(mysql_error());
			while($row = mysql_fetch_array($result))
			{
				$id				= $row['mdID'];
				$lName 			= $row['lastname'];
				$fName 			= $row['firstname'];
				buildAssistTblHeader($id, $fName . ' ' . $lName, $view, 'popup', $id .'Div');
				buildDataDiv($id .'Div', $id, $view, 'tblAssistance.mdID', '');
			}
			break;
	}

			
}
function searchForIt($search){
	//search patients
		echo '<div class="viewTitle">Patient Results</Div>';
		$query = "select * from tblDemographics where firstname like '%$search%' or lastname like '%$search%'";
		$result = mysql_query($query) or die(mysql_error());
		if (mysql_num_rows($result)>0){
			echo '<b><i>' . mysql_num_rows($result) . ' results found...</b></i>';
			while($row = mysql_fetch_array($result))
			{
				$id			= $row['pID'];
				$firstName 	= $row['firstName'];
				$lastName 	= $row['lastName'];
				$title = $firstName . ' ' . $lastName;
				buildAssistTblHeader($id, $title, 'patient', 'popup', 'p' . $id);
				buildDataDiv('p' . $id, $id, 'patient', 'tblAssistance.pid', '');
			}
		}else{
			echo "<b><i>0 results found...</b></i>";
		}
	//search dr's
		echo '<div class="viewTitle">Doctor Results</Div>';
		$query = "select * from tblMD where firstname like '%$search%' or lastname like '%$search%'";
		$result = mysql_query($query) or die(mysql_error());
		if (mysql_num_rows($result)>0){
			echo '<b><i>' . mysql_num_rows($result) . ' results found...</b></i>';
			while($row = mysql_fetch_array($result))
			{
				$id				= $row['mdID'];
				$lName 			= $row['lastName'];
				$fName 			= $row['firstName'];
				buildAssistTblHeader($id, $fName . ' ' . $lName, 'doctor', 'popup', 'dr' . $id);
				buildDataDiv('dr' . $id, $id, 'doctor', 'tblAssistance.mdID', '');
			}
		}else{
			echo "<b><i>0 results found...</b></i>";
		}
	//search companys
		echo '<div class="viewTitle">Company Results</Div>';
		$query = "select * from tblCompany where companyName like '%$search%'";
		$result = mysql_query($query) or die(mysql_error());
		if (mysql_num_rows($result)>0){
			echo '<b><i>' . mysql_num_rows($result) . ' results found...</b></i>';
			while($row = mysql_fetch_array($result))
			{
				$id				= $row['companyID'];
				$companyName 	= $row['companyName'];
				buildAssistTblHeader($id, $companyName, 'company', 'popup', 'c' . $id);
				buildDataDiv('c' . $id, $id, 'company', 'tblAssistance.companyID', '');
			}
		}else{
			echo "<b><i>0 results found...</b></i>";
		}
	//search meds
			echo '<div class="viewTitle">Medicine Results</Div>';
			$query = "select * from tblMeds where Medicine like '%$search%'";
			$result = mysql_query($query) or die(mysql_error());
		if (mysql_num_rows($result)>0){
			echo '<b><i>' . mysql_num_rows($result) . ' results found...</b></i>';
			while($row = mysql_fetch_array($result))
			{
				$id				= $row['medID'];
				$medName     	= $row['Medicine'];
				buildAssistTblHeader($id, $medName, 'medicine', 'popup', 'm' . $id);
				buildDataDiv('m' . $id, $id, 'medicine', 'tblAssistance.medID', '');
			}
		}else{
			echo "<b><i>0 results found...</b></i>";
		}	
}
function showAssistOnPageLoad($assistID, $divID){
		echo '<script>    $(document).ready(function(){';
		echo  '$(editAssist' . $assistID . '' . $divID . 'Div).slideDown("fast")' . Chr("59") . ' ';
		echo  '$(slideid'.$divID.'Div).slideDown("fast")' . Chr("59") . ' ';
		echo  '})' . Chr("59") . ' ';
		echo '</script>';
}
function updateAssist($view, $id, $assistID, $assistDate, $company, $medicine, $doctor, $insurance, $assistDose, $assistQty, $assistDateReceived, $assistCost, $assistComments, $action, $oralOrInfs){
	

	if ($action == "edit") {
		$query = "UPDATE tblAssistance SET  medType='$oralOrInfs', companyID= '$company', mdID = '$doctor', medID = '$medicine', dose = '$assistDose', qty = '$assistQty', dateReceived = '$assistDateReceived', date = '$assistDate', inID = '$insurance', cost = '$assistCost', comments = '$assistComments' where assistID='$assistID'";		
	}else{
		if ($action=="delete"){
			$query = "DELETE FROM tblAssistance WHERE assistID='$assistID'";
		}
	}
	mysql_query($query) or die("User has not been edited!");
}
function buildAssistTblHeader($id, $title, $view, $action, $divName){
	echo '<div class="assistHeaderDiv" id="' . $divName . '"><label class="titleLink">' .  $title . '</label>';
		if ($view=='patient'){
			echo '<div class="addAssistanceDiv"><a href="EnterProgramData.php?id=' . $id .'" class="titleLink"><img src="img/add.png" class="icon">Add Assitance</a></div>';
		}
	echo '</div>';
	flush();
	ob_flush();
}
function buildDataDiv($divID, $id, $view, $whrFld, $search){
	echo '<div id="slideid' . $divID . '" class="slideDiv" name="slideMe">';
		echo "";
		echo '<script>';
		echo "";
		echo '     $("#' . $divID . '").click(function () {';
		echo  '$(slideid' . $divID .').slideToggle("fast")' . Chr("59") . ' ';
		echo  '})' . Chr("59") . ' ';
		echo "";
		echo '</script>';
		echo "";
		if ($view=='patient'){
			echo '<div><a href="EnterProgramData.php?id=' . $id .'"><img src="img/add.png" class="LrgIcon">Add Assitance</a><br></div>';
		}
			echo '<br><table class="dataDiv">';
			echo '<tr><th colspan="3">Action</th><th>Date</th><th>Company</th><th>Medicine</th><th>Dose</th><th>Qty</th><th>Doctor</th><th>Cost</th><th>Insurance</th><th>O/I</th></tr>';
			$query = 'SELECT tblDemographics.firstName as fName, tblDemographics.lastName as lName, tblAssistance.assistID, tblCompany.companyName, tblMeds.Medicine, tblAssistance.dose, tblAssistance.qty, tblMD.firstName, tblMD.lastName, tblAssistance.dateReceived, tblAssistance.date, tblAssistance.cost, tblInsurance.insuranceName, tblAssistance.comments, tblAssistance.medType ';
			$query = $query . ' FROM tblAssistance ';
			$query = $query . ' INNER JOIN tblCompany on tblCompany.companyID = tblAssistance.companyID';
			$query = $query . ' INNER JOIN tblDemographics on tblDemographics.pid = tblAssistance.pID';
			$query = $query . ' INNER JOIN tblMeds on tblMeds.medID = tblAssistance.medID';
			$query = $query . ' INNER JOIN tblMD on tblMD.mdID = tblAssistance.mdID';
			$query = $query . ' INNER JOIN tblInsurance on tblInsurance.inID = tblAssistance.inID';
			$query = $query . ' WHERE '. $whrFld . '=' . $id . ' ';

			//echo '<br>' . $query . '<br>';
			$result = mysql_query($query) or die(mysql_error());
			while($row = mysql_fetch_array($result))
			{
			    
				echo "<tr>";
					//echo '<td><a href="ViewAssist.php?view=' . $view . '&id=' . $row['assistID'] . '&action=edit"><img src="img/edit.png" class="icon"></a>&nbsp;&nbsp;<a href="ViewAssist.php?view=' . $view . '&id=' . $row['assistID'] . '&action=delete"><img src="img/delete.jpg" class="icon"></a></td>';
					echo '<td><div id="editDiv' . $row['assistID'] . '"><img src="img/edit.png" class="icon"></div></td><td><a href="ViewAssist.php?id=' . $id . '&assistid=' . $row['assistID'] . '$action=copy&delete=true"><img src="img/delete.jpg" class="icon"></a>';
					echo '<td><a href="ViewAssist.php?id=' . $row['assistID'] . '&copyit=true"><img src="img/copy.png" class="icon"></a></td>';
					echo '<td nowrap="nowrap">' . $row['date'] . '</td>';
					echo '<td nowrap="nowrap">' . $row['companyName'] . '</td>';
					echo '<td nowrap="nowrap">' . $row['Medicine'] . '</td>';
					echo '<td nowrap="nowrap">' . $row['dose'] . '</td>';
					echo '<td nowrap="nowrap">' . $row['qty'] . '</td>';
					echo '<td nowrap="nowrap">' . $row['firstName'] . ' ' . $row['lastName'] . '</td>';
//					echo '<td>' . $row['dateReceived'] . '</td>';
					echo '<td nowrap="nowrap">' . $row['cost'] . '</td>';
					echo '<td nowrap="nowrap">' . $row['insuranceName'] . '</td>';
					echo '<td nowrap="nowrap">' . $row['medType'] . '</td>';
				echo "</tr>";
				echo "<tr>";
					echo '<td colspan="15">';
						echo '<div id="editAssist' . $row['assistID'] . '' . $divID . '" class="slideForm">';
							echo '<script>     $("#editDiv' . $row['assistID'] . '").click(function () {';
								echo  '$(editAssist' . $row['assistID'] . '' . $divID .').slideToggle("fast")' . Chr("59") . ' ';
								echo  '})' . Chr("59") . ' ';
							echo "</script>";
								echo '<form action="ViewAssist.php" method="GET">';
										echo '<table class="editDataDiv">';
											echo '<tr><td colspan=2><label class="lblHeader">Edit Data</label></td></tr>';
											echo '<tr><td><label class="lblForm">First Name:</label></td>	 <td><label class="txtForm">' . $row['fName'] . '</label></td></tr>';
											echo '<tr><td><label class="lblForm">Last Name:</label></td>	 <td><label class="txtForm">' . $row['lName'] . '</label></td></tr>';
											echo '<tr><td><label class="lblForm">Date:</label></td>			 <td><input type="text" name="assistDate" id="" class="txtForm" value="' . $row['date'] . '"></td></tr>';
											 	if ($row['medType'] == 'O'){$oCheck = "checked";}
				  								if ($row['medType'] == 'I'){$iCheck = "checked";}
                  						    echo '<tr><td colspan="2">
                  																			<center><fieldset class="fsForm">
																							   <legend class="lblForm">Oral/Infusion</legend>
																								<input type="radio" name="oralOrInfs" value="O" ' . $oCheck . '>Oral
																								<input type="radio" name="oralOrInfs" value="I" ' . $iCheck . '>Infusion
																							</fieldset></center><br>
                  						    </td>';
                  						    $iCheck = "";
                  						    $oCheck = "";
											echo '<tr><td><label class="lblForm">Company:</label></td>		 <td>';
														populateDropDown('company', 'tblCompany', 'companyName', 'companyID', 'ddForm', $row['companyName']);
											echo '</td></tr>';
											echo '<tr><td><label class="lblForm">Medicine:</label></td>		 <td>';
                        								populateDropDown('medicine', 'tblMeds', 'medicine', 'medID', 'ddForm', $row['Medicine']);											
											echo '</td></tr>';
											echo '<tr><td><label class="lblForm">Dose:</label></td>			 <td><input type="text" name="assistDose" id="" class="txtForm" value="' . $row['dose'] . '"></td></tr>';
											echo '<tr><td><label class="lblForm">Qty:</label></td>			 <td><input type="text" name="assistQty" id="" class="txtForm" value="' . $row['qty'] . '"></td></tr>';
											echo '<tr><td><label class="lblForm">Doctor:</label></td>		 <td>';
														populateDropDown('doctor', 'tblMD', 'lastName', 'mdID', 'ddForm', $row['lastName']);
											echo '</td></tr>';
											echo '<tr><td><label class="lblForm">Date Received:</label></td> <td><input type="text" name="assistDateReceived" id="" class="txtForm" value="' . $row['dateReceived'] . '"></td></tr>';
											echo '<tr><td><label class="lblForm">Cost:</label></td>			 <td><input type="text" name="assistCost" id="" class="txtForm" value="' . $row['cost'] . '"></td></tr>';
											echo '<tr><td><label class="lblForm">Insurance:</label></td>	 <td>';
														populateDropDown('insurance', 'tblInsurance', 'insuranceName', 'inID', 'ddForm', $row['insuranceName']);
											echo '</td></tr>';
											echo '<tr><td><label class="lblForm">Comments:</label></td>		 <td><textarea name="assistComments" id="" class="txtAreaForm" rows="4">' . $row['comments'] . '</textarea></td></tr>';	
											echo '<tr><td></td><td><input type="submit" value="Edit" class="btnForm"></td></tr>'; 											
									echo "</table>";	
									echo '<input type="hidden" name="id" value="'.$id.'"><input type="hidden" name="view" value="'.$view.'"><input type="hidden" name="action" value="edit"><input type="hidden" name="assistID" value="' . $row['assistID'] . '">';															
								echo "</form>";
						echo "</div>";
					echo "</td>";
				echo "</tr>";
				flush();
				ob_flush();
			}
			echo '</table>';
		
		
	echo '</div>';

}
function deleteAssistance($id){
	$query = "delete from tblAssistance where assistID = '$id'";
	//echo $query;
	mysql_query($query) or die(mysql_error());
	showInformation("Deleted", "The assistance data has been deleted!");
}
function copyAssistance($id){
	$query = "select * from tblAssistance where assistID = '$id'";
	$result = mysql_query($query) or die(mysql_error());
		while($row = mysql_fetch_array($result))
		{
			$company = $row['companyID'];
			$doctor = $row['mdID'];
			$medicine = $row['medID'];
			$assistDose = $row['dose'];
			$assistQty = $row['qty'];
			$assistDateReceived = $row['dateReceived'];
			$assistDate = $row['date'];
			$insurance = $row['inID'];
			$assistCost = $row['cost'];
			$assistComments = $row['comments'];
			$patient = $row['pID'];
		}
	enterProgramDataQuery($patient, '1', $assistDate, $company, $doctor, $insurance, $medicine, $assistDose, $assistQty, $assistDateReceived, $assistCost, $assistComments);
	showInformation("Copied", "The assistance data has been copied!");
}
//---------------------------------------------------------


//------------------------------------------------------------------
//------------------reports ----------------------------------------
function buildReports(){
	$query = "SELECT COUNT(tblAssistance.assistID) as total, tblCompany.companyName FROM tblAssistance INNER JOIN tblCompany ON tblCompany.companyID = tblAssistance.companyID GROUP BY companyName ORDER BY companyName ASC";
	pieGraphCount('Total By Company', 'countByCompany', $query, 'companyName');
	$query = "SELECT COUNT(tblAssistance.assistID) as total, tblMeds.Medicine FROM tblAssistance INNER JOIN tblMeds ON tblMeds.medID = tblAssistance.medID GROUP BY Medicine ORDER BY Medicine ASC";
	pieGraphCount('Total By Medicine', 'countByMed', $query, 'Medicine');
	$query = "SELECT COUNT(tblAssistance.assistID) as total, tblMD.lastName FROM tblAssistance INNER JOIN tblMD ON tblMD.mdID = tblAssistance.mdID GROUP BY lastName ORDER BY lastName ASC";
	pieGraphCount('Total By Doctor', 'countByMd', $query, 'lastName');
	flush();
	ob_flush();
	$query = "SELECT COUNT(tblAssistance.assistID) as total, tblInsurance.inID, tblInsurance.insuranceName FROM tblAssistance INNER JOIN tblInsurance ON tblInsurance.inID = tblAssistance.inID GROUP BY insuranceName ORDER BY insuranceName ASC";
	pieGraphCount('Total By Insurance', 'countByInsurance', $query, 'insuranceName');
	$query = "select count(tblAssistance.date), tblAssistance.date, tblCompany.companyName from tblAssistance INNER JOIN tblCompany on tblCompany.companyID = tblAssistance.companyID group by date order by date asc";
	$dateQuery = "select distinct(date) from tblAssistance order by date asc";
	flush();
	ob_flush();
					
	lineGraphNumPatients('Number of Patients', 'patientsByDate');
	lineGraphCosts('Dollar Amt By Month', 'dollarByMonth');
	lineGraphMedType('Dollar Amt By Month By Med Type', 'dollarMedType');
	
	echo '<div id="graphs" class="graphDiv" name="graphDiv"><table>';
		echo '<tr>';
			echo '<td>';
				echo '<div id="countByInsurance" 		class="pieChartS"></div>';
				echo '<div id="tblCountByInsurance" 	class="rptDataDiv">';
					$qry =  "SELECT COUNT(tblAssistance.assistID) as total, tblInsurance.inID, tblInsurance.insuranceName FROM tblAssistance INNER JOIN tblInsurance ON tblInsurance.inID = tblAssistance.inID GROUP BY insuranceName ORDER BY insuranceName ASC";
					showRptTable($qry, "insuranceName", "Insurance Name");
					flush();
					ob_flush();
				echo '</div>';
			echo '</td>';
			echo '<td>';	
				echo '<div id="countByMd" 		class="pieChartS"></div>';
				echo '<div id="tblCountByDr" 	class="rptDataDiv">';
					$qry = "SELECT COUNT(tblAssistance.assistID) as total, tblMD.lastName FROM tblAssistance INNER JOIN tblMD ON tblMD.mdID = tblAssistance.mdID GROUP BY lastName ORDER BY lastName ASC";
					showRptTable($qry, "lastName", "Doctor Name");
					flush();
					ob_flush();
				echo '</div>';
			echo '</td>';
			echo '<td>';
			echo '</td>';
		echo '</tr>';
		echo '<tr>';
			echo '<td>';
				echo '<div id="countByInsBtn" class="showBtn"><center>Show/Hide Data</center></div>';				
			echo '</td>';
			echo '<td>';
				echo '<div id="countByDrBtn" class="showBtn"><center>Show/Hide Data</center></div>';
			echo '</td>';			
		echo '</tr>';
		echo '</tr>';
			echo '<td colspan=3>';
				echo '<div id="dollarMedType" class="lineChart"></div>';
			echo '</td>';
		echo '</tr>';		
		echo '<tr>';
			echo '<td colspan=3>';
				echo '<div id="dollarByMonth" class="lineChart"></div>';
			echo '</td>';
		echo '</tr>';
			echo '<td colspan=3>';
				echo '<div id="patientsByDate" class="lineChart"></div>';
			echo '</td>';
		echo '</tr>';
		echo '<tr>';
			echo '<td colspan=3>';
				echo '<div id="countByMed" class="pieChartL"></div>';
				echo '<div id="tblCountByMed" 	class="rptDataDiv">';
					$qry = "SELECT COUNT(tblAssistance.assistID) as total, tblMeds.Medicine FROM tblAssistance INNER JOIN tblMeds ON tblMeds.medID = tblAssistance.medID GROUP BY Medicine ORDER BY Medicine ASC";
					showRptTable($qry, "Medicine", "Medicine Name");
					flush();
					ob_flush();
				echo '</div>';
			echo '</td>';
		echo '</tr>';
		echo '<tr>';
			echo '<td colspan=3>';
				echo '<div id="countByMedBtn" class="showBtn"><center>Show/Hide Data</center></div>';								
			echo '</td>';
		echo '</tr>';
		echo '<tr>';
			echo '<td colspan=3>';
				echo '<div id="countByCompany" class="pieChartL"></div>';
				echo '<div id="tblCountByComp" 	class="rptDataDiv">';
					$qry = "select count(tblAssistance.date) as total, tblAssistance.date, tblCompany.companyName from tblAssistance INNER JOIN tblCompany on tblCompany.companyID = tblAssistance.companyID group by date order by date asc";
					showRptTable($qry, "companyName", "Company Name");
					flush();
					ob_flush();
				echo '</div>';
			echo '</td>';
		echo '</tr>';
		echo '<tr>';
			echo '<td colspan=3>';
				echo '<div id="countByCompBtn" class="showBtn"><center>Show/Hide Data</center></div>';				
			echo '</td>';
		echo '</tr>';	
	echo '</table></div>';
				
}
function showRptTable($qry, $fldToDisplay, $heading){
	echo "<table class=rptData>";
	  echo "<tr>";
		echo "<th class=rptDataHead>";
			echo $heading;
		echo "</th>";
		echo "<th class=rptDataHead>Qty</th>";
	  echo "</tr>";
		$result = mysql_query($qry) or die(mysql_error());
    	while($row = mysql_fetch_array($result))
    	{
    		echo "<tr>";
    		  echo "<td class=rptData>";
    			echo $row[$fldToDisplay];
    		  echo "</td>";
    		  echo "<td class=rptData>";
    			echo $row['total'];
    		  echo "</td>";
    		echo "</tr>";    			
    	}
    echo "</table>";
}
function pieGraphCount($chartName, $container, $queryT, $fld){
echo <<< END
<script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: '$container',
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: true,
                borderWidth: 2,
                backgroundColor: "#F3F4F2"
            },
            title: {
                text: '$chartName'
            },
            tooltip: {
                formatter: function() {
                    return '<b>'+ this.point.name + '</b>: '+ this.percentage +' %';
                }
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: true,
                        color: '#000000',
                        connectorColor: '#000000',
                        formatter: function() {
                            return '<b>'+ this.point.name;
                        }
                    }
                }
            },
            series: [{
                type: 'pie',
                name: 'Company',
                data: [
END;
			
			$query = "SELECT COUNT(assistID) as tot from tblAssistance";
			$result = mysql_query($query) or die(mysql_error());
			while($row = mysql_fetch_array($result))
			{
				$AllAssistance = $row['tot'];
			}

			                    
			$result = mysql_query($queryT) or die(mysql_error());
			while($row = mysql_fetch_array($result))
			{	
				$datastring = $datastring . "['";
				$datastring = $datastring . $row[$fld];
				$datastring = $datastring . "', ";
				$datastring = $datastring . round(($row['total'] / $AllAssistance) * 100, 0);
				$datastring = $datastring . "], " . chr(13);	
			}
	echo substr($datastring,0,-3);
	echo '		     
                    ]
            }]
        });
    });
    
});
		</script>	
';

}
function lineGraphMedType($chrtName, $container){
echo <<<END
<script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: '$container',
                type: 'line',
                marginRight: 130,
                marginBottom: 25,
                borderWidth: 2,
                backgroundColor: "#F3F4F2",
                animation: true
            },
            title: {
                text: '$chrtName',
                x: -20 //center
            },
            subtitle: {
                text: 'Line Graph',
                x: -20
            },
            xAxis: {			
                categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
            },
            yAxis: {
                title: {
                    text: 'Cost By Month by Med Type'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                formatter: function() {
                        return '<b>'+ this.series.name +'</b><br/>'+
                        this.x +': '+ '$' + this.y +'';
                }
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'top',
                x: -10,
                y: 100,
                borderWidth: 1,
                backgroundColor: "#ffffff"
            },
            series: [{
END;
			$yearQuery = "SELECT DISTINCT(year(date)) as yr from tblAssistance";
			$result = mysql_query($yearQuery) or die(mysql_error());
			$i = 0;
			while($row = mysql_fetch_array($result))
			{
				$years[$i] = $row['yr'];
				$i = $i + 1;
			}
			$seriesData = "";
			foreach ($years as $yr) {
    			$seriesData = $seriesData . "name: 'Oral $yr',";
    			$seriesData = $seriesData . "data: [";
    			$seriesData = $seriesData . getMonthCostValueMedType('01','02',$yr, 'O');
    			$seriesData = $seriesData . getMonthCostValueMedType('02','03',$yr, 'O');
    			$seriesData = $seriesData . getMonthCostValueMedType('03','04',$yr, 'O');
    			$seriesData = $seriesData . getMonthCostValueMedType('04','05',$yr, 'O');
    			$seriesData = $seriesData . getMonthCostValueMedType('05','06',$yr, 'O');
    			$seriesData = $seriesData . getMonthCostValueMedType('06','07',$yr, 'O');
    			$seriesData = $seriesData . getMonthCostValueMedType('07','08',$yr, 'O');
    			$seriesData = $seriesData . getMonthCostValueMedType('08','09',$yr, 'O');
    			$seriesData = $seriesData . getMonthCostValueMedType('09','10',$yr, 'O');
    			$seriesData = $seriesData . getMonthCostValueMedType('10','11',$yr, 'O');
    			$seriesData = $seriesData . getMonthCostValueMedType('11','12',$yr, 'O');
    			$seriesData = $seriesData . getMonthCostValueMedType('12','12',$yr, 'O');
    			$seriesData = $seriesData . "}, {";
						
    			$seriesData = $seriesData . "name: 'Infusion $yr',";
    			$seriesData = $seriesData . "data: [";
    			$seriesData = $seriesData . getMonthCostValueMedType('01','02',$yr, 'I');
    			$seriesData = $seriesData . getMonthCostValueMedType('02','03',$yr, 'I');
    			$seriesData = $seriesData . getMonthCostValueMedType('03','04',$yr, 'I');
    			$seriesData = $seriesData . getMonthCostValueMedType('04','05',$yr, 'I');
    			$seriesData = $seriesData . getMonthCostValueMedType('05','06',$yr, 'I');
    			$seriesData = $seriesData . getMonthCostValueMedType('06','07',$yr, 'I');
    			$seriesData = $seriesData . getMonthCostValueMedType('07','08',$yr, 'I');
    			$seriesData = $seriesData . getMonthCostValueMedType('08','09',$yr, 'I');
    			$seriesData = $seriesData . getMonthCostValueMedType('09','10',$yr, 'I');
    			$seriesData = $seriesData . getMonthCostValueMedType('10','11',$yr, 'I');
    			$seriesData = $seriesData . getMonthCostValueMedType('11','12',$yr, 'I');
    			$seriesData = $seriesData . getMonthCostValueMedType('12','12',$yr, 'I');
    			$seriesData = $seriesData . "}, {";
    			
			}
			$seriesData = substr($seriesData, 0, -4);			
			echo $seriesData;
           	echo " }]
        });
    });
    
});
		</script>";

}
function lineGraphCosts($chrtName, $container){
echo <<<END
<script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: '$container',
                type: 'line',
                marginRight: 130,
                marginBottom: 25,
                borderWidth: 2,
                backgroundColor: "#F3F4F2",
                animation: true
            },
            title: {
                text: '$chrtName',
                x: -20 //center
            },
            subtitle: {
                text: 'Line Graph',
                x: -20
            },
            xAxis: {			
                categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
            },
            yAxis: {
                title: {
                    text: 'Cost By Month'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                formatter: function() {
                        return '<b>'+ this.series.name +'</b><br/>'+
                        this.x +': '+ '$' + this.y +'';
                }
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'top',
                x: -10,
                y: 100,
                borderWidth: 1,
                backgroundColor: "#ffffff"
            },
            series: [{
END;
			$yearQuery = "SELECT DISTINCT(year(date)) as yr from tblAssistance";
			$result = mysql_query($yearQuery) or die(mysql_error());
			$i = 0;
			while($row = mysql_fetch_array($result))
			{
				$years[$i] = $row['yr'];
				$i = $i + 1;
			}
			$seriesData = "";
			foreach ($years as $yr) {
    			$seriesData = $seriesData . "name: '$yr',";
    			$seriesData = $seriesData . "data: [";
    			$seriesData = $seriesData . getMonthCostValue('01','02',$yr);
    			$seriesData = $seriesData . getMonthCostValue('02','03',$yr);
    			$seriesData = $seriesData . getMonthCostValue('03','04',$yr);
    			$seriesData = $seriesData . getMonthCostValue('04','05',$yr);
    			$seriesData = $seriesData . getMonthCostValue('05','06',$yr);
    			$seriesData = $seriesData . getMonthCostValue('06','07',$yr);
    			$seriesData = $seriesData . getMonthCostValue('07','08',$yr);
    			$seriesData = $seriesData . getMonthCostValue('08','09',$yr);
    			$seriesData = $seriesData . getMonthCostValue('09','10',$yr);
    			$seriesData = $seriesData . getMonthCostValue('10','11',$yr);
    			$seriesData = $seriesData . getMonthCostValue('11','12',$yr);
    			$seriesData = $seriesData . getMonthCostValue('12','12',$yr);
    			$seriesData = $seriesData . "}, {";
			}
			$seriesData = substr($seriesData, 0, -4);
			
			echo $seriesData;
           echo " }]
        });
    });
    
});
		</script>";

}
function lineGraphNumPatients($chrtName, $container){

echo <<<END
<script type="text/javascript">
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: '$container',
                type: 'line',
                marginRight: 130,
                marginBottom: 25,
                borderWidth: 2,
                backgroundColor: "#F3F4F2"
            },
            title: {
                text: '$chrtName',
                x: -20 //center
            },
            subtitle: {
                text: 'Line Graph',
                x: -20
            },
            xAxis: {			
                categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
            },
            yAxis: {
                title: {
                    text: '# of Patients'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                formatter: function() {
                        return '<b>'+ this.series.name +'</b><br/>'+
                        this.x +': '+ this.y +'';
                }
            },
            legend: {
                layout: 'vertical',
                align: 'right',
                verticalAlign: 'top',
                x: -10,
                y: 100,
                borderWidth: 1,
                backgroundColor: "#ffffff"
            },
            series: [{
END;
			$yearQuery = "SELECT DISTINCT(year(date)) as yr from tblAssistance";
			$result = mysql_query($yearQuery) or die(mysql_error());
			$i = 0;
			while($row = mysql_fetch_array($result))
			{
				$years[$i] = $row['yr'];
				$i = $i + 1;
			}
			$seriesData = "";
			foreach ($years as $yr) {
    			$seriesData = $seriesData . "name: '$yr',";
    			$seriesData = $seriesData . "data: [";
    			$seriesData = $seriesData . getMonthValue('1','2',$yr);
    			$seriesData = $seriesData . getMonthValue('2','3',$yr);
    			$seriesData = $seriesData . getMonthValue('3','4',$yr);
    			$seriesData = $seriesData . getMonthValue('4','5',$yr);
    			$seriesData = $seriesData . getMonthValue('5','6',$yr);
    			$seriesData = $seriesData . getMonthValue('6','7',$yr);
    			$seriesData = $seriesData . getMonthValue('7','8',$yr);
    			$seriesData = $seriesData . getMonthValue('8','9',$yr);
    			$seriesData = $seriesData . getMonthValue('9','10',$yr);
    			$seriesData = $seriesData . getMonthValue('10','11',$yr);
    			$seriesData = $seriesData . getMonthValue('11','12',$yr);
    			$seriesData = $seriesData . getMonthValue('12','12',$yr);
    			$seriesData = $seriesData . "}, {";
			}
			$seriesData = substr($seriesData, 0, -4);
			
			echo $seriesData;
           echo " }]
        });
    });
    
});
		</script>";

}
function getMonthValue($m1, $m2, $yr){
	$total = "";
	if ($m1 == '12'){
		$query = "select count(assistID) as total from tblAssistance where date > '$yr-$m1-1' AND date < '$yr-$m1-31'";
	$result = mysql_query($query) or die(mysql_error());
    	while($row = mysql_fetch_array($result))
    	{
    		$total = $row['total'] . ']';    			
    	}
	}else{
		$query = "select count(assistID) as total from tblAssistance where date > '$yr-$m1-1' AND date < '$yr-$m2-1'";
		$result = mysql_query($query) or die(mysql_error());
    	while($row = mysql_fetch_array($result))
    	{
    		$total =  $row['total'] .', ';    			
    	}
	}
    return $total;
}
function getMonthCostValue($m1, $m2, $yr){
	$total = "";
	if ($m1 == '12'){
		$query = "select sum(cost) as total from tblAssistance where date > '$yr-$m1-1' AND date < '$yr-$m1-31'";
		$result = mysql_query($query) or die(mysql_error());
    	while($row = mysql_fetch_array($result))
    	{
    		if ($row['total'] < 1){
				$total = '0 ]';
			}else{
    			$total = $row['total'] . ']';
			}
    		    			
    	}
	}else{
		$query = "select sum(cost) as total from tblAssistance where date > '$yr-$m1-1' AND date < '$yr-$m2-1'";
		$result = mysql_query($query) or die(mysql_error());
    	while($row = mysql_fetch_array($result))
    	{
    		if ($row['total'] < 1){
				$total = '0, ';
			}else{
    			$total = $row['total'] .', '; 
			} 			
    	}
	}
	
    return $total;
}
function getMonthCostValueMedType($m1, $m2, $yr, $mType){
	$total = "";
	if ($m1 == '12'){
		$query = "select sum(cost) as total, medType from tblAssistance where (date > '$yr-$m1-1' AND date < '$yr-$m1-31') and medType = '$mType'";
		$result = mysql_query($query) or die(mysql_error());
    	while($row = mysql_fetch_array($result))
    	{
    		if ($row['total'] > 1){
				$total = $row['total'] . ']';
			}else{
    			$total = '0 ]';					
			}	    			
    	}
	}else{
		$query = "select sum(cost) as total, medType  from tblAssistance where (date > '$yr-$m1-1' AND date < '$yr-$m2-1') and medType = '$mType'";
		$result = mysql_query($query) or die(mysql_error());
    	while($row = mysql_fetch_array($result))
    	{
    		if ($row['total'] > 1 ){
				$total = $row['total'] . ', ';
			}else{
    			$total = '0, ';
			} 			
    	}
	}
	
    return $total;
}
//--------backup and restore database---------
function showBUPForm(){
echo '<div class="smallDivContainer">';
      echo '<div class="smallDivTop"><div class="smallDivHeader"></div></div>';
       echo '<div class="smallDivMiddle">';
        echo '<div class="smallDivContent">';
                echo '<form action="backupandrestore.php" method="GET">';
                 echo '<table>';
                  echo '<tr><td colspan="4"><label class="lblHeader">Restore Data</label></td></tr>';
                  echo '<tr><td><label class="lblForm">File: </label></td> <td><input type="text" name="bfile"  class="txtForm"></td>';
                  echo '<tr><td><label class="lblForm">Table: </label></td> <td><input type="text" name="tbl"  class="txtForm"></td>';
                  echo '<tr><td></td><td><input type="submit" value="Restore" class="btnForm"></td></tr>';
                  echo '<input type="hidden" name="action" value="restore">';
                 echo '</table>';
                echo '</form>';
                echo '<form action="backupandrestore.php" method="GET">';
                 echo '<table>';
                  echo '<tr><td colspan="4"><label class="lblHeader">Back up data</label></td></tr>';
                  echo '<tr><td></td><td><input type="submit" value="Back up all" class="btnForm"></td></tr>';
                  echo '<input type="hidden" name="action" value="backup">';
                 echo '</table>';
                echo '</form>';
        echo '</div>';
       echo '</div>';
      echo '<div class="smallDivBottom"></div>';
     echo '</div>';	
}
function showRESForm(){
}
function backUpDB(){
	$tday  = date("Ymdhisu");
	
	$bfile = '/var/www/html/dbBackUps/tblUsers' . $tday . '.backup';
	bupQRY($bfile, 'tblUsers');
	$bfile = '/var/www/html/dbBackUps/tblAssistance' . $tday . '.backup';
	bupQRY($bfile, 'tblAssistance');
	$bfile = '/var/www/html/dbBackUps/tblCompany' . $tday . '.backup';
	bupQRY($bfile, 'tblCompany');
	$bfile = '/var/www/html/dbBackUps/tblDemographics' . $tday . '.backup';
	bupQRY($bfile, 'tblDemographics');
	$bfile = '/var/www/html/dbBackUps/tblMD' . $tday . '.backup';
	bupQRY($bfile, 'tblMD');
	$bfile = '/var/www/html/dbBackUps/tblMeds' . $tday . '.backup';
	bupQRY($bfile, 'tblMeds');
	$bfile = '/var/www/html/dbBackUps/tblInsurance' . $tday . '.backup';
	bupQRY($bfile, 'tblInsurance');
	$bfile = '/var/www/html/dbBackUps/tblComments' . $tday . '.backup';
	bupQRY($bfile, 'tblComments');
}
function bupQRY($bfile, $tbl){
	$query = "SELECT * INTO OUTFILE '$bfile' FROM $tbl";
	$result = mysql_query($query) or die(mysql_error());
	echo '<div class="assistHeaderDiv"><label class="titleLink">' . $tbl .' has been backed up to ' . $bfile . '!</label></div>';
}
function restore($bfile, $tbl){
	$query = "LOAD DATA INFILE '$bfile' INTO TABLE $tbl";
	$result  = mysql_query($query) or die(mysql_error());
	echo '<div class="assistHeaderDiv"><label class="titleLink">' . $tbl .' has been restored from ' . $bfile . '!</label></div>';
}


//------home page items------//
function tasks(){
	echo '<div>';
	  echo '<br><b><u><h3>Tasks/Comments</b></u></h3>';
		echo '<form action="" method="GET">';
			echo '<table class="dataDiv">';
				showComments();
			echo '</table>';
			echo '<table class="dataDiv">';
				EnterComments($pg);
			echo '</table>';
		echo '</form>';
	echo '</div>';
}
function EnterComments(){	
		echo '<form action="" method="GET">';	
			echo '<tr style="border: none;"><td style="border: none;"><label class="lblForm">Comment: </label></td> <td style="border: none;"><textarea name="txtComments"  class="txtAreaForm" style="width: 500px;"></textarea></td></tr>';
			echo '<input type="hidden" name="addComment" value="new">';
			echo '<tr style="border: none;"><td style="border: none;"></td><td style="border: none;"><input type="submit" value="Insert" class="btnForm"></td></tr>';
		echo '<form>';	
}
function showComments(){
				
	echo '<tr><th>Action</td><th>Comments/Tasks</td></tr>';
	
				
	$query = "SELECT * FROM tblComments WHERE (userName = '$userName' OR public = 'Y') and active = 'Y' order by id asc";
	$result = mysql_query($query) or die(mysql_error());
	while($row = mysql_fetch_array($result))
    {
    	echo '<tr>';
			echo '<td><a href="index.php?updateComment=' . $row['id'] . '"><img src="img/delete.jpg" class="icon"></a></td>';
			echo '<td>' . $row['comments'] . '<i>....' . $row['userName'] . '</i></td>';
		echo '</tr>';
    }
}

function deactivateComment($id){
	$query = "Update tblComments set active = 'N' WHERE (id = '$id')";
	$result = mysql_query($query) or die(mysql_error());
}
function insertComment($comments, $un){
	$query = "INSERT INTO tblComments (comments, userName, active, public) VALUES ('$comments', '$un', 'Y', 'Y')";
	$result = mysql_query($query) or die(mysql_error());
}
function floatComments(){
	echo '<div name="floatCommentHeader" class="floatCommentHeader"><b>Comments</b></div><div name="floatCommentsData" CLASS="floatCommentsData">';
		$updateID = $_GET['updateComment'];
		if ($updateID <> ''){deactivateComment($updateID);}
  		$addNew = $_GET['addComment'];
  		$txtToAdd = mysql_real_escape_string ($_GET['txtComments']);
  		$un = $_SESSION['un'];
		if ($addNew == 'new'){insertComment($txtToAdd, $un);}
		tasks();
	echo '</div>';
		
		
}






?>









