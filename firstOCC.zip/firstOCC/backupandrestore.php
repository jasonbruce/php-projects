<?php 

include 'header.php';
 include 'modules.php';
 	if ($_SESSION['loggedin'] == "true"){
  	 	include 'navimenu.php';
 		include 'adminMenu.php';
 		searchBar('');

 		$action = $_GET['action'];
 		if ($action == 'backup'){
 			backUpDB();
 		}else{
	 		if ($action == 'restore'){
	 			$bfile = $_GET['bfile'];
				$tbl = $_GET['tbl'];
	 			restore($bfile, $tbl);
	 		}else{
	 			showBUPForm();
	 			showRESForm();
	 		}
 		}
 	}




?>