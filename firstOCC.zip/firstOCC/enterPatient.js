		$(document).ready(function(){	
			$("#fn").focusin(function(){
              $("#fn").css("border","1px solid blue");
              $("#fn").animate({width:"295px"},"slow")
            });
            $("#fn").focusout(function(){
              $("#fn").css("border", "1px solid #0e8c7a");
              $("#fn").animate({width:"200px"},"slow")
              if (document.getElementById("fn").value==""){
              	$("#fNameError").slideDown("fast");
              }else{
              	$("#fNameError").slideUp("fast");
              }
            });
            $("#ln").focusin(function(){
              $("#ln").css("border","1px solid blue");
              $("#ln").animate({width:"295px"},"slow")
            });
            $("#ln").focusout(function(){
              $("#ln").css("border","1px solid #0e8c7a");
              $("#ln").animate({width:"200px"},"slow")
              if (document.getElementById("ln").value==""){
              	$("#lNameError").slideDown("fast");
              }else{
              	$("#lNameError").slideUp("fast");
              }
            });
            
            
            $("#dob").focusin(function(){
              $("#dob").css("border","1px solid blue");
              $("#dob").animate({width:"295px"},"slow")
            });
            $("#dob").focusout(function(){
              $("#dob").css("border","1px solid #0e8c7a");
              $("#dob").animate({width:"200px"},"slow")
            });
            
            $('#mo').keyup(function() {      
            	if(this.value.length == $(this).attr('maxlength')) 
            	{          
            		$('#da').focus();      
            	}  
            });
            $('#da').keyup(function() {      
            	if(this.value.length == $(this).attr('maxlength')) 
            	{          
            		$('#yr').focus();      
            	}  
            });
		});