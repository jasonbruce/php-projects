<?php
session_start();


 echo '
 <html>
 <head>';
       echo '

       <link rel="stylesheet" type="text/css" href="menu.css" media="all">
       <link rel="stylesheet" type="text/css" href="adminMenu.css" media="all">
       <link rel="stylesheet" type="text/css" href="generalStyle.css" media="all">
       <link rel="stylesheet" type="text/css" href="indexStyle.css" media="all">
       <link rel="stylesheet" type="text/css" href="admin.css" media="all">
       <link rel="stylesheet" type="text/css" href="ViewAssist.css" media="all">
       <link rel="stylesheet" type="text/css" href="reports.css" media="all">
       <title>FirstOCC</title>
 	
	<script type="text/javascript" src="jquery.js"></script>
	<script type="text/javascript" src="adminMenu.js"></script>
	<script type="text/javascript" src="enterPatient.js"></script>
	<script type="text/javascript" src="login.js"></script>
	<script type="text/javascript" src="enterProgramData.js"></script>
	<script type="text/javascript" src="admin.js"></script>
	<script type="text/javascript" src="ViewAssist.js"></script>
	<script src="js/highcharts.js"></script>
	<script src="js/modules/exporting.js"></script>
	<script type="text/javascript" src="reports.js"></script>
	
 </head>
<body>
';

?>
