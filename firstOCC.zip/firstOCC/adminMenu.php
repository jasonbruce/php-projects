<?php

  echo '
	<p class="menuBtn">Welcome Back '. $_SESSION['un'] . '</p>
	<div class="adminPanel">
		 User ID#: '. $_SESSION['uID'] . '<br>
		 User Name: '. $_SESSION['un'] . '<br>
		 Email: '. $_SESSION['email'] . '<br>
		 User Type: '. $_SESSION['role'] . '<br>
	</div>
  ';


?>
