		$(document).ready(function(){
            //admin menu
	  		$(".menuBtn").click(function(){
              $(".adminPanel").slideToggle("slow");
            });
	  		$(".floatCommentHeader").click(function(){
	              $(".floatCommentsData").slideToggle("medium");
	        });
	  		
		});
		