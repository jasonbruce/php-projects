<?php
 include 'header.php';
 include 'modules.php';
 
 if ($_SESSION['loggedin'] == "true"){
  	 	include 'navimenu.php';
 		searchBar('');
 		userInfo();
 		floatComments();
 		buildReports();
 		
 }else{
	$action = $_POST['action'];
 	login($action, 'index.php');
 }



	





?>
