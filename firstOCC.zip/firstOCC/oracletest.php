<?php
//$myselect = "select * from scott.emp";
//$oraconn = oci_connect('system', 'password', '//192.168.0.145/lindb');
//$doquery = OCIparse($oraconn, $myselect) or die("Couldn't parse statement.");
//OCIexecute($doquery) or die("Couldn't execute statement.");

//while (OCIfetch($doquery))
 //{$surname = OCIresult($doquery, ENAME);
  //$salval = OCIresult($doquery, SAL);
  //print '<b>'.$surname.'</b> '.$salval.'<br>';
 //}
  
$database="localhost";
$dbun="root";
$dbpw="";
$con = mysql_connect($database, $dbun, $dbpw) or die("uh o");

?>
