<?php
$handle = @fopen("logs/thelog.txt", "r");
  if ($handle) {
	echo "<label class=header>Log</label><br>";
    while (($buffer = fgets($handle, 4096)) !== false) {
          echo "$buffer";
          echo '<br>';
    }
    if (!feof($handle)) {
        echo "Error: unexpected fail";
    }
    fclose($handle);
  }
?>

