<?php
  echo '<table>
        <tr><td><label class=header>Output files</label> <br><i>(/var/www/html/FirstMergeS2/output_file/)</i></td></tr>
        <tr><td>';
            showFiles("output_file/");
        echo '</td></tr>
        <tr><td><label class=header>Imported Files</label> <br><i>(/var/www/html/uploads/)</i></td></tr>
        <tr><td>';
            showFiles("../uploads/");
  echo '</td></tr>';
  echo '<tr><td><label class=header>Application Space</label> <i></i></td></tr>';
  echo '<tr><td>';
           showSpace(); 
  echo '</td></tr>';
//  echo '<tr><td><label class=header>CPU Usage</label> <i></i></td></tr>';
//  echo '<tr><td>';
//            getCPU();
//  echo '</td></tr>';
  echo '</table>';


 function showSpace(){
   exec("cat /dev/null > /var/www/html/FirstMergeS2/space.txt");
   exec("du -h /var/www/html/FirstMergeS2/output_file/ > /var/www/html/FirstMergeS2/logs/space.txt");
   exec("du -h /var/www/html/uploads/ >> /var/www/html/FirstMergeS2/logs/space.txt");
   exec("du -h /var/www/html/FirstMergeS2/logs/ >> /var/www/html/FirstMergeS2/logs/space.txt");
     read_file("/var/www/html/FirstMergeS2/logs/space.txt");
 }
 
 function getCPU(){
   $command = "sar | grep -v '^L' | cut -d' ' -f7,12,13  | tail -n3 > logs/cpu.txt";
   exec($command);
     read_file("/var/www/html/FirstMergeS2/logs/cpu.txt");

 }
 function showFiles($dir){
   $results = scandir($dir);
   foreach ($results as $file){
      if ($file != "." && $file != ".."){
         echo "<a href='$dir/$file' target='_blank' class='file_link'>$file</a><br>";
      }
   }
 }
 function read_file($file){
   $handle = @fopen($file, "r");
   if ($handle) {
    while (($buffer = fgets($handle, 4096)) !== false) {
        echo $buffer;
                echo '<br>';
    }
    if (!feof($handle)) {
        echo "Error: unexpected fail";
    }
    fclose($handle);
   }
 }
?>

