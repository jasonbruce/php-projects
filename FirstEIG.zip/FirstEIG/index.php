<?php
  echo '
        <html>
        <head><title>Portal EIG Logs</title></head>
        <body>
        <div style="width: 100%; height:100%; position: relative;">
        <div style="position: relative; height: 100%; width: 70%; left: 15%; border: 1px solid black;">
        <center><table>
        <tr><th colspan=4><font size="12">Portal EIG Logs</font><br><br><br></th></tr>';

        echo '<tr><td colspan=2><label class=header><font size="5"><u><b>LIVE - hcihpp3fh</u></b></font></label></td></tr>';
            showFiles("eig_logs/live/hcihpp3fh");
        echo '<tr><td colspan=2><label class=header><font size="5"><u><b>LIVE - hcihpp4fh</u></b></font></label></td></tr>';
            showFiles("eig_logs/live/hcihpp4fh");
        echo '<tr><td colspan=2><label class=header><font size="5"><u><b>TEST - hcihppt1fh</u></b></font></label></td></tr>';
            showFiles("eig_logs/test/hcihppt1fh");
        echo '<tr><td colspan=2><label class=header><font size="5"><u><b>TEST - hcihppt2fh</u></b></font></label></td></tr>';
            showFiles("eig_logs/test/hcihppt2fh");

  echo '</table></center>
        </div>
        </div>
        </body>
        </html>
       ';
 
 function showFiles($dir){
   $results = scandir($dir);
   foreach ($results as $file){
     echo '<tr>';
      if ($file != "." && $file != ".."){
         if (strpos($file, "eig") === false) {
         }else{
           $fileTime = date("m/d/y h:m", filemtime($dir . '/' . $file));
           echo "<td></td><td><a href='$dir/$file' target='_blank' class='file_link'><b>$file</b></a></td><td><i>$fileTime</i></td>";
         }
      }
     echo '</tr>';
   }
 }
?>

