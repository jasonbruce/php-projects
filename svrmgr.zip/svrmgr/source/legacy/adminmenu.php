<?php

echo '<center>
<div class="adminMenuDiv" id="menu">
<b><u>@Dm1N M3nu</u></b><br>
[--<a href="updateServerDel.php" class="menulink">Delete Servers</a>--]
<br>
[--<a href="editusers.php" class="menulink">Edit Users </a>--]
</div>
</center><br>
';


?> 