<?php
 error_reporting(0);
include 'connecttodb.php';
 include 'checklogin.php';
$loggedin = $_SESSION['loggedin'];

if ($loggedin == "TRUE"){
require 'exporttocsv.php';
 
$table=$_GET['tbl']; // this is the tablename that you want to export to csv from mysql.

$query = "SELECT skeys as 'KEY', serverName as 'DNS NAME', method as 'METHOD', osID as 'OS TYPE', osver as 'OS VER', typeID as 'HW VER', owner as 'OWN', serial as 'SERIAL #', pncon as 'PN CON', sncon as 'SN CON', speed as 'Speed', alias as 'ALIAS 1', alias2 as 'ALIAS 2', alias3 as 'ALIAS 3', alias4 as 'ALIAS 4', alias5 as 'ALIAS 5', comments as 'DESC' FROM tblServers WHERE active = 'Y' ";


exportMysqlToCsv($table, $query);
 }
?>
