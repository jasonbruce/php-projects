<?php
include 'headtag.php';
include 'menu.php';
include 'connecttodb.php';
include 'searchForm.php';
include 'checklogin.php';
$loggedin = $_SESSION['loggedin'];



if ($loggedin == "TRUE"){


	$uname = $_SESSION['UserName'];
	$pwO = $_GET['pwone'];
	$pwT  = $_GET['pwtwo'];
	$submitBtn = $_GET['changed'];
	
	if ($submitBtn == "clicked"){
		if ($pwO == $pwT){
			if(strlen($pwO) < 8) {
				echo 'Password is less than 8 characters long, please try again';
			}else{
					
					$query = 'UPDATE tblUSRs SET pw="' .sha1($pwO) . '" WHERE uname="' . $uname .'"';
					mysql_query($query);
					echo '<br>YOUR PASSWORD HAS BEEN CHANGED!';
			}
		}
	}
	showForm();
}
	
	
	function showForm(){
		echo '<form action="changePW.php" method="GET">	
			<table class="changePW">
			<tr>
				<td>Enter New Password: </td><td><input type="password" name="pwone"></td>
			</tr>
			<tr>
				<td>Confirm: </td><td><input type="password" name="pwtwo"></td>
			</tr>
			<tr>
				<td colspan="2"><center><input type="submit" value="Change Password"><input type="hidden" name="changed" value="clicked"></center></td>
			</tr>
			</table>
		</form>';
	}

?>