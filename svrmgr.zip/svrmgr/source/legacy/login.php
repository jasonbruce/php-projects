 <?php 
 // this starts the session 
 include 'headtag.php';
 include 'connecttodb.php';
 
 $uname				 		= $_POST['uname'];
 $pw 							= $_POST['pword'];

 $query = "select `pw`, `role` from tblUSRs where `uname` = '$uname' AND `active` = 'Y'";
 $result = mysql_query($query);
 while($row = mysql_fetch_array($result))
 {
		if ($row['pw'] == "" )
		{
			echo 'Password/User Name Error';	
		} else {
			$pwFound = $row['pw'];
			$ro = $row['role'];
		}
 }
 
 if ($pwFound == sha1($pw)){
	$_SESSION['UserName'] 			= $_POST['uname'];
	include 'menu.php';
	 echo "Welcome ". $_SESSION['UserName'] .'<br>'; 
	 $_SESSION['loggedin'] = "TRUE";
	 $_SESSION['urole'] = $ro;
 }else{
	echo 'Password Mis-Match!';	
 }
 
 //$_SESSION['UID'] 		= $_POST['uname'];
 
 // echo variable from the session, we set this on our other page 

  
 ?> 