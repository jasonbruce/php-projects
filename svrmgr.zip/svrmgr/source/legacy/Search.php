<?php
include 'headtag.php';
include 'menu.php';
include 'checklogin.php';
$loggedin = $_SESSION['loggedin'];

if ($loggedin == "TRUE"){
	$search 	= 	$_GET['search'];

showSearchBar($search);
Space();
showSearchQuery($search);
}




function showSearchBar($search){
echo '
<center><div class="searchBarDiv">
	<center>	
		<form action="Search.php" method="get">
			Search For:  <input type="text" name="search" value="' . $search . '"><Input type="submit" value="Find IT!">
		</form>
	</center>
</div>
';

}

function showSearchQuery($search){
   if ($search != ""){
	echo '<div class="SearchResults">';
	echo '<b>Your Search for: </b> ' . $search;	
	Space();
           
                SearchFor($search, 'serial', 'Serial');
                SearchFor($search, 'serverName', 'Server Name');
                SearchFor($search, 'skeys', 'Key' );
				SearchFor($search, 'alias', 'Alias 1');         
                SearchFor($search, 'alias2', 'Alias 2');           
                SearchFor($search, 'alias3', 'Alias 3 ');           
                SearchFor($search, 'alias4', 'Alias 4 ');           
                SearchFor($search, 'alias5', 'Alias 5 ');           
                SearchFor($search, 'owner', 'Owner ');           
                SearchFor($search, 'osID', 'OS');           
                SearchFor($search, 'osver', 'OS Version ');           
                SearchFor($search, 'typeID', 'Type ');           
                SearchFor($search, 'comments', 'Comments ');           
                SearchFor($search, 'ipID', 'IP Addresses ');           
                SearchFor($search, 'method', 'Method ');           
                SearchFor($search, 'speed', 'Speed ');           
                SearchFor($search, 'pncon', 'PN Connection ');
                SearchFor($search, 'sncon', 'SN Connection ');
				SearchFor($search, 'pvState', 'Physical / Virtual');
				SearchFor($search, 'osLic', 'OS License');
           
	echo '</div>';
    }
}

function SearchFor($search, $field, $displ){
include 'connecttodb.php';
$query = "SELECT * FROM tblServers WHERE $field LIKE '%$search%'";
        $result = mysql_query($query);
		$nrows = mysql_num_rows($result);        
	if ($nrows > 0){
			echo '	<div class="SearchField">';
			echo $nrows . ' <i>Results Found in </i>' . $displ . ' <br>';	
				while($row = mysql_fetch_array($result)){
					echo '<i><a href="viewServer.php?serverID=' . $row['serverID'] .'" class="searchResultA">' . $row['serverName'] .'</a></i>';
					echo "<i>\t\t ";
					echo $row['skeys'];
					echo "\t\t ";
					echo $row['serial'];
        	        echo "\t\t ";
					echo $row['owner'];
	                echo "\t\t ";
					echo $row['osID'];
                	echo '</i><br>';
				}
			echo '</div><br>';
	}else{
	
	}
}



function DisplaySearchField($Field){
echo '	<div class="SearchField">';
		//<b><i>Search Results in Field: '. $Field  .'</i></b>

}


function Space(){
	echo '<br>';
}

?>
