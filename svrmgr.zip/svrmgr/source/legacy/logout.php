<?php

session_destroy();

echo 'Please come again soon';


?>