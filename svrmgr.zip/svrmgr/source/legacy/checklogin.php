<?php

	if ($_SESSION['UserName'] == "")
	{
		echo '<div class="userInfo">';
			echo '<form name="loginForm" action="login.php" method="POST">
				    <table>
							<tr>
								<td>User Name: </td><td><input type="text" name="uname" class="uname"></td>
							</tr>
							<tr>	
								<td>Password: </td><td><input type="password" name="pword" class="uname"></td>
							</tr>
							<tr>
								<td colspan="2"><center><input type="submit" value="Log In"></td>
							</tr>
					</table>
				</form>';
		echo '</div>';
	}else{
		echo '<div class="userInfo">';
					echo '<b>Welcome '.  $_SESSION['UserName'] .'.</b>';
					if ($_SESSION['urole'] == "admin"){
						include 'adminmenu.php';
					}
						
		echo '<a href="changePW.php" class="menulink">Change PW</a><br><a href="logout.php" class="menulink"> Log Out </a>';
		echo '</div>';
	}


?>