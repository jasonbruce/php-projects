<?php
echo '<head>';
 session_start() ;
echo ' 
<link rel="stylesheet" type="text/css" href="style.css" media="all">
<script language="JavaScript">
	function showDiv(id){
		if (document.getElementById(id).style.display == \'inline\') {
			document.getElementById(id).style.display = \'none\';
		}else{
			document.getElementById(id).style.display = \'inline\';
		}
	}
</script>
<title>Server Manager</title>
</head>
<body>
';
?>