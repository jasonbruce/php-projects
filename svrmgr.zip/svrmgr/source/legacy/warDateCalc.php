<?php
include 'connecttodb.php';

function getDateDiff($serverID){
$query = "select `warID` from tblServers where serverID='$serverID'";
$result = mysql_query($query);
				while($row = mysql_fetch_array($result)){
								$warEndDate = $row['warID'];
				}
				list($month, $day, $year) = split('[/.-]', $warEndDate);
				$warEndDate = $year  . '-' . $month . '-' . $day;
				$toDayDate = date("Y-m-d");
		
				$start_ts = strtotime($toDayDate);
				$end_ts = strtotime($warEndDate);
				$diff = $end_ts - $start_ts;
				return round($diff / 86400);
}

			

?>