<?php

include 'headtag.php';
include 'menu.php';
include 'connecttodb.php';
include 'checklogin.php';
$loggedin = $_SESSION['loggedin'];
	$action = $_GET['action'];
	$userid  = $_GET['userid'];
	$uname = $_GET['uname'];
	$active = $_GET['active'];
	$role = $_GET['role'];
	$email = $_GET['email'];
	$update = $_GET['update'];

if ($loggedin == "TRUE"){
	updateUser($action, $userid, $uname, $active, $role, $email, $update);
	showUserTable();
	populateForm($action, $userid, $uname, $active, $role, $email);
	echo '</table></div>';
}


function showUserTable(){
		
		$query = "SELECT * FROM tblUSRs";
		$result = mysql_query($query);
		
			echo '<div class="editUdiv">
			<a href="editusers.php" class="menulink">*New User*</a>
				<table class="editUtbl">
						<tr>
								<th>Action</th>
								<th>User ID</th>
								<th>User Name</th>
								<th>Active</th>
								<th>Role</th>
								<th>Email</th>
						</tr>';
		while($row = mysql_fetch_array($result)){
					echo '<tr>
								<td><a href="editusers.php?userid=' . $row['userid'] . '&uname=' . $row['uname'] . '&active=' . $row['active'] . '&role=' . $row['role'] . '&email=' . $row['email'] . '&action=Edit">[-Edit-]</a>
									   <a href="editusers.php?userid=' . $row['userid'] . '&uname=' . $row['uname'] . '&active=' . $row['active'] . '&role=' . $row['role'] . '&email=' . $row['email'] . '&action=Delete">[-Delete-]</a>
							    </td>
								<td>' . $row['userid'] . '</td>
								<td>' . $row['uname'] . '</td>
								<td>' . $row['active'] . '</td>
								<td>' . $row['role'] . '</td>
								<td>' . $row['email'] . '</td>
							</tr>	';
		}
			
			
}

function populateForm($action, $userid, $uname, $active, $role, $email){

 if ( $action == "" ) {
	$action = "Add";
 }

echo '<tr>
				<td><form action=editusers.php method=GET><input type="submit" value="' . $action . '  "><input type="hidden" name=action value="' . $action . '"><input type="hidden" name=update value="Y"><input type="hidden" name=userid value="' . $userid . '"></td>
				<td>' . $userid . '</td>
				<td><input type="text" name=uname value=' . $uname . '></td>
				<td><select name="active">' ;
							if ($active == "N"){
								echo '<option>Y</option>';
								echo '<option selected>N</option>';
							}else{
								echo '<option selected>Y</option>';
								echo '<option>N</option>';
							}
				echo '</select></td>
				<td><input type="text" name=role value=' . $role . '></td>
				<td><input type="text" name=email value=' . $email . '></td></form>
		</tr>';
}

function updateUser($action, $userid, $uname, $active, $role, $email, $update){
				
			if($update=="Y"){
				if ($action == "Delete")
				{
					$query = "Delete from tblUSRs where `userid`= '$userid'";
				}
				if ($action == "Edit")
				{
					$query =  "Update `tblUSRs` SET `uname`='$uname',`active`='$active', `role`='$role', `active`='$active', `email`='$email' WHERE `userid`=$userid";
				}
				if ($action == "Add")
				{
					$pw = 'T' . rand(300,400) . 'E' . rand(150,500) . 'M' . rand(12,40) . 'P';
					$pwe = sha1($pw);
					$query = "Insert into tblUSRs (uname, active,role,email, pw) Values ( '$uname', '$active', '$role', '$email', '$pwe')";  
					mail($email, "Welcome to Server Manager!", "TEST! Welcome to Server Manager!  Your User Name is $uname.  Your temporary password is: $pw.  Please log in http://dev-mgr-mrh/index.php", "FROM: ADMIN@SVRMGR");
					mail("jbruce@firsthealth.org","new user added", "the user $uname, has been added to dev-mgr-mrh");
				}
					
				mysql_query($query);			
			}				
							
							
							
}


?>