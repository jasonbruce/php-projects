<?php
include 'headtag.php';
include 'menu.php';
include 'searchForm.php';
include 'checklogin.php';
$loggedin = $_SESSION['loggedin'];

if ($loggedin == "TRUE"){
$owner         = $_GET['owner'];
$serverName    = $_GET['serverName'];
$serverAlias   = $_GET['serverAlias'];
$active        = $_GET['active'];
$serverID      = $_GET['serverID'];
$serial        = trim($_GET['serial'], " ");
$updated       = "false";
$updated       = $_GET['updated'];
$key           = $_GET['key']; 
$aliasTwo      = $_GET['alias2'];
$method        = $_GET['method'];
$speed         = $_GET['speed'];
$pncon         = $_GET['pncon'];
$sncon         = $_GET['sncon'];
$osVer         = $_GET['osVer'];
$osID          = $_GET['osID'];
$ascdesc		= $_GET['ascdesc'];
$sortby			= $_GET['sortby'];
$pvState		= $_GET['pvState'];

if ($ascdesc=="ASC") 
{ 
	$ascdesc = "DESC" ;
} 
else 
{  
	$ascdesc = "ASC" ;
}
if ($sortby=="") 
{ 
	$sortby = "skeys" ;
}


include 'connecttodb';

if ($updated == "true"){
	updateTable($serverID, $serial, $active, $serverName, $serverAlias, $cost, $osID, $osVer, $typeID, $owner, $key, $aliasTwo, $method, $speed, $pncon, $sncon, $pvState);	
}
echo '<center><div class="updateTableDiv">';
displayTable($serial, $serverID, $sortby, $ascdesc);
echo '</table></div></center>';
echo '<br>';
echo '<center><div class="notes"> 
	<p>The table above is editable. Simply click in the cell you wish to edit, make your edits, hit "ENTER" or click the Update button on the action column. Once the data has been updated, the row will highlight yellow.
</div></center>';
}


function displayTable($serial, $serverID, $sortby, $ascdesc){
include 'connecttodb.php';
include 'pingit.php';

echo '<table class="validationtable">';
echo '
<th>Action</th>
<th><a href="updateServer.php?sortby=skeys&ascdesc=' . $ascdesc . '" class="sortLink">Key</a></th>
<th><a href="updateServer.php?sortby=serverName&ascdesc=' . $ascdesc . '" class="sortLink">Server/Host Name</a></th>
<th><a href="updateServer.php?sortby=serial&ascdesc=' . $ascdesc . '" class="sortLink">Serial</a></th>
<th><a href="updateServer.php?sortby=alias&ascdesc=' . $ascdesc . '" class="sortLink">Alias 1</a></th>
<th><a href="updateServer.php?sortby=alias2&ascdesc=' . $ascdesc . '" class="sortLink">Alias 2</a></th>
<th><a href="updateServer.php?sortby=method&ascdesc=' . $ascdesc . '" class="sortLink">Method</a></th>
<th><a href="updateServer.php?sortby=speed&ascdesc=' . $ascdesc . '" class="sortLink">Speed</a></th>
<th><a href="updateServer.php?sortby=pncon&ascdesc=' . $ascdesc . '" class="sortLink">PN Con</a></th>
<th><a href="updateServer.php?sortby=sncon&ascdesc=' . $ascdesc . '" class="sortLink">SN Con</a></th>
<th><a href="updateServer.php?sortby=active&ascdesc=' . $ascdesc . '" class="sortLink">Active</a></th>
<th><a href="updateServer.php?sortby=owner&ascdesc=' . $ascdesc . '" class="sortLink">Owner</a></th>
<th><a href="updateServer.php?sortby=osID&ascdesc=' . $ascdesc . '" class="sortLink">OS</a></th>
<th><a href="updateServer.php?sortby=osver&ascdesc=' . $ascdesc . '" class="sortLink">OS Version</a></th>
<th><a href="updateServer.php?sortby=pvState&ascdesc=' . $ascdesc . '" class="sortLink">Phys\Virt</a></th>';
	$query = "SELECT * FROM tblServers ORDER BY $sortby $ascdesc";
	$result = mysql_query($query);
	while($row = mysql_fetch_array($result)){
	    if($row['serverID']==$serverID){
		echo '<tr bgcolor=yellow><form action=updateServer.php method="GET">';
			echo '
				  <td nowrap="nowrap"><input type="hidden" name="serverID" value="' . $row['serverID'] . '"><input type="hidden" name="updated" value="true">	
			      | <input type="submit" value="Update" class="tdtxt"> 
			      | <a href="viewServer.php?serverID='. $row['serverID']  .'" class="tdtxt">View</a>

			      |</td>
				  <td><input type="text" name="key" value="' . $row['skeys'] . '" class="tdtxt"  style="width: 60px;"></td>
			      <td><input type="text" name="serverName" value="' .   $row['serverName'] . '" class="tdtxt"></td>
			      <td><input type="text" name="serial" value="' .       $row['serial']  . '" class="tdtxt" maxlength="20" style="width: 80px;"></td>
			      <td><input type="text" name="serverAlias" value="' .  $row['alias']  . '" class="tdtxt" maxlength="20" style="width: 70px;"></td>
			      <td><input type="text" name="alias2" value="' .       $row['alias2']  . '" class="tdtxt" maxlength="20" style="width: 70px;"></td>
			      <td><input type="text" name="method" value="' .       $row['method'] . '" class="tdtxt"  maxlength="10" style="width: 50px;"></td>
                  <td><input type="text" name="speed" value="' .        $row['speed'] . '" class="tdtxt" maxlength="10"  style="width: 50px;"></td>
			      <td><input type="text" name="pncon" value="' .        $row['pncon'] . '" class="tdtxt" maxlength="10"  style="width: 50px;"></td>
			      <td><input type="text" name="sncon" value="' .        $row['sncon'] . '" class="tdtxt" maxlength="10"  style="width: 50px;"></td>
			      <td><input type="text" name="active" value="' .       $row['active'] . '" class="tdtxt" maxlength="1" style="width: 30px;"></td>
			      <td><input type="text" name="owner" value="' .        $row['owner'] . '" class="tdtxt" maxlength="20" style="width: 110px;"></td>
			      <td><input type="text" name="osID" value="' .         $row['osID'] . '" class="tdtxt" maxlength="20" style="width: 80px;"></td>
                  <td><input type="text" name="osVer" value="' .        $row['osver'] . '" class="tdtxt" maxlength="20" style="width: 90px;"></td>
				  <td><input type="text" name="pvState" value="' .        $row['pvState'] . '" class="tdtxt" maxlength="20" style="width: 90px;"></td>
				  <input type="hidden" name="ascdesc" value=" ' . $ascdesc . ' "> <input type="hidden" name="sortby" value=" ' . $sortby . ' ">';
		echo '</form></tr>';
	    }else{
		    if ($row['active'] == "N")
			{
				$tdColor = "#9C9B9B";
				echo '<tr bgcolor="' . $tdColor . '"><form action=updateServer.php method="GET">';
			echo '
			<td nowrap="nowrap"><input type="hidden" name="serverID" value="' . $row['serverID'] . '"><input type="hidden" name="updated" value="true">	
			      | <input type="submit" value="Update" class="tdntxt"> 
			      | <a href="viewServer.php?serverID='. $row['serverID']  .'" class="tdntxt">View</a>

			      |</td>
				  <td><input type="text" name="key" value="' .          $row['skeys'] .      '" class="tdntxt"  style="width: 60px;"></td>
			      <td><input type="text" name="serverName" value="' .   $row['serverName'] . '" class="tdntxt"></td>
			      <td><input type="text" name="serial" value="' .       $row['serial']  . '" class="tdntxt" maxlength="20" style="width: 80px;"></td>
			      <td><input type="text" name="serverAlias" value="' .  $row['alias']  . '" class="tdntxt" maxlength="20" style="width: 70px;"></td>
			      <td><input type="text" name="alias2" value="' .       $row['alias2']  . '" class="tdntxt" maxlength="20" style="width: 70px;"></td>                      
			      <td><input type="text" name="method" value="' .       $row['method'] .     '" class="tdntxt" maxlength="10"  style="width: 50px;"></td>
			      <td><input type="text" name="speed" value="' .        $row['speed'] .      '" class="tdntxt" maxlength="10"  style="width: 50px;"></td>
                  <td><input type="text" name="pncon" value="' .        $row['pncon'] .      '" class="tdntxt" maxlength="10"  style="width: 50px;"></td>
                  <td><input type="text" name="sncon" value="' .        $row['sncon'] .      '" class="tdntxt" maxlength="10"  style="width: 50px;"></td>
			      <td><input type="text" name="active" value="' .       $row['active'] .     '" class="tdntxt" maxlength="1" style="width: 30px;"></td>
			      <td><input type="text" name="owner" value="' .        $row['owner'] . '" class="tdntxt" maxlength="20" style="width: 110px;"></td>
			      <td><input type="text" name="osID" value="' .         $row['osID'] . '" class="tdntxt" maxlength="20" style="width: 80px;"></td>
                  <td><input type="text" name="osVer" value="' .        $row['osver'] . '" class="tdntxt" maxlength="20" style="width: 90px;"></td>
				  <td><input type="text" name="pvState" value="' .        $row['pvState'] . '" class="tdntxt" maxlength="20" style="width: 90px;"></td>
				  <input type="hidden" name="ascdesc" value=" ' . $ascdesc . ' "> <input type="hidden" name="sortby" value=" ' . $sortby . ' ">';
            	  echo '</form></tr>';
			}else{
				$tdColor = "#6DAE6D";
				echo '<tr bgcolor="' . $tdColor . '"><form action=updateServer.php method="GET">';
			echo '
			<td nowrap="nowrap"><input type="hidden" name="serverID" value="' . $row['serverID'] . '"><input type="hidden" name="updated" value="true">	
			      | <input type="submit" value="Update" class="tdtxt"> 
			      | <a href="viewServer.php?serverID='. $row['serverID']  .'" class="tdtxt">View</a>

			      |</td>
				  <td><input type="text" name="key" value="' .          $row['skeys'] .      '" class="tdtxt"  style="width: 60px;"></td>
			      <td><input type="text" name="serverName" value="' .   $row['serverName'] . '" class="tdtxt"></td>
			      <td><input type="text" name="serial" value="' .       $row['serial']  . '" class="tdtxt" maxlength="20" style="width: 80px;"></td>
			      <td><input type="text" name="serverAlias" value="' .  $row['alias']  . '" class="tdtxt" maxlength="20" style="width: 70px;"></td>
			      <td><input type="text" name="alias2" value="' .       $row['alias2']  . '" class="tdtxt" maxlength="20" style="width: 70px;"></td>                     
			      <td><input type="text" name="method" value="' .       $row['method'] .     '" class="tdtxt" maxlength="10"  style="width: 50px;"></td>
			      <td><input type="text" name="speed" value="' .        $row['speed'] .      '" class="tdtxt" maxlength="10"  style="width: 50px;"></td>
                  <td><input type="text" name="pncon" value="' .        $row['pncon'] .      '" class="tdtxt" maxlength="10"  style="width: 50px;"></td>
                  <td><input type="text" name="sncon" value="' .        $row['sncon'] .      '" class="tdtxt" maxlength="10"  style="width: 50px;"></td>
			      <td><input type="text" name="active" value="' .       $row['active'] .     '" class="tdtxt" maxlength="1" style="width: 30px;"></td>
			      <td><input type="text" name="owner" value="' .        $row['owner'] . '" class="tdtxt" maxlength="20" style="width: 110px;"></td>
			      <td><input type="text" name="osID" value="' .         $row['osID'] . '" class="tdtxt" maxlength="20" style="width: 80px;"></td>
                  <td><input type="text" name="osVer" value="' .        $row['osver'] . '" class="tdtxt" maxlength="20" style="width: 90px;"></td>
				  <td><input type="text" name="pvState" value="' .        $row['pvState'] . '" class="tdtxt" maxlength="20" style="width: 90px;"></td>
				  <input type="hidden" name="ascdesc" value=" ' . $ascdesc . ' "> <input type="hidden" name="sortby" value=" ' . $sortby . ' ">';
            	  echo '</form></tr>';
			}   
		
		
	        
	    }
	}

}


function updateTable($serverID, $serial, $active, $serverName, $serverAlias, $cost, $osID, $osVer, $typeID, $owner, $key, $aliasTwo, $method, $speed, $pncon, $sncon, $pvState){
	include 'connecttodb.php';
	mysql_select_db("svrmgr");
	$query = 'Update `tblServers` SET `osID`="'. $osID .'",`osver`="'. $osVer  .'", `skeys`="' . $key  . '",`pncon`="' . $pncon  . '",`sncon`="' . $sncon  . '",`speed`="' . $speed  . '",`alias2`="' . $aliasTwo  . '",`method`="' . $method  . '", `active`="' . $active . '", `serverName`="' . $serverName . '", `serial`="' . $serial . '", `owner`="' . $owner . '", `alias`="' . $serverAlias . '", `pvState`="' . $pvState . '" WHERE `serverID` = ' . $serverID . ' ';
	mysql_query($query);
	echo '<font color=green><b>Your data has been updated</b></font>';
}



?>
