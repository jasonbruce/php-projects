<?php
include 'headtag.php';
include 'menu.php';
include 'searchForm.php';


echo '
<div class="logDiv">
<b>Upload Process:<br>
1. Download the template from <a href="http://is-spt-mrh/tsupport/support_documents/serverImport.csv" style="text-decoration:none;">[---Here---]</a><br>
2. Fill out the template with server information that you want to check / enter into the system.<u>(DO NOT MOVE THE COLUMNS)</u><br>
3. Save the template locally <u> (MUST BE CSV)</u>.<br>
4. Browse for the saved file.<br>
5. Click Upload.<br> 
</b><br><br><div>
';

displayForm();






function displayForm(){
echo '
<form action="uploadScript.php" method="post" enctype="multipart/form-data">
<input type="hidden" name="MAX_FILE_SIZE" value="300000">
<input type="file" name="uploadTemplate" id="uploadTemplate">
<br>
<input type="submit" value="Upload Template">
</form>
';

}

?>
