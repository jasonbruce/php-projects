<?php
$database="localhost";
	$dbun="root";
		$dbpw="root";
			mysql_connect($database, $dbun, $dbpw) or die(mysql_error());
				mysql_select_db("svrmgr");
?> 
