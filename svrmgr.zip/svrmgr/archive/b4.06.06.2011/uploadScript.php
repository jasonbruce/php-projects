<?php
//--------------------------------//
//--------------------------------//
//-----------MAIN-----------------//
//--------------------------------//
//--------------------------------//


include 'headtag.php';
include 'menu.php';	

echo '<div class="pageheader">
	<center><h3>Serial Import / Validation</h3></center>
</div><br><br>';
echo '<div class="logDiv">';
uploadData();
importData();
echo '<br><br><br><hr><br><br>';
//--------------------------------i/
//--------------------------------//
//--------------------------------//
//--------------------------------//
//--------------------------------//
//--------------------------------//


function checkSerialnName($serial, $servName, $key, $alias, $alias2, $alias3, $alias4, $alias5, $method, $speed, $pncon, $sncon, $warrantydate, $dateinservice, $make, $model, $ipaddress, $active, $osname, $osversion, $owner, $cost, $comments){

$serial = trim($serial, " ");

if ($serial <> ""){
        include 'connecttodb.php';
        $query = "SELECT * FROM tblServers WHERE serial = '" . $serial . "' AND serverName= '" . $servName . "'";
        $found = "no";
        $result = mysql_query($query);

echo '<tr>';
        while($row = mysql_fetch_array($result))
        {
                        $found = "yes";
						echo '<td nowrap="nowrap"><a href="updateServer.php?serial=' . $serial . '">Update Server</a><a href="javascript:location.reload(true)"><img src="/img/refresh.jpg" class="icon"></a></td>';
                        echo '<td><img src="/img/found.png" class="icon">';
                        echo '<td nowrap="nowrap">' .  $row['skeys'] . '</td>';
						echo '<td nowrap="nowrap">' . $serial . '</td>';
                        echo '<td nowrap="nowrap">' .  $row['serverName'] . '</td>';
                        echo '<td nowrap="nowrap">' . $row['alias'] . '</td>';
                        echo '<td nowrap="nowrap">' . $row['alias2'] . '</td>';
                        echo '<td nowrap="nowrap">' . $row['alias3'] . '</td>';
                        echo '<td nowrap="nowrap">' . $row['alias4'] . '</td>';
                        echo '<td nowrap="nowrap">' . $row['alias5'] . '</td>';
                        echo '<td nowrap="nowrap">' . $row['method'] . '</td>';
                        echo '<td nowrap="nowrap">' . $row['speed'] . '</td>';
                        echo '<td nowrap="nowrap">' . $row['pncon'] . '</td>';
                        echo '<td nowrap="nowrap">' . $row['sncon'] . '</td>';
                        echo '<td nowrap="nowrap">' . $row['warrantyStartDate'] . '</td>';
						echo '<td nowrap="nowrap">' . $row['dateInService'] . '</td>';
						echo '<td nowrap="nowrap">' . $row['typeID'] . '</td>';
						echo '<td nowrap="nowrap">' . $row['ipID'] . '</td>';
						echo '<td nowrap="nowrap">' . $row['active'] . '</td>';
						echo '<td nowrap="nowrap">' . $row['osID'] . '</td>';
						echo '<td nowrap="nowrap">' . $row['osver'] . '</td>';
						echo '<td nowrap="nowrap">' . $row['owner'] . '</td>';
						echo '<td nowrap="nowrap">' . $row['cost'] . '</td>';
						echo '<td nowrap="nowrap">' . $row['comments'] . '</td>';	
                        
			

        }
if ($found=="no"){
		echo '<td nowrap="nowrap"><a href="enterserver.php?serial= ' . $serial  . '&serverName=' . $servName . '&serverAlias=' . $alias . '&txtMake=' . $make  . 
		'&txtModel=' . $model  . '&tblOS=' . $osname  . '&osver=' . $osversion  . '&txtIPAddress=' . $ipaddress  . '&key=' . $key  . '&owner=' . $owner  . '&alias2=' . $alias2  . '&alias3=' . $alias3  . '&alias4=' . $alias4  . '&alias5=' . $alias5  . '&method=' . $method  . '&speed=' . $speed  . '&pncon=' . $pncon  . '&sncon=' . $sncon  . '&cost=' . $cost  . '&warrantyStartDate=' . $warrantydate  . '&dateInService=' . $dateinservice  . '&comments=' . $comments  . '&tblType=Select+From+List" target="_blank">Add Server</a>';
		echo '<a href="javascript:location.reload(true)"><img src="/img/refresh.jpg" class="icon"></a></td>';
		echo '<td nowrap="nowrap"><img src="/img/notfound.png" class="icon">';
		echo '<td nowrap="nowrap">'. $key .'</td>';
		echo '<td nowrap="nowrap">' . $serial . '</td>';
        echo '<td nowrap="nowrap">'. $servName .'</td>';
        echo '<td nowrap="nowrap">' . $alias  . '</td>';
        echo '<td nowrap="nowrap">' . $alias2 . '</td>';
        echo '<td nowrap="nowrap">' . $alias3 . '</td>';
        echo '<td nowrap="nowrap">' . $alias4 . '</td>';
        echo '<td nowrap="nowrap">' . $alias5 . '</td>';
		echo '<td nowrap="nowrap">' . $method . '</td>';
		echo '<td nowrap="nowrap">' . $speed . '</td>';
		echo '<td nowrap="nowrap">' . $pncon . '</td>';
		echo '<td nowrap="nowrap">' . $sncon . '</td>';
		echo '<td nowrap="nowrap">' . $warrantydate . '</td>';
		echo '<td nowrap="nowrap">' . $dateinservice . '</td>';
		echo '<td nowrap="nowrap">' . $make . ' --- ';
		echo $model . '</td>';
		echo '<td nowrap="nowrap">' . $ipaddress . '</td>';
		echo '<td nowrap="nowrap">' . $active . '</td>';
		echo '<td nowrap="nowrap">' . $osname . '</td>';
		echo '<td nowrap="nowrap">' . $osversion . '</td>';
		echo '<td nowrap="nowrap">' . $owner . '</td>';
		echo '<td nowrap="nowrap">' . $cost . '</td>';
		echo '<td nowrap="nowrap">' . $comments . '</td>';	
}
}
echo '</td></tr>';
}



function executeSQLImport ($headers, $columns){
	for ($i =0; ; $i++){
		if ($headers[$i] == "make"){
			$qryHeader = $qryHeader . ', typeID';	
		}elseif($headers[$i] == "model"){
		}elseif($headers[$i] == "osName"){
			 $qryHeader = $qryHeader . ', osID';
		}elseif($headers[$i] == "serial"){
			 $qryHeader = 'serial';			
		}else{
	                $qryHeader = $qryHeader . ', ' . $headers[$i];
		}
		if ($headers[$i] == "" ){
			break;
		}
	}
	
	
echo "</div><h3><u>Serial and Server/Host Name Match</u></h3>";
        $i=0;
        echo '<table class="validationtable">
                        <tr>
                        		<td bgcolor="#6d7b8d"><b><font color=white>Action</font></b></td>
                        		<td bgcolor="#6d7b8d"><b><font color=white>Match Status</b></td>
                        		<td bgcolor="#6d7b8d"><b><font color=white>Key</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>Serial Number</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>Name</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>Alias</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>Alias2</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>Alias3</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>Alias4</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>Alias5</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>Method</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>Speed</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>PN Connection</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>SN Connection</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>Warranty</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>Date In Service</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>Make & Model</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>IP Address</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>Active</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>OS Name</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>OS Version</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>Owner</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>Cost</b></td>
                                <td bgcolor="#6d7b8d"><b><font color=white>Description/Comments</b></td>
                                
                                
                        </tr>
        ';
                for ($i=0; ; $i=$i+23){
                        checkSerialnName($columns[$i], $columns[$i+1], $columns[$i+2], $columns[$i+3], $columns[$i+4], $columns[$i+5], $columns[$i+6], $columns[$i+7], $columns[$i+8], $columns[$i+9], $columns[$i+10], $columns[$i+11], $columns[$i+12], $columns[$i+13], $columns[$i+14], $columns[$i+15], $columns[$i+16], $columns[$i+17], $columns[$i+18], $columns[$i+19], $columns[$i+20], $columns[$i+21], $columns[$i+22]);
                        if ($columns[$i] == ""){
                                break;
                        }
                }
        echo '</table>';

//echo '</div>';
}

function uploadData(){
if ($_FILES["uploadTemplate"]["error"] > 0){
	echo "Error: " . $_FILES["uploadTemplate"]["error"] . "<br>";
}else{
	echo "<b><u>Upload:</u> "    . $_FILES["uploadTemplate"]["name"] . "<br>";
	echo "<u>Type:</u> "      . $_FILES["uploadTemplate"]["type"] . "<br>";
	echo "<u>Size:</u> "      . $_FILES["uploadTemplate"]["size"] / 1000 . "KB<br>";
}
//if (file_exists("uploads/" . $_FILES["uploadTemplate"]["name"])){
//	echo '<b><font color=red>File already exists, rename the file and try again.</font></b>';
//	$success = "false";
//}else{
	move_uploaded_file($_FILES["uploadTemplate"]["tmp_name"] , "uploads/" . $_FILES["uploadTemplate"]["name"]);
	echo '<b><br><font color=green>File uploaded successfully.</font><br></b>';
	$success = "true";
//}
	return $success;
}

function checkDocumentHeaders($headers){
	foreach ($headers as $head){
		if ($head == ""){
		echo "<br><b><font color=red>ERROR: You have a blank header</b></font>";
		}else{
		echo "<br><font color=green>" . $head . " validated.</font>";
			$colCount = $colCount + 1;
		}
	}
	return $colCount;
}

function getColumns($columnName){
			
}

function importData(){
        $row = 0;
        $h = 0;
	$co = 0;
        if (($handle = fopen("uploads/" . $_FILES["uploadTemplate"]["name"], "r")) !== FALSE)
        {
                while (($data = fgetcsv($handle, 1000, ",")) !== FALSE)
                {
                         $num = count($data);
                         $row++;
                        for ($c=0; $c < $num; $c++)
                        {
                                        if ($row == 1){
                                                $header[$h] = $data[$c];
                                                $h = $h + 1;
                                        }else{
                                        	//echo '<br> ' . $data[$c];
					        $columns[$co] = $data[$c];	
						$co = $co + 1;
			                }
                        }
               	}
		fclose($handle);
                echo '<br><font color=green>Headers and Data gathered<br>';
		$colCount = checkDocumentHeaders($header);
		echo "<br><br>" . $colCount . " Columns will be imported.  If you had any </font><font color=red> errors </font><font color=green> you may want to re-import data.<br></font>";	
		
		executeSQLImport($header, $columns);             
        }

}
?>
