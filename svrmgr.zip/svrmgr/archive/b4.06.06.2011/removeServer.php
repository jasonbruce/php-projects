<?php
include 'headtag.php';
include 'menu.php';

$owner         = $_GET['owner'];
$serverName    = $_GET['serverName'];
$serverAlias   = $_GET['serverAlias'];
$active        = $_GET['active'];
$serverID      = $_GET['serverID'];
$serial        = trim($_GET['serial'], " ");
$updated       = "true";
$key           = $_GET['key']; 
$aliasTwo      = $_GET['alias2'];
$method        = $_GET['method'];
$speed         = $_GET['speed'];
$pncon         = $_GET['pncon'];
$sncon         = $_GET['sncon'];
$osVer         = $_GET['osVer'];
$osID          = $_GET['osID'];


            

include 'connecttodb';

if ($updated == "true"){
	updateTable($serverID, $serial, $active, $serverName, $serverAlias, $cost, $osID, $osVer, $typeID, $owner, $key, $aliasTwo, $method, $speed, $pncon, $sncon);	
}
displayTable($serial);


function displayTable($serial){
include 'connecttodb.php';
echo '<table class="validationtable">';
echo '
<th>Action</th>
<th>Key</th>
<th>Server/Host Name</th>
<th>Serial</th>
<th>Alias 1</th>
<th>Alias 2</th>
<th>Method</th>
<th>Speed</th>
<th>PN Connection</th>
<th>SN Connection</th>
<th>Active</th>
<th>Owner</th>
<th>OS</th>
<th>OS Version</th></tr>';
	$query = "SELECT * FROM tblServers";
	$result = mysql_query($query);
	
	
	
	while($row = mysql_fetch_array($result)){
	    
	        echo '<tr bgcolor=white><form action=updateServer.php method="GET">';
			echo '
			<td nowrap="nowrap"><input type="hidden" name="serverID" value="' . $row['serverID'] . '"><input type="hidden" name="updated" value="true">	
			      | <input type="submit" value="Update" class="tdtxt"> 
			      | <a href="viewServer.php?serverID='. $row['serverID']  .'" class="tdtxt">View</a>
			      | <a href="removeServer.php?serverID='. $row['serverID']  .'" class="tdtxt">Delete</a>
			      |</td>
			
				  <td><input type="text" name="key" value="' .         $row['skeys'] .      '" class="tdtxt"  style="width: 60px;"></td>
			      <td><input type="text" name="serverName" value="' .  $row['serverName'] . '" class="tdtxt"></td>
			      <td><input type="text" name="serial" value="' .      $row['serial']  .    '" class="tdtxt"></td> 
                  <td><input type="text" name="serverAlias" value="' . $row['alias']  .     '" class="tdtxt"></td>
                  <td><input type="text" name="alias2" value="' .      $row['alias2']  .    '" class="tdtxt"></td>                         
			      <td><input type="text" name="method" value="' .      $row['method'] .     '" class="tdtxt" maxlength="10"  style="width: 50px;"></td>
			      <td><input type="text" name="speed" value="' .       $row['speed'] .      '" class="tdtxt" maxlength="10"  style="width: 50px;"></td>
                  <td><input type="text" name="pncon" value="' .       $row['pncon'] .      '" class="tdtxt" maxlength="10"  style="width: 50px;"></td>
                  <td><input type="text" name="sncon" value="' .       $row['sncon'] .      '" class="tdtxt" maxlength="10"  style="width: 50px;"></td>
			      <td><input type="text" name="active" value="' .      $row['active'] .     '" class="tdtxt" maxlength="1" style="width: 30px;"></td>
                  <td><input type="text" name="owner" value="' .       $row['owner'] .      '" class="tdtxt"></td>
			      <td><input type="text" name="osID" value="' .        $row['osID'] .       '" class="tdtxt"></td>
                  <td><input type="text" name="osVer" value="' .       $row['osver'] .      '" class="tdtxt"></td>';
            	  echo '</form></tr>';
	    
	}

}


function updateTable($serverID, $serial, $active, $serverName, $serverAlias, $cost, $osID, $osVer, $typeID, $owner, $key, $aliasTwo, $method, $speed, $pncon, $sncon){
	include 'connecttodb.php';
	mysql_select_db("svrmgr");
	
	$query = 'delete from tblServers WHERE serverID = ' . $serverID . ' ';

mysql_query($query);
echo '<font color=green><b>Server '. $serverName .' has been removed! Add it back with the link below:</b></font><br>';
echo '<a href="enterserver.php

	?serial= ' . $serial  . '
	&serverName=' . $serverName . '
	&serverAlias=' . $serverAlias . '
	&tblOS=' . $osID  . '
	&osver=' . $osVer  . '
	&key=' . $key  . '
	&owner=' . $owner  . '
	&alias2=' . $aliasTwo  . '
	&method=' . $method  . '
	&speed=' . $speed  . '
	&pncon=' . $pncon  . '
	&sncon=' . $sncon  . '
	&cost=' . $cost  . '

	target="_blank">Edit</a>';

}



?>
 
