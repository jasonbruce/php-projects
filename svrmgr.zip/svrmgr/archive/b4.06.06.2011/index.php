<?php
include 'headtag.php';
include 'menu.php';
include 'searchForm.php';
include 'connecttodb.php';

echo '<div class="reportSection">';
totalServers();
physVsVirt();
osTotals();
osVerTotals();
showTable("totalActInact", "Active", "active", "active", "active");
echo '</div>';

function totalServers()
{
	echo '<div class="totalSvr">';
		echo '<table class="report">
					<tr>
							<th>Owner</th>
							<th>#</th>
					</tr>';
					
		$query = "select count(serverName) as result  from tblServers where owner = 'DEV' ";
		 $result = mysql_query($query);
				while($row = mysql_fetch_array($result)){
					echo '<tr>
									<td>Development</td>
									<td>' .	$row['result'] . '</td>
								</tr>';
				}
				
		$query = "select count(serverName) as result  from tblServers where owner = 'SVR' ";
		 $result = mysql_query($query);
				while($row = mysql_fetch_array($result)){

								echo '<tr>
									<td>Server</td>
									<td>' .	$row['result'] . '</td>
								</tr>';

				}
		
		$query = "select count(serverName) as result  from tblServers where owner = 'NET' ";
		 $result = mysql_query($query);
				while($row = mysql_fetch_array($result)){

								echo '<tr>
									<td>Network</td>
									<td>' .	$row['result'] . '</td>
								</tr>';

				}
				
				
				
	echo '</table>';	
	echo '</div>';
}

function physVsVirt()
{
	echo '<div class="totalPV">';
		echo '<table class="report">
					<tr>
							<th>Phys/Virt</th>
							<th>#</th>
					</tr>';
					
		$query = "select count(pvState) as result  from tblServers where pvState = 'PHYSICAL' ";
		 $result = mysql_query($query);
				while($row = mysql_fetch_array($result)){
					echo '<tr>
									<td>Physical</td>
									<td>' .	$row['result'] . '</td>
								</tr>';
				}
		$query = "select count(pvState) as result  from tblServers where pvState = 'VIRTUAL' ";
		 $result = mysql_query($query);
				while($row = mysql_fetch_array($result)){
					echo '<tr>
									<td>Virtual</td>
									<td>' .	$row['result'] . '</td>
								</tr>';
				}

		echo '</table></div>';		
				
}

function osTotals()
{
	echo '<div class="totalOS">';
		echo '<table class="report">
					<tr>
							<th>OS</th>
							<th>#</th>
					</tr>';
					
		$query = "select count(osID) as result  from tblServers where osID = 'LINUX' ";
		$result = mysql_query($query);
				while($row = mysql_fetch_array($result)){
					echo '<tr>
									<td>Linux</td>
									<td>' .	$row['result'] . '</td>
								</tr>';
				}
		$query = "select count(osID) as result  from tblServers where osID = 'WINDOWS' " ;
		$result = mysql_query($query);
				while($row = mysql_fetch_array($result)){
					echo '<tr>
									<td>Windows</td>
									<td>' .	$row['result'] . '</td>
								</tr>';
				}
		$query = "select count(osID) as result  from tblServers where osID = 'ESX' ";
		$result = mysql_query($query);
				while($row = mysql_fetch_array($result)){
					echo '<tr>
									<td>ESX</td>
									<td>' .	$row['result'] . '</td>
								</tr>';
				}
		$query = "select count(osID) as result  from tblServers where osID = 'HP-UX' ";
		$result = mysql_query($query);
				while($row = mysql_fetch_array($result)){
					echo '<tr>
									<td>HP-UX</td>
									<td>' .	$row['result'] . '</td>
								</tr>';
				}
		$query = "select count(osID) as result  from tblServers where osID = 'AIX' ";
		$result = mysql_query($query);
				while($row = mysql_fetch_array($result)){
					echo '<tr>
									<td>AIX</td>
									<td>' .	$row['result'] . '</td>
								</tr>';
				}	
		
		echo '</table></div>';

}

function osVerTotals()
{
	echo '<div class="totalOSVer">';
		echo '<table class="report">
					<tr>
							<th>OS Version</th>
							<th>#</th>
					</tr>';
					
		$query = "select distinct count(osver) as result,  osver as title from tblServers group by osver";
		$result = mysql_query($query);
				while($row = mysql_fetch_array($result)){
							if ($row['title'] == "")
							{
							}else{
								echo '<tr>
									<td>' . $row['title'] . '</td>
									<td>' .	$row['result'] . '</td>
								</tr>';
							}
				}
		
		
		echo '</table></div>';

}

function showTable($class, $header, $cFld, $cTitle, $cGroup)
{
	echo '<div class=" '  . $class .' ">';
		echo '<table class="report">
					<tr>
							<th>' .  $header . ' </th>
							<th>#</th>
					</tr>';
					
		$query = 'select distinct count('. $cFld. ') as result,  ' . $cTitle . ' as title from tblServers group by '. $cGroup;
		$result = mysql_query($query);
				while($row = mysql_fetch_array($result)){
							if ($row['title'] == "")
							{
							}else{
								echo '<tr>
									<td>' . $row['title'] . '</td>
									<td>' .	$row['result'] . '</td>
								</tr>';
							}
				}
		
		
		echo '</table></div>';



}

?>
