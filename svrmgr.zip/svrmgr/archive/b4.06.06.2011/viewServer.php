<?php
include 'headtag.php';
include 'menu.php';
include 'searchForm.php';
include 'pingit.php';

$serverID	 =   $_GET['serverID'];
$skeys		 =   strtoupper(mysql_real_escape_string($_GET['skeys']));
$serverName   	 =   strtoupper(mysql_real_escape_string($_GET['serverName']));
$serial   	 =   strtoupper(mysql_real_escape_string($_GET['serial']));
$alias   	 =   strtoupper(mysql_real_escape_string($_GET['alias']));
$alias2   	 =   strtoupper(mysql_real_escape_string($_GET['alias2']));
$alias3   	 =   strtoupper(mysql_real_escape_string($_GET['alias3']));
$alias4   	 =   strtoupper(mysql_real_escape_string($_GET['alias4']));
$alias5   	 =   strtoupper(mysql_real_escape_string($_GET['alias5']));
$method   	 =   strtoupper(mysql_real_escape_string($_GET['method']));
$speed   	 =   strtoupper(mysql_real_escape_string($_GET['speed']));
$pncon   	 =   strtoupper(mysql_real_escape_string($_GET['pncon']));
$sncon   	 =   strtoupper(mysql_real_escape_string($_GET['sncon']));
$active    	 =   strtoupper(mysql_real_escape_string($_GET['active']));
$owner   	 =   strtoupper(mysql_real_escape_string($_GET['owner']));
$osID   	 =   strtoupper(mysql_real_escape_string($_GET['osID']));
$osver   	 =   strtoupper(mysql_real_escape_string($_GET['osver']));
$typeID   	 =   strtoupper(mysql_real_escape_string($_GET['typeID']));
$cost   	 =   strtoupper(mysql_real_escape_string($_GET['cost']));
$comments   	 =   strtoupper(mysql_real_escape_string($_GET['comments']));
$pvState 			 =   strtoupper(mysql_real_escape_string($_GET['pvState']));
$osLic 			 =   strtoupper(mysql_real_escape_string($_GET['osLic']));



if ($skeys != "") {
	updateServer($serverID,$skeys,$serverName,$serial,$alias,$alias2,$alias3,$alias4,$alias5,$method,$speed,$pncon,$sncon,$active,$owner,$osID,$osver,$typeID,$cost,$comments, $pvState, $osLic);

}

displayData($serverID);

echo '<br><br><center><div class="notes">
        <p>The table above is editable. Simply click in the cell you wish to edit, make your edits, hit "ENTER" or click the Update button on the action column.</p> 
</div></center>';



function updateServer($serverID, $skeys, $serverName, $serial, $alias, $alias2, $alias3, $alias4, $alias5, $method, $speed, $pncon, $sncon, $active, $owner, $osID, $osver, $typeID, $cost, $comments, $pvState, $osLic){
include 'connecttodb.php';
        mysql_select_db("svrmgr");
        $query = 'Update `tblServers` SET `comments`="'. $comments .'", `osID`="'. $osID .'",`osver`="'. $osver  .'", `skeys`="' . $skeys  . '",`pncon`="' . $pncon  . '",`sncon`="' . $sncon  . '",`speed`="' . $speed  . '",`alias2`="' . $alias2  . '",`method`="' . $method  . '", `active`="' . $active . '", `serverName`="' . $serverName . '", `serial`="' . $serial . '", `owner`="' . $owner . '", `alias`="' . $alias . '", `alias3`="' . $alias3 . '", `alias4`="' . $alias4 . '", `alias5`="' . $alias5 . '", `pvState`="' . $pvState . ' ", `osLic`="'. $osLic .' " WHERE `serverID` = ' . $serverID . ' ';
        mysql_query($query);
        echo '<font color=green><b>Your data has been updated</b></font>';




}







function displayData($serverID){
	include 'connecttodb.php';
	$query = "Select * from tblServers where serverID = $serverID";
	$result = mysql_query($query);
     
		
		while($row = mysql_fetch_array($result)){
            $pingStat = ping($row['serverName']) ;
			if ($pingStat == "Online")
			{
				$tdColor = "#4E9258";
			}else{
				$tdColor = "#E77471";
			}   
				
				echo '

			<h2><u> ' . $row['serverName']  . ' </u></h2><hr><br><br>
	     		      <table class="viewServerTable">
			      
			      <form action=viewServer.php method="get">
				                                  <input type="hidden" name="serverID"          value="' . $row['serverID'].'">
			      <tr><th>Key (short name): </th>   <td><input type="text" name="skeys"	 	value="' . $row['skeys']  . '" class="tdvtxt"></td></tr>
			      <tr><th>Server Name: 	</th>	<td><input type="text" name="serverName" 	value="' . $row['serverName'] . '" class="tdvtxt"></td></tr>
                              <tr><th>Serial: 		</th>	<td><input type="text" name="serial" 		value="' . $row['serial']  . '" class="tdvtxt"></td></tr>
	                      <tr><th>Server Alias1: 	</th>	<td><input type="text" name="alias" 		value="' . $row['alias']  . '" class="tdvtxt"></td></tr>
                              <tr><th>Server Alias2:    </th>   <td><input type="text" name="alias2" 		value="' . $row['alias2']  . '" class="tdvtxt"></td></tr>
			      <tr><th>Server Alias3:    </th>   <td><input type="text" name="alias3" 		value="' . $row['alias3']  . '" class="tdvtxt"></td></tr>
                              <tr><th>Server Alias4:    </th>   <td><input type="text" name="alias4" 		value="' . $row['alias4']  . '" class="tdvtxt"></td></tr>
                              <tr><th>Server Alias5:    </th>   <td><input type="text" name="alias5" 		value="' . $row['alias5']  . '" class="tdvtxt"></td></tr>
			      <tr><th>Method:           </th>   <td><input type="text" name="method"	 	value="' . $row['method']  . '" class="tdvtxt"></td></tr>
			      <tr><th>Speed:            </th>   <td><input type="text" name="speed"	 	value="' . $row['speed']  . '" class="tdvtxt"></td></tr>
			      <tr><th>PN Connection:    </th>   <td><input type="text" name="pncon"	 	value="' . $row['pncon']  . '" class="tdvtxt"></td></tr>
                              <tr><th>SN Connection:    </th>   <td><input type="text" name="sncon"	 	value="' . $row['sncon']  . '" class="tdvtxt"></td></tr>
			      <tr><th>Active: 		</th>	<td><input type="text" name="active" 	  	value="' . $row['active'] . '" class="tdvtxt"></td></tr>
				  <tr><th>Physical or Virtual: 		</th>	<td><input type="text" name="pvState" 	  	value="' . $row['pvState'] . '" class="tdvtxt"></td></tr>
                              <tr><th>Owner: 		</th>	<td><input type="text" name="owner" 		value="' . $row['owner'] . '" class="tdvtxt"></td></tr>
		      	      <tr><th>OS:		</th>	<td><input type="text" name="osID" 		value="' . $row['osID']  . '" class="tdvtxt"></td></tr>
			      <tr><th>OS Version:    	</th>   <td><input type="text" name="osver" 		value="' . $row['osver']  . '" class="tdvtxt"></td></tr>
			      <tr><th>Type:		</th>	<td><input type="text" name="typeID" 		value="' . $row['typeID']  . '" class="tdvtxt"></td>
                              <tr><th>Cost: 		</th>	<td><input type="text" name="cost" 		value="' . $row['cost'] . '" class="tdvtxt"></tr>
							  <tr><th>License: 		</th>	<td><input type="text" name="osLic" 		value="' . $row['osLic'] . '" class="tdvtxt"></tr>
			      <tr><th>Description: 	</th>	<td><textarea 	    name="comments" rows="20" cols="50">'. $row['comments'] . '</textarea></tr>
				  <tr><th>Online Status:</th>	<td bgcolor="' .  $tdColor .'">' .  $pingStat . ' </td></tr>
			      <tr><td colspan=2><center><input type="submit" value="Update Server"></center></td></tr>	
			      
			      </form>
		</table>';
	}
	
}


function displaySubData($fld, $serverID){
        include 'connecttodb.php';
       	if ($fld == "type") {
		$query = "Select * from tblType where typeID = '$serverID'";
	        $result = mysql_query($query);
	        while($row = mysql_fetch_array($result)){
        	        echo '<td>'. $row['make'] . '--' . $row['model']  .'</td>';
	        }

	}
        if ($fld == "OS") {
                $query = "Select * from tblOS where osID = '$serverID'";
		$result = mysql_query($query);
                while($row = mysql_fetch_array($result)){
        		echo '<td>'. $row['osName'] . '</td>';
                }
        }
	
}



?>
