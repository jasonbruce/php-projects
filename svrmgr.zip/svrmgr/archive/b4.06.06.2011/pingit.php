<?php
function ping($host) {
		$result = exec("ping  $host -c 1"); 
		if ($result == "" )
		{
			$result = "<b><u>Offline</u></b>";
		}else{
			$result = "Online";
		}
		return $result;
}
?>