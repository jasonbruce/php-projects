<?php

include 'headtag.php';
include 'menu.php';
include 'searchForm.php';

//010101010110111101110000011101110010101101010101000110100101//
//01010011011                                10111010101001001//
//00010111010     VARIABLE DECLARATION       01010000110100001//
//01000110011                                00111000101101001//
//010101010110111101110000011101110010101101010101000110100101//


	$comments            = strtoupper(mysql_real_escape_string ($_GET['comments']));
	$owner               = strtoupper(mysql_real_escape_string (trim($_GET['owner'])));
	$type                = strtoupper(mysql_real_escape_string (trim($_GET['tblType'])));
	$os                  = strtoupper(mysql_real_escape_string (trim($_GET['tblOS'])));
	$ip                  = mysql_real_escape_string (trim($_GET['tblIP']));
	$servName            = strtoupper(mysql_real_escape_string (trim($_GET['serverName'])));
	$servAlias           = strtoupper(mysql_real_escape_string (trim($_GET['serverAlias'])));
	$warDate             = mysql_real_escape_string ($_GET['warrantyStartDate']);
	$dateInService       = mysql_real_escape_string ($_GET['dateInService']);
	$newMake             = strtoupper(mysql_real_escape_string (trim($_GET['txtMake'])));
	$newModel            = strtoupper(mysql_real_escape_string (trim($_GET['txtModel'])));
	$newOS               = strtoupper(mysql_real_escape_string (trim($_GET['txtOSName'])));
	$newIP               = mysql_real_escape_string (trim($_GET['txtIPAddress']));
	$serial		         = strtoupper(mysql_real_escape_string (trim($_GET['serial'], " ")));
	$alias2              = strtoupper(mysql_real_escape_string (trim($_GET['alias2'], " ")));
	$alias3              = strtoupper(mysql_real_escape_string (trim($_GET['alias3'], " ")));
	$alias4              = strtoupper(mysql_real_escape_string (trim($_GET['alias4'], " ")));
	$alias5              = strtoupper(mysql_real_escape_string (trim($_GET['alias5'], " ")));
	$pncon               = strtoupper(mysql_real_escape_string (trim($_GET['pncon'], " ")));
	$sncon               = strtoupper(mysql_real_escape_string (trim($_GET['sncon'], " ")));
	$speed               = strtoupper(mysql_real_escape_string (trim($_GET['speed'], " ")));
	$method              = strtoupper(mysql_real_escape_string (trim($_GET['method'], " ")));
	$osver               = strtoupper(mysql_real_escape_string (trim($_GET['osver'], " ")));
	$key                 = strtoupper(mysql_real_escape_string (trim($_GET['key'], " ")));
	$pvState			= strtoupper(mysql_real_escape_string (trim($_GET['pvState'], " ")));
	$osLic				= strtoupper(mysql_real_escape_string (trim($_GET['osLic'], " ")));

//010101110110111101110000011101110010101111000111000111100001//
//010100110110110101110001010110110010101101010111010101001001//
//000101110100111101010000011101110010101110001010000110100001//
//010001100110101101110010011101111010111011000111000101101001//
//010101010110111101110000011101110010101101010101000110100101//



//--------------------------------------------------------------//
//--------------------------------------------------------------//
//---------------------Main Section-----------------------------//
//--------------------------------------------------------------//
//--------------------------------------------------------------//

if ($serial == "") {
	displayVarForm($type, $os, $ip, $servName, $servAlias, $warDate, $dateInService,    $type, $newModel, $newMake,  $newOS, $newIP, $serial, $owner, $comments, $alias2, $alias3, $alias4, $alias5, $osver, $pncon, $sncon, $speed, $method, $key, $pvState, $osLic);
}else{
	echo '<div class="errorDiv">';
	echo  '<font color=red><b>';
		$validated = validateFormData($type, $os, $ip, $servName, $servAlias, $warDate, $dateInService, $newModel, $newModel, $newOS, $newIP, $serial, $comments, $alias2, $alias3, $alias4, $alias5, $osver, $pncon, $sncon, $speed, $method, $key, $pvState, $osLic);
	echo  '</font></b>';

	if ($validated == "true") {
		echo '<i>No Errors Found</div>';
		InputServerInfo($type, $os, $ip, $servName, $servAlias, $warDate, $dateInService, $type, $newModel, $newMake, $newOS, $newIP, $serial, $owner, $comments, $alias2, $alias3, $alias4, $alias5, $osver, $pncon, $sncon, $speed, $method, $key, $pvState, $osLic);
		//displayVarForm($type, $os, $ip, $servName, $servAlias, $warDate, $dateInService,    $type, $newModel, $newMake,  $newOS, $newIP, $serial, $owner, $comments, $alias2, $alias3, $alias4, $alias5, $osver, $pncon, $sncon, $speed, $method, $key);
		
	}else{
		echo '<br><br><b><i>Please fix the errors above on the form below.</i></b><br></div>';
		displayVarForm($type, $os, $ip, $servName, $servAlias, $warDate, $dateInService,    $type, $newModel, $newMake,  $newOS, $newIP, $serial, $owner, $comments, $alias2, $alias3, $alias4, $alias5, $osver, $pncon, $sncon, $speed, $method, $key, $pvState, $osLic);
	}
}

//---------------------------------------------------------------//
//---------------------------------------------------------------//
//---------------------------------------------------------------//
//---------------------------------------------------------------//
//---------------------------------------------------------------//
//---------------------------------------------------------------//


//888888888888888888888888888888888888888888888888888888888888888//
//8888    INPUT SERVER INFO FUNCTION   88888888888888888888888888//
//8888    Function that inserts data   88888888888888888888888888//
//8888    into the database            88888888888888888888888888//
//888888888888888888888888888888888888888888888888888888888888888//
function InputServerInfo($type, $os, $ip, $servName, $servAlias, $warDate, $dateInService, $type,  $newModel, $newMake, $newOS, $newIP, $serial, $owner, $comments, $alias2, $alias3, $alias4, $alias5, $osver, $pncon, $sncon, $speed, $method, $key, $pvState, $osLic)
{
	include 'connecttodb.php';
	if ($newModel != "" || $newType != "" || $newOS != "" || $newIP != "") {
		if ($newModel != "" || $newType != ""){
			$type = $newMake . ' ' . $newModel;		
		}
		if ($newIP != ""){
                        $query = "INSERT INTO tblIP (ipAddress) VALUES ('$newIP')";
                        mysql_query($query);
                        //echo '<br></i><b>IP Table Updated with:</b> '. $newIP;
			$query = "SELECT * FROM tblIP WHERE ipAddress = '$newIP'";
                        $result = mysql_query($query);
                                while($row = mysql_fetch_array($result)){
                                        $ip = $row['ipID'];
                                }
		}
		if ($newOS != ""){
			$os = $newOS;
                }

	
	}
	$query = "INSERT INTO tblServers (serverName, alias, warrantyStartDate, dateInService, comments, typeID, ipID, active, osID, serial, owner, alias2, alias3, alias4, alias5, osver, pncon, sncon, speed, method, skeys, pvState, osLic) VALUES ('$servName','$servAlias', '$warDate', '$dateInService', '$comments', '$type', '$ip', 'Y', '$os', '$serial', '$owner', '$alias2', '$alias3', '$alias4', '$alias5', '$osver', '$pncon', '$sncon', '$speed', '$method', '$key', '$pvState', '$osLic')";
	mysql_query($query);
	echo '<br> <br>Your data has been entered!</i>';
	echo '<br> <u><b>Serial</b></u>: ' . $serial;
	echo '<br> <u><b>Key</b></u>: ' . $key;
	echo '<br> <u><b>Server Name</b></u>: ' . $servName;
	echo '<br> <u><b>Physical / Virtual</b></u>: ' . $pvState;
	echo '<br> <u><b>Alias 1</b></u>: ' . $servAlias;
	echo '<br> <u><b>Alias 2</b></u>: ' . $alias2;
	echo '<br> <u><b>Alias 3</b></u>: ' . $alias3;
	echo '<br> <u><b>Alias 4</b></u>: ' . $alias4;
	echo '<br> <u><b>Alias 5</b></u>: ' . $alias5;
	echo '<br> <u><b>Warranty</b></u>: ' . $warDate;
	echo '<br> <u><b>Date In Service</b></u>: ' . $dateInService;
	echo '<br> <u><b>Type</b></u>: ' . $type;
	echo '<br> <u><b>IP Address</b></u>: ' . $ip;
	echo '<br> <u><b>OS Name</b></u>: ' . $os;
	echo '<br> <u><b>OS Version</b></u>: ' . $osver;
	echo '<br> <u><b>Owner</b></u>: ' . $owner;
	echo '<br> <u><b>PN Connection</b></u>: ' . $pncon;
	echo '<br> <u><b>SN Connection</b></u>: ' . $sncon;
	echo '<br> <u><b>Speed</b></u>: ' . $speed;
	echo '<br> <u><b>Method</b></u>: ' . $method;
	echo '<br> <u><b>OS License</b></u>: ' . $osLic;
	echo '<br> <u><b>Description / Comments</b></u>: ' . $comments;
	
	//echo '<br>' . $query;
}
//888888888888888888888888888888888888888888888888888888888888888//
//888888888888888888888888888888888888888888888888888888888888888//
//8888888888888      END OF INPUT FUNCTION    8888888888888888888//
//888888888888888888888888888888888888888888888888888888888888888//
//888888888888888888888888888888888888888888888888888888888888888//


//:) :O :D :/ :\ ;) :) :O :D :/ :\ ;) :) :O :D :/ :\ ;):) :O :D ://
//:) :O :D                                           ;):) :O :D ://
//:) :O :D         DISPLAY FORM FUNCTION             ;):) :O :D ://
//:) :O :D                                           ;):) :O :D ://
//:) :O :D :/ :\ ;) :) :O :D :/ :\ ;) :) :O :D :/ :\ ;):) :O :D ://
function displayVarForm($type, $os, $ip, $servName, $servAlias, $warDate, $dateInService, $type, $newType, $newModel, $newOS, $newIP, $serial, $owner, $comments, $alias2, $alias3, $alias4, $alias5, $osver, $pncon, $sncon, $speed, $method, $key, $pvState, $osLic){
echo '
<br>
<br>
<div class="EnterForm">
<form action=enterserver.php class=serverForm>
<table class="enterFormTbl">
	<tr>
		<td width=150px class="lbl">Select Hardware Type:</td>
		<td width=150px>';		
		CreateAndPopulateDropDown("tblType", "typeID");
echo '		</td>';
		echo '<td><input type=button name=type value="Enter New Type" onClick="showDiv(\'EnterType\');" class="showHideBtn"></td>';
echo '	
		<td>	<div id="EnterType" class="formDiv">
				Model: 
				<input type="text" name="txtModel" value="'. $newModel  . ' "><br>
				Make: 
				<input type="text" name="txtMake" value="'. $newType  .'">
			</div>
		</td>
	</tr>
	<tr>
		<td class="lbl">Select OS:</td>
		<td  class="input">';		
		CreateAndPopulateDropDown("tblOS", "osID");
echo '		</td>
		<td><input type=button name=type value="Enter New OS" onClick="showDiv(\'EnterOS\');" class="showHideBtn"></td>
		<td>
			<div id="EnterOS" class="formDiv">
				OS Name: 
				<input type="text" name="txtOSName" value="'. $os .'">
			</div>
		</td>
	</tr>
	<tr>
                	<td class="lbl">OS Version: </td>
        	        <td colspan=4  class="input">';
					CreateAndPopulateDropDown("osver", "osver");
					echo '</td>
	</tr>
	<tr>
		<td class="lbl">Enter IP:</td>
		<td  class="input"><input type="text" name="txtIPAddress" value="000.000.000.000"></td>
	</tr>
	<tr>
                <td class="lbl">Serial: </td>
                <td colspan=4  class="input"><input type="text" name="serial" value="' . $serial . '"></td>
        </tr>
	<tr>
		<td class="lbl">Server Name: </td>
		<td colspan=4  class="input"><input type="text" name="serverName" value="' . $servName . '"></td>
	</tr>
        <tr>
                <td class="lbl">Key <i>(Short Name)</i>: </td>
                <td colspan=4 class="input"><input type="text" name="key" value="' . $key . '"></td>
        </tr>
	<tr>
		<td class="lbl">Physical / Virtual: </td>
		<td colspan=4  class="input">';
		CreateAndPopulateDropDown("pvState", "pvState");
echo '</td>
	</tr>
	<tr>
                <td class="lbl">Owner: </td>
                <td colspan=4  class="input"><select name="owner">
			<option>DEV</option>
			<option>SVR</option>
			<option>NET</option>
			<option>Other (enter in comments)</option>
		</select></td>
        </tr>
	<tr>
		<td class="lbl">Server Alias 1: </td>
		<td colspan=4 class="input"><input type="text" name="serverAlias" value="' . $servAlias . '"></td>
	</tr>
        <tr>
                <td class="lbl">Server Alias 2: </td>
                <td colspan=4 class="input"><input type="text" name="alias2" value="' . $alias2 . '"></td>
        </tr>
        <tr>
                <td class="lbl">Server Alias 3: </td>
                <td colspan=4 class="input"><input type="text" name="alias3" value="' . $alias3 . '"></td>
        </tr>
        <tr>
                <td class="lbl">Server Alias 4: </td>
                <td colspan=4 class="input"><input type="text" name="alias4" value="' . $alias4 . '"></td>
        </tr>
        <tr>
                <td class="lbl">Server Alias 5: </td>
                <td colspan=4 class="input"><input type="text" name="alias5" value="' . $alias5 . '"></td>
        </tr>
        <tr>
                <td class="lbl">Method: </td>
                <td colspan=4 class="input"><input type="text" name="method" value="' . $method . '"></td>
        </tr>
        <tr>
                <td class="lbl">Speed: </td>
                <td colspan=4 class="input"><input type="text" name="speed" value="' . $speed . '"></td>
        </tr>
        <tr>
                <td class="lbl">PN Connection: </td>
                <td colspan=4 class="input"><input type="text" name="pncon" value="' . $pncon . '"></td>
        </tr>
        <tr>
                <td class="lbl">SN Connection: </td>
                <td colspan=4 class="input"><input type="text" name="sncon" value="' . $sncon . '"></td>
        </tr>
	<tr>
		<td class="lbl">Cost: </td>
		<td colspan =4 class="input"><input type="text" name="cost" value="' . $cost . '"></td>
        </tr>
	<tr>
		<td class="lbl">Warranty Start Date:</td>
		<td colspan=4 class="input"><input type="text" name="warrantyStartDate" value="' . $warDate . '"></td>
	</tr>
	<tr>
		<td class="lbl">Date In Service: </td>
		<td colspan=4 class="input"><input type="text" name="dateInService" value="' . $dateInService . '"></td>
	</tr>
	<tr>
		<td class="lbl">License: </td>
		<td colspan=4 class="input"><input type="text" name="osLic" value="' . $osLic . '"></td>
	</tr>	
        <tr>
                <td class="lbl">Description/Comments: </td>
                <td colspan=4 class="input"><textarea name="comments" rows="10" cols="50">' . $comments . '</textarea></td>
        </tr>
	<tr>
		<td colspan=2><center><input type=submit value="Enter Server"></center></td>
	</tr>
</table>
</form>
</div>
<br>
</body>
';

}
//:) :O :D :/ :\ ;) :) :O :D :/ :\ ;) :) :O :D :/ :\ ;):) :O :D ://
//:) :O :D :/ :\ ;) :) :O :D :/ :\ ;) :) :O :D :/ :\ ;):) :O :D ://
//:) :O :      END OF DISPLAY FORM FUNCTION       :\ ;):) :O :D ://
//:) :O :D :/ :\ ;) :) :O :D :/ :\ ;) :) :O :D :/ :\ ;):) :O :D ://
//:) :O :D :/ :\ ;) :) :O :D :/ :\ ;) :) :O :D :/ :\ ;):) :O :D ://


//!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&//
//!@#$%^&                                           (){}[]!@#$%^&//
//!@#$%^&         Validation Function               (){}[]!@#$%^&//
//!@#$%^&                                           (){}[]!@#$%^&//
//!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&//         
function validateFormData($type, $os, $ip, $servName, $servAlias, $warDate, $dateInService, $newType, $newModel, $newOS, $newIP, $owner, $cost, $alias2, $alias3, $alias4, $alias5, $osver, $pncon, $sncon, $speed, $method, $key, $pvState, $osLic){

$validated = "true";
	if ($type == "Select From List" && $newMake == "" && $newModel == "" || $type == "" ){
		$validated = "false";
		echo 'Type not correct';
		if ($newMake == "" || $newModel == ""){
			echo '<br>If you are entering a new Server Type, Make and Model are REQUIRED.';
			$validated = "false";
		}
	}
	if ($os == "Select From List" && $newOS == "" || $os = ""){
		echo '<br>OS is not selected';
		$validated = "false";
	}
		if ($newIP != ""){	
			if ($ip == ""){
				$numberFound = checkIPAddress($newIP);
			}
			if (strlen($numberFound) != 3){
				echo '<br>The IP Address you entered ('. $ip . ') is not in the proper format! You have ' . strlen($numberFound) . ' .\'s and you need only 3.';
				$validated = "false";
			}
		}
	if ($servName == "") {
		echo '<br>Server Name was left blank.';
		$validated = "false";
	}	
return $validated;
}

function checkIPAddress($ipaddress){
$numberFound = "";
	for ($i = 0; $i < 16; $i +=1){
		$character = substr($ipaddress, $i,1);
		if ($character == "."){
			$numberFound = $numberFound . $character;
		}
	}
return $numberFound;
}
//!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&//
//!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&//
//!@#$%^&*(      END OF VALIDATION FUNCTION     %^&*(){}[]!@#$%^&//
//!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&//
//!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&*(){}[]!@#$%^&//



/////////////////////////////////////////////////////////////////
///////////                                 /////////////////////
///////////     CREATE DD FUNCTION          /////////////////////
///////////                                 /////////////////////
/////////////////////////////////////////////////////////////////
function CreateAndPopulateDropDown($tbl, $field){
include 'connecttodb.php';
$query = "SELECT distinct $field FROM tblServers";

echo '<select name="'. $tbl . '" class=frmSelect>';
echo '<option selected>Select From List</option>';
$result = mysql_query($query);
while($row = mysql_fetch_array($result)){
	if ($tbl == "tblType"){
		echo '<option value="'.$row['typeID'].'">'.$row['typeID'].'</option>';
	}
	if ($tbl == "tblOS"){
		echo '<option value="'.$row['osID'].'">'.$row['osID'].'</option>';
	}
	if ($tbl == "tblIP"){
		echo '<option value="'.$row['ipID'].'">'.$row['ipID'].'</option>';
	}
	if ($tbl == "pvState"){
		echo '<option value="'.$row['pvState'].'">'.$row['pvState'].'</option>';
	}
	if ($tbl == "osver"){
		echo '<option value="'.$row['osver'].'">'.$row['osver'].'</option>';
	}
}
echo '</select>';
}
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////



?> 
