<?php
include 'headtag.php';
include 'menu.php';
include 'searchForm.php';
$owner         = $_GET['owner'];
$serverName    = $_GET['serverName'];
$serverAlias   = $_GET['serverAlias'];
$active        = $_GET['active'];
$serverID      = $_GET['serverID'];
$serial        = trim($_GET['serial'], " ");
$updated       = "false";
$updated       = $_GET['updated'];
$key           = $_GET['key']; 
$aliasTwo      = $_GET['alias2'];
$method        = $_GET['method'];
$speed         = $_GET['speed'];
$pncon         = $_GET['pncon'];
$sncon         = $_GET['sncon'];
$osVer         = $_GET['osVer'];
$osID          = $_GET['osID'];
$ascdesc		= $_GET['ascdesc'];
$sortby			= $_GET['sortby'];
$pvState		= $_GET['pvState'];


if ($ascdesc=="ASC") 
{ 
	$ascdesc = "DESC" ;
} 
else 
{  
	$ascdesc = "ASC" ;
}
if ($sortby=="") 
{ 
	$sortby = "skeys" ;
}


include 'connecttodb';

if ($updated == "true"){
	updateTable($serverID, $serial, $active, $serverName, $serverAlias, $cost, $osID, $osVer, $typeID, $owner, $key, $aliasTwo, $method, $speed, $pncon, $sncon, $pvState);	
}
echo '<center><div class="updateTableDiv">';
displayTable($serial, $serverID, $sortby, $ascdesc);
echo '</table></div></center>';
echo '<br>';
echo '<center><div class="notes"> 
	<p>The table above is editable. Simply click in the cell you wish to edit, make your edits, hit "ENTER" or click the Update button on the action column. Once the data has been updated, the row will highlight yellow.
</div></center>';



function displayTable($serial, $serverID, $sortby, $ascdesc){
include 'connecttodb.php';
include 'pingit.php';

echo '<table class="validationtable">';
echo '
<th>Action</th>
<th><a href="ServerStatus.php?sortby=skeys&ascdesc=' . $ascdesc . '" class="sortLink">Key</a></th>
<th><a href="ServerStatus.php?sortby=serverName&ascdesc=' . $ascdesc . '" class="sortLink">Server/Host Name</a></th>
<th><a href="ServerStatus.php?sortby=active&ascdesc=' . $ascdesc . '" class="sortLink">Active</a></th>
<th><a href="ServerStatus.php?sortby=owner&ascdesc=' . $ascdesc . '" class="sortLink">Owner</a></th>
<th><a href="updateServer.php?sortby=pvState&ascdesc=' . $ascdesc . '" class="sortLink">Phys\Virt</a></th>
																														<th>Online Status</th></tr>';
	$query = "SELECT * FROM tblServers ORDER BY $sortby $ascdesc";
	$result = mysql_query($query);
	while($row = mysql_fetch_array($result)){
	    if ($row['active'] == "Y"){
		if($row['serverID']==$serverID){
		echo '<tr bgcolor=yellow><form action=ServerStatus.php method="GET">';
			$pingStat = ping($row['serverName']) ;
			if ($pingStat == "Online")
			{
				$tdColor = "#4E9258";
			}else{
				$tdColor = "#E77471";
			}
			echo '
			      <td nowrap="nowrap"><input type="hidden" name="serverID" value="' . $row['serverID'] . '"><input type="hidden" name="updated" value="true">	
			      | <input type="submit" value="Update" class="tdvtxt"> 
			      | <a href="viewServer.php?serverID='. $row['serverID']  .'" class="tdvtxt">View</a>

			      |</td>
				  <td><input type="text" name="key" value="' . $row['skeys'] . '" class="tdvtxt"  style="width: 60px;"></td>
			      <td><input type="text" name="serverName" value="' .   $row['serverName'] . '" class="tdvtxt"></td>
			      <td><input type="text" name="active" value="' .       $row['active'] . '" class="tdvtxt" maxlength="1" style="width: 30px;"></td>
			      <td><input type="text" name="owner" value="' .        $row['owner'] . '" class="tdvtxt" maxlength="20" style="width: 110px;"></td>
				  <td><input type="text" name="pvState" value="' .        $row['pvState'] . '" class="tdvtxt" maxlength="20" style="width: 90px;"></td>
				  <td bgcolor="' .  $tdColor .'" nowrap="nowrap">' .  $pingStat . '  </td>
				  <input type="hidden" name="ascdesc" value=" ' . $ascdesc . ' "> <input type="hidden" name="sortby" value=" ' . $sortby . ' ">';
		echo '</form></tr>';
	    }else{	
			echo '<tr bgcolor=white><form action=ServerStatus.php method="GET">';
			$pingStat = ping($row['serverName']) ;
			if ($pingStat == "Online")
			{
				$tdColor = "#4E9258";
			}else{
				$tdColor = "#E77471";
			}
			echo '
			<td nowrap="nowrap"><input type="hidden" name="serverID" value="' . $row['serverID'] . '"><input type="hidden" name="updated" value="true">	
			      | <input type="submit" value="Update" class="tdvtxt"> 
			      | <a href="viewServer.php?serverID='. $row['serverID']  .'" class="tdvtxt">View</a>

			      |</td>
				  <td><input type="text" name="key" value="' .          $row['skeys'] .      '" class="tdvtxt"  style="width: 60px;"></td>
			      <td><input type="text" name="serverName" value="' .   $row['serverName'] . '" class="tdvtxt"></td>
			      <td><input type="text" name="active" value="' .       $row['active'] .     '" class="tdvtxt" maxlength="1" style="width: 30px;"></td>
			      <td><input type="text" name="owner" value="' .        $row['owner'] . '" class="tdvtxt" maxlength="20" style="width: 110px;"></td>
			      <td><input type="text" name="pvState" value="' .        $row['pvState'] . '" class="tdvtxt" maxlength="20" style="width: 90px;"></td>
				  <td bgcolor="' .  $tdColor .'" nowrap="nowrap">' .  $pingStat . '  </td>
				  <input type="hidden" name="ascdesc" value=" ' . $ascdesc . ' "> <input type="hidden" name="sortby" value=" ' . $sortby . ' ">';
            	  echo '</form></tr>';
		}
	    }
	}

}


function updateTable($serverID, $serial, $active, $serverName, $serverAlias, $cost, $osID, $osVer, $typeID, $owner, $key, $aliasTwo, $method, $speed, $pncon, $sncon, $pvState){
	include 'connecttodb.php';
	mysql_select_db("svrmgr");
	$query = 'Update `tblServers` SET `osID`="'. $osID .'",`osver`="'. $osVer  .'", `skeys`="' . $key  . '",`pncon`="' . $pncon  . '",`sncon`="' . $sncon  . '",`speed`="' . $speed  . '",`alias2`="' . $aliasTwo  . '",`method`="' . $method  . '", `active`="' . $active . '", `serverName`="' . $serverName . '", `serial`="' . $serial . '", `owner`="' . $owner . '", `alias`="' . $serverAlias . '", `pvState`=" ' . $pvState . ' " WHERE `serverID` = ' . $serverID . ' ';
	mysql_query($query);
	echo '<font color=green><b>Your data has been updated</b></font>';
}



?>
