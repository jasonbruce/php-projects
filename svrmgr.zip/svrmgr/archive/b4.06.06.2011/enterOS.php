<?php
$name = mysql_real_escape_string($_GET['name']);

if ($name == ""){
    echo '
	<form action="enterOS.php" method="get">
	<table class="enterFormTbl">
		<tr>
			<td>OS Name: </td>
			<td><input type="text" name="name"></td>
		</tr>
		<tr>
			<td colspan=2><center><input type=submit value="Enter OS"></center></td>
		</tr>
	</table>
	</form>
     ';
}else{
include 'connecttodb.php';
$query = "INSERT INTO tblOS (osName) VALUES ('$name')";
mysql_query($query);
echo '
<b>Your OS has been entered</b>
<form action="enterOS.php" method="get">
	<table class="enterFormTbl">
		<tr>
			<td>OS Name: </td>
			<td><input type="text" name="name"></td>
		</tr>
		<tr>
			<td colspan=2><center><input type=submit value="Enter OS"></center></td>
		</tr>
	</table>
	</form>
';
}

?> 
