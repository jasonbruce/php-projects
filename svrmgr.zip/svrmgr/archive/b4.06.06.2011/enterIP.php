<?php
$name = mysql_real_escape_string($_GET['name']);

if ($name == ""){
    echo '
	<form action="enterIP.php" method="get">
	<table class="enterFormTbl">
		<tr>
			<td>IP Address: </td>
			<td><input type="text" name="name"></td>
		</tr>
		<tr>
			<td colspan=2><center><input type=submit value="Enter IP"></center></td>
		</tr>
	</table>
	</form>
     ';
}else{

$error = checkIPAddress($name);
if (strlen($error) != 3){
echo '
<b>Your IP has been entered</b>
<form action="enterIP.php" method="get">
	<table class="enterFormTbl">
		<tr>
			<td>IP Address: </td>';
echo '			<td><input type="text" name="name" value="'.$name.'"></td>';
echo '			<td><font color=red><b>IP ADDRESS is in an incorrect format!!</b></font></td>
		</tr>
		<tr>
			<td colspan=2><center><input type=submit value="Enter IP"></center></td>
		</tr>
	</table>
	</form>
';
}else{
include 'connecttodb.php';
$query = "INSERT INTO tblIP (ipAddress) VALUES ('$name')";
mysql_query($query);
echo '
<b><font color=red>Incorrect Format Error</font></b>
<form action="enterIP.php" method="get">
	<table class="enterFormTbl">
		<tr>
			<td>IP Address: </td>
			<td><input type="text" name="name" value="000.000.000.000"></td>
		</tr>
		<tr>
			<td colspan=2><center><input type=submit value="Enter IP"></center></td>
		</tr>
	</table>
	</form>
';
}
}


function checkIPAddress($ipaddress){
$numberFound = "";
	for ($i = 0; $i < 16; $i +=1){
		$character = substr($ipaddress, $i,1);
		if ($character == "."){
			$numberFound = $numberFound . $character;
		}
	}
return $numberFound;
}


?> 
