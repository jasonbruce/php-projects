<?php



	$search 	= 	$_GET['search'];

showSearchBar($search);
Space();
showSearchQuery($search);





function showSearchBar($search){
echo '
<center><div class="searchBarDiv">
	<center>	
		<form action="Search.php" method="get">
			Search For:  <input type="text" name="search" value="' . $search . '"><Input type="submit" value="Find IT!">
		</form>
	</center>
</div>
';

}

function showSearchQuery($search){
   if ($search != ""){
	echo '<div class="SearchResults">';
	echo '<b>Your Search for: </b> ' . $search;	
	Space();
           DisplaySearchField('Serial');
                SearchFor($search, 'serial');
           echo '</div>';
                Space();
           DisplaySearchField('Server Name');
                SearchFor($search, 'serverName');
           echo '</div>';
                Space();
           DisplaySearchField('Key Name');
                SearchFor($search, 'skeys');
           echo '</div>';
                Space();
           DisplaySearchField('Alias 1');
                SearchFor($search, 'alias');
           echo '</div>';
                Space();
           DisplaySearchField('Alias 2');
                SearchFor($search, 'alias2');
           echo '</div>';
                Space();
           DisplaySearchField('Alias 3');
                SearchFor($search, 'alias3');
           echo '</div>';
                Space();
           DisplaySearchField('Alias 4');
                SearchFor($search, 'alias4');
           echo '</div>';
                Space();
           DisplaySearchField('Alias 5');
                SearchFor($search, 'alias5');
           echo '</div>';
                Space();
           DisplaySearchField('Owner');
                SearchFor($search, 'owner');
           echo '</div>';
                Space();
           DisplaySearchField('Operating System');
                SearchFor($search, 'osID');
           echo '</div>';
                Space();
           DisplaySearchField('OS Version');
                SearchFor($search, 'osver');
           echo '</div>';
                Space();
           DisplaySearchField('Type');
                SearchFor($search, 'typeID');
           echo '</div>';
                Space();
           DisplaySearchField('Comments');
                SearchFor($search, 'comments');
           echo '</div>';
                Space();
           DisplaySearchField('IP Address');
                SearchFor($search, 'ipID');
           echo '</div>';
                Space();
           DisplaySearchField('Method');
                SearchFor($search, 'method');
           echo '</div>';
                Space();
           DisplaySearchField('Speed');
                SearchFor($search, 'speed');
           echo '</div>';
                Space();
           DisplaySearchField('PN Con');
                SearchFor($search, 'pncon');
           echo '</div>';
                Space();
           DisplaySearchField('SN Con');
                SearchFor($search, 'sncon');
           echo '</div>';
	echo '</div>';
    }
}

function SearchFor($search, $field){
include 'connecttodb.php';
$query = "SELECT * FROM tblServers WHERE $field LIKE '%$search%'";
Space();
        $result = mysql_query($query);
	$nrows = mysql_num_rows($result);
        echo $nrows . ' <i>Results Found</i><br>';	
	if ($nrows > 0){
        	while($row = mysql_fetch_array($result)){
			echo '<i><a href="viewServer.php?serverID=' . $row['serverID'] .'" class="searchResultA">' . $row['serverName'] .'</a></i>';
			echo "<i>\t\t ";
			echo $row['skeys'];
			echo "\t\t ";
			echo $row['serial'];
        	        echo "\t\t ";
			echo $row['owner'];
	                echo "\t\t ";
			echo $row['osID'];
                	echo '</i> ';
			Space();
		}
	}else{
	
	}
}



function DisplaySearchField($Field){
echo '	<div class="SearchField">
		<b><i>Search Results in Field: '. $Field  .'</i></b>
';



}


function Space(){
	echo '<br>';
}

?>
