<?php
$model = mysql_real_escape_string($_GET['model']);
$make  = mysql_real_escape_string($_GET['make']);

if ($model=="" && $make==""){
    echo '
	<form action="entertype.php" method="get">
	<table class="enterFormTbl">
		<tr>
			<td>Model: </td>
			<td><input type="text" name="model"></td>
		</tr>
		<tr>
			<td>Make: </td>
			<td><input type="text" name="make"></td>
		</tr>
		<tr>
			<td colspan=2><center><input type=submit value="Enter Type"></center></td>
		</tr>
	</table>
	</form>
     ';
}else{
include 'connecttodb.php';
$query = "INSERT INTO tblType (model, make) VALUES ('$model','$make')";
mysql_query($query);
echo '
<b>Your model has been entered</b>
<form action="entertype.php" method="get">
	<table class="enterFormTbl">
		<tr>
			<td>Model: </td>
			<td><input type="text" name="model"></td>
		</tr>
		<tr>
			<td>Make: </td>
			<td><input type="text" name="make"></td>
		</tr>
		<tr>
			<td colspan=2><center><input type=submit value="Enter Type"></center></td>
		</tr>
	</table>
	</form>




';
}




function CreateAndPopulateDropDown($tbl, $field){
include 'connecttodb.php';
$query = "SELECT * FROM " . $tbl;


echo '<select name="type">';
$result = mysql_query($query);
while($row = mysql_fetch_array($result)){
	echo '<option value="'.$row['typeID'].'">'.$row['model']. '--' . $row['make'] . '</option>';
}
echo '</select>';



}



?> 
