<?php

echo '<center>

<div class="menuDiv" id="menu">
[--<a href="index.php" class="menulink">Home</a>--]
[--<a href="enterserver.php" class="menulink">Enter Server</a>--]
[--<a href="updateServer.php" class="menulink">View Servers</a>--]
[--<a href="ServerStatus.php" class="menulink">Server Status </a>--]
[--<a href="Search.php" class="menulink">Search </a>--]
[--<a href="uploadTemplate.php" class="menulink">Import Data </a>--]
[--<a href="exportXwin.php?tbl=tblServers" class="menulink">Export Xwin </a>--]

</div>

<div class="menuBtn">
	<input type=submit onmouseover="showDiv(\'menu\');"  onClick="showDiv(\'menu\');" class="showHideMenuBtn" value="--menu--">
</div>

</center><br>
';




?> 
