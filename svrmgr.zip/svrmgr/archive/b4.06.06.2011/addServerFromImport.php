<?php
      
include 'connecttodb.php';
include 'headtag.php';
include 'menu.php';


$type                = $_GET['tblType'];
$os                  = $_GET['tblOS'];
$ip                  = $_GET['tblIP'];
$servName            = $_GET['serverName'];
$servAlias           = $_GET['serverAlias'];
$warDate             = $_GET['warrantyStartDate'];
$dateInService       = $_GET['dateInService'];
$newMake             = $_GET['txtMake'];
$newModel            = $_GET['txtModel'];
$newOS               = $_GET['txtOSName'];
$newIP               = $_GET['txtIPAddress'];
$serial = $_GET['serial'];
$entered = $_GET['entered'];


if ($entered == "yes"){
	addServer();
}else{
	displayForm($serial);
}















function displayForm($serial){

echo '
<br>
<br>
<div class="EnterForm">
<form action=enterserver.php class=serverForm>
<table class="enterFormTbl">
        <tr>
                <td width=150px>Select Type:</td>
                <td width=150px>';
                CreateAndPopulateDropDown("tblType", "model");
echo '          </td>';
                echo '<td><input type=button name=type value="Enter New Type" onClick="showDiv(\'EnterType\');" class="showHideBtn"></td>';
echo '          <td>    <div id="EnterType" class="formDiv">
                                Model:
                                <input type="text" name="txtModel"><br>
                                Make:
                                <input type="text" name="txtMake">
                        </div>
                </td>
        </tr>
        <tr>
                <td>Select OS:</td>
                <td>';
                CreateAndPopulateDropDown("tblOS", "osName");
echo '          </td>
                <td><input type=button name=type value="Enter New OS" onClick="showDiv(\'EnterOS\');" class="showHideBtn"></td>
                <td>
                        <div id="EnterOS" class="formDiv">
                                OS Name:
                                <input type="text" name="txtOSName">
                        </div>
                </td>
        </tr>
        <tr>
                <td>Select IP:</td>
                <td>';
                CreateAndPopulateDropDown("tblIP", "ipAddress");
echo '          </td>
                <td><input type=button name=type value="Enter New IP" onClick="showDiv(\'EnterIP\');" class="showHideBtn"></td>
                <td>
                        <div id="EnterIP" class="formDiv">
                                IP Address:
                                <input type="text" name="txtIPAddress" value="000.000.000.000">
                        </div>
                </td>
        </tr>
        <tr>
                <td>Server Name: </td>
                <td colspan=3><input type="hidden" name="entered" value="yes"><input type="text" name="serverName"></td>
        </tr>
        <tr>
                <td>Server Alias: </td>
                <td colspan=3><input type="text" name="serverAlias"></td>
        </tr>
        <tr>
                <td>Serial:</td>
                <td colspan=3><input type="text" name="serial" value="' . trim($serial, " ")  . '"></td>
        </tr>
        <tr>
                <td>Date In Service: </td>
                <td colspan=3><input type="text" name="dateInService" value="mm/dd/yyyy"></td>
        </tr>
        <tr>
                <td>Warranty Start Date:</td>
                <td colspan=3><input type="text" name="warrantyStartDate" value="mm/dd/yyyy"></td>
        </tr>
	<tr>
                <td colspan=2><center><input type=submit value="Enter Server"></center></td>
        </tr>
	

</table>
</form>
</div>
<br>
</body>
';
}



function CreateAndPopulateDropDown($tbl, $field){
include 'connecttodb.php';
$query = "SELECT * FROM " . $tbl;

echo '<select name="'. $tbl . '" class=frmSelect>';
echo '<option selected>Select From List</option>';
$result = mysql_query($query);
while($row = mysql_fetch_array($result)){
        if ($tbl == "tblType"){
                echo '<option value="'.$row['typeID'].'">'.$row['model']. '--' . $row['make'] . '</option>';
        }
        if ($tbl == "tblOS"){
                echo '<option value="'.$row['osID'].'">'.$row['osName'].'</option>';
        }
        if ($tbl == "tblIP"){
                echo '<option value="'.$row['ipID'].'">'.$row['ipAddress'].'</option>';
        }
}
echo '</select>';



}





?>
