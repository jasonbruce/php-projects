<?php
  do_command_and_echo_output("Clean Up Data", "/usr/bin/php /var/www/html/FirstMonitor/__Scripts/clean_up_tmp.php");
//  do_command_and_echo_output("Do All Events", "/usr/bin/php /var/www/html/FirstMonitor/__Scripts/doAll.php");
//  do_command_and_echo_output("HOL Report", "/usr/bin/php /var/www/html/FirstMonitor/__Scripts/hol_report.php");

 function do_command_and_echo_output($strOutPut, $cmd){
   exec($cmd);
   echo $strOutPut . ' <br><br>';

 }
?>
