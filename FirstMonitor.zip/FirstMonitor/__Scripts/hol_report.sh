


cat /dev/null > /var/www/html/FirstMonitor/rpt/hol_report.html
echo "<center><h1>HOL Daily Report</h1>" >> /var/www/html/FirstMonitor/rpt/hol_report.html
echo "<i>Last Update: " >> /var/www/html/FirstMonitor/rpt/hol_report.html
date >>  /var/www/html/FirstMonitor/rpt/hol_report.html
echo "<hr width=50%></center></i><br><br>" >> /var/www/html/FirstMonitor/rpt/hol_report.html
echo "<center><table style=\"border-collapse: collapse; border:1px solid black;\"><tr><th style=\"background-color: rgb(193,193,193);\">Facility</th><th style=\"background-color: rgb(193,193,193);\">Total</th></tr>" >> /var/www/html/FirstMonitor/rpt/hol_report.html
cat /var/www/html/FirstMonitor/tmp/37.bwsrt0-mrh.grep | wc -l | awk ' BEGIN { print "<tr><td><center>HOL-HCH Convenient Care - HCH</center></td>";}{print "<td><center>",$1,"</center></td></tr>";}END{print "";}' >>  /var/www/html/FirstMonitor/rpt/hol_report.html
cat /var/www/html/FirstMonitor/tmp/40.bwsrt0-mrh.grep | wc -l | awk ' BEGIN { print "<tr><td><center>HOL-HCH Specialty Cntrs</center></td>";}{print "<td><center>",$1,"</center></td></tr>";}END{print "";}' >>  /var/www/html/FirstMonitor/rpt/hol_report.html
cat /var/www/html/FirstMonitor/tmp/42.bwsrt0-mrh.grep | wc -l | awk ' BEGIN { print "<tr><td><center>HOL-Convenient Care - RMH</center></td>";}{print "<td><center>",$1,"</center></td></tr>";}END{print "";}' >>  /var/www/html/FirstMonitor/rpt/hol_report.html
cat /var/www/html/FirstMonitor/tmp/41.bwsrt0-mrh.grep | wc -l | awk ' BEGIN { print "<tr><td><center>HOL-Ellerbe</center></td>";}{print "<td><center>",$1,"</center></td></tr>";}END{print "";}' >>  /var/www/html/FirstMonitor/rpt/hol_report.html
cat /var/www/html/FirstMonitor/tmp/12.bwsrt0-mrh.grep | wc -l | awk ' BEGIN { print "<tr><td><center>HOL-Seven Lakes</center></td>";}{print "<td><center>",$1,"</center></td></tr>";}END{print "";}' >>  /var/www/html/FirstMonitor/rpt/hol_report.html
cat /var/www/html/FirstMonitor/tmp/35.bwsrt0-mrh.grep | wc -l | awk ' BEGIN { print "<tr><td><center>HOL-Troy</center></td>";}{print "<td><center>",$1,"</center></td></tr>";}END{print "";}' >>  /var/www/html/FirstMonitor/rpt/hol_report.html
cat /var/www/html/FirstMonitor/tmp/43.bwsrt0-mrh.grep | wc -l | awk ' BEGIN { print "<tr><td><center>HOL-FCC Candor</center></td>";}{print "<td><center>",$1,"</center></td></tr>";}END{print "";}' >>  /var/www/html/FirstMonitor/rpt/hol_report.html
echo "</table></center><br><br>" >> /var/www/html/FirstMonitor/rpt/hol_report.html

awk -F"|" ' 
   BEGIN {
           print "<center><table style=\"border-collapse: collapse; border:1px solid black;\"><tr><th style=\"background-color: rgb(193,193,193);\">Seconds</th><th style=\"background-color: rgb(193,193,193);\">Name</th><th style=\"background-color: rgb(193,193,193);\">Facility</th><th style=\"background-color: rgb(193,193,193);\">Start Date</th><th style=\"background-color: rgb(193,193,193);\">End Date</th></tr>";
         }
         {
           print "<tr><td>",$3,"</td><td>",$4,"</td><td>",substr($7,1,15),"</td><td>",$5,"</td><td>",$6,"</td></tr>";
         }
   END   {
           print "</table></center>";
         } ' /var/www/html/FirstMonitor/tmp/5.bwsrt0-mrh.grep  >> /var/www/html/FirstMonitor/rpt/hol_report.html
