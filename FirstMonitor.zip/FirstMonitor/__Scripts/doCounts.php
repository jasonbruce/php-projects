<?php
 $debug='N';

 connectToDb();
 doGreps($debug);



  function doGreps($debug){
    $qry = "SELECT tblPaths.file_name as 'file_name', tblMonitor.monitorID as 'monitorID',tblMonitor.monitor_name as 'MonitorName',
                   tblCount.countID as 'countID',tblHosts.host_name as 'host_name', tblHosts.username as 'username',tblHosts.password as 'password',
                   tblHosts.hostID as 'hostID', tblHosts.hosttypeID as 'hosttypeID', tblPaths.pathID as 'pathID',tblPaths.path as 'path'
            FROM tblMonitor 
            INNER JOIN tblCount ON tblMonitor.countID = tblCount.countID 
            INNER JOIN tblHosts ON tblMonitor.hostID = tblHosts.hostID 
            INNER JOIN tblPaths ON tblMonitor.pathID = tblPaths.pathID 
            WHERE tblMonitor.countID > '1' AND tblMonitor.active ='Y'";
    $result = mysql_query($qry);
    while($rw = mysql_fetch_array($result)){
        $osType = lookupID("tblHostTypes", "hosttypeID", $rw['hosttypeID'],"host_type_name");
        if ($osType='Windows'){
          mountWindows("/mnt/windows_machines",$rw['host_name'],$rw['path'],$rw['username'],$rw['password'],$debug); 
          doCount("/mnt/windows_machines/",$rw['path'],$rw['file_name'],$rw['host_name'],$rw['monitorID'],$debug);
          umount("/mnt/windows_machines",$debug);
        }
    }


    if ($debug=='Y'){
       echo "<hr>";
       echo $qry;
       echo "<br><hr>";
    }

  }
  function doCount($mnt,$path,$file,$hostname,$monitorID,$debug){
     $cmd ="";
         $cmd = "ls -l $mnt | grep -v total | wc -l  > /var/www/html/FirstMonitor/tmp/$monitorID.$hostname.count ";
         exec($cmd);
    if ($debug=='Y'){
       echo "<hr>";
       echo "file_found: ";
       $foundIt =  file_exists("$mnt$file");
       echo "$foundIt<br>";
       echo $cmd;
       echo "<br><hr>";
    }

  }
  function umount($umount_path, $debug){
    $cmd = "sudo umount -l $umount_path";
    exec($cmd);
    if ($debug=='Y'){
       echo "<hr>";
       echo $cmd;
       echo "<br><hr>";
    }
  }
  function mountWindows($mountTo, $hostName, $path, $userName, $password, $debug){
    $cmd = "sudo mount -t cifs //$hostName/$path $mountTo -o username=$userName,password=$password,domain=firsthealth.org";
    echo exec($cmd);
    if ($debug=='Y'){
       echo "<hr>";
       echo $cmd;
       echo "<br><hr>";
    }
  }
  function lookupID($tbl, $idColumn, $id, $valueColumn){
    $qry = "select $valueColumn from $tbl where $idColumn='$id'";
    $result = mysql_query($qry);
    while($rw = mysql_fetch_array($result)){
      return $rw[$valueColumn];
    } 
  }
  function connectToDb(){
    $database="dev-mysql-mrh";
    $dbun="webRoot";
    $dbpw="webR00t";
    mysql_connect($database, $dbun, $dbpw) or die(mysql_error());
    mysql_select_db("dbFirstMonitor");
  }




?>
