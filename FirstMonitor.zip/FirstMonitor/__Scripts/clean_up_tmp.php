<?php

  $cmd="sudo rm -rf /var/www/html/FirstMonitor/tmp/*";
  exec($cmd);
  

?>
