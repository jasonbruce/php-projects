<?php

//  $cmd = "./hol_report.sh";
//  exec($cmd);

  $report_text = "<a href='http://dev-web/FirstMonitor/rpt/hol_report.html'>Click here to view report</a>"; 
//  send_email("fhc-is-devalerts@firsthealth.org,dsmith@firsthealth.org,eforest@firsthealth.org,sbonville@firsthealth.org","!!!PHI!!! HOL - Processing Report",$report_text);
  send_email("jbruce@firsthealth.org,dwalters@firsthealth.org","!PHI! HOL - Processing Report",$report_text);

	


   function send_email($mail_to, $mail_subject, $mail_body){
       $header   = "From: FirstMonitor@dev-web-mrh.firsthealth.org\r\n";
       $header .= "MIME-Version: 1.0\r\n";
       $header .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
       mail($mail_to,$mail_subject,$mail_body,$header);
   }
?>
