<?php
 $debug='N';

 connectToDb();
 doGreps($debug);



  function doGreps($debug){
    $qry = "SELECT tblPaths.file_name as 'file_name', tblMonitor.monitorID as 'monitorID',tblMonitor.monitor_name as 'MonitorName',tblGrep.grepID as 'grepID',tblGrep.grep_statement as 'grep_statement',tblHosts.host_name as 'host_name',tblHosts.username as 'username',tblHosts.password as 'password',tblHosts.hostID as 'hostID', tblHosts.hosttypeID as 'hosttypeID', tblPaths.pathID as 'pathID',tblPaths.path as 'path' 
            FROM tblMonitor 
             INNER JOIN tblGrep  ON tblMonitor.grepID = tblGrep.grepID 
             INNER JOIN tblHosts ON tblMonitor.hostID = tblHosts.hostID 
             INNER JOIN tblPaths ON tblMonitor.pathID = tblPaths.pathID 
            WHERE tblMonitor.grepID > '1' AND tblMonitor.active ='Y'";
    $result = mysql_query($qry);
    while($rw = mysql_fetch_array($result)){
        $osType = lookupID("tblHostTypes", "hosttypeID", $rw['hosttypeID'],"host_type_name");
        if ($osType='Windows'){
          mountWindows("/mnt/windows_machines",$rw['host_name'],$rw['path'],$rw['username'],$rw['password'],$debug); 
          doGrep("/mnt/windows_machines/",$rw['path'],$rw['file_name'],$rw['grep_statement'],$rw['host_name'],$rw['monitorID'],$debug);
          umount("/mnt/windows_machines",$debug);
        }
    }


    if ($debug=='Y'){
       echo "<hr>";
       echo $qry;
       echo "<br><hr>";
    }

  }
  function doGrep($mnt,$path,$file,$grep_statement,$hostname,$monitorID,$debug){
     $cmd ="";
     if (file_exists("$mnt$file")){
         $cmd = "cat $mnt$file | $grep_statement > /var/www/html/FirstMonitor/tmp/$monitorID.$hostname.grep &";
         exec($cmd);
     } 
   
    if ($debug=='Y'){
       echo "<hr>";
       echo "file_found: ";
       $foundIt =  file_exists("$mnt$file");
       echo "$foundIt<br>";
       echo $cmd;
       echo "<br><hr>";
    }

  }
  function umount($umount_path, $debug){
    $cmd = "sudo umount -l $umount_path";
    exec($cmd);
    if ($debug=='Y'){
       echo "<hr>";
       echo $cmd;
       echo "<br><hr>";
    }
  }
  function mountWindows($mountTo, $hostName, $path, $userName, $password, $debug){
    $cmd = "sudo mount -t cifs //$hostName/$path $mountTo -o username=$userName,password=$password,domain=firsthealth.org";
    echo exec($cmd);
    if ($debug=='Y'){
       echo "<hr>";
       echo $cmd;
       echo "<br><hr>";
    }
  }
  function lookupID($tbl, $idColumn, $id, $valueColumn){
    $qry = "select $valueColumn from $tbl where $idColumn='$id'";
    $result = mysql_query($qry);
    while($rw = mysql_fetch_array($result)){
      return $rw[$valueColumn];
    } 
  }
  function connectToDb(){
    $database="dev-mysql-mrh";
    $dbun="webRoot";
    $dbpw="webR00t";
    mysql_connect($database, $dbun, $dbpw) or die(mysql_error());
    mysql_select_db("dbFirstMonitor");
  }




?>
