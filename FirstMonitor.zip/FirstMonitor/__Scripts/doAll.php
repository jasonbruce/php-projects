<?php
$cmd = "/usr/bin/php /var/www/html/FirstMonitor/__Scripts/doGreps.php > /dev/null";
    exec($cmd);
$cmd = "/usr/bin/php /var/www/html/FirstMonitor/__Scripts/doCounts.php > /dev/null";
    exec($cmd);
$cmd = "cat /dev/null > /var/spool/mail/root";
    exec($cmd);
?>
