<?php

//-----------A Fresh Start
  $cmd = "cat /dev/null > ../rpt/hol_daily_report.txt";
  exec($cmd);
  $cmd = "sudo rm -rf /tmp/12.*";
  exec($cmd);
  $cmd = "sudo rm -rf /tmp/13.*";
  exec($cmd);
  $cmd = "sudo rm -rf /tmp/4.*";
  exec($cmd);
  $cmd = "sudo rm -rf /tmp/5.*";
  exec($cmd);
?>
