<?php
 $debug='Y';
  connectToDb(); 
  buildBody();
  buildMenu();
    getExpected($debug); 
  buildEndBody();  
  
 function getExpected($debug){
    $qry="SELECT * FROM tblMonitor where expect='Y'";
     $result = mysql_query($qry);
     while($rw = mysql_fetch_array($result)){  
       $monID = $rw['monitorID']; 
       search_and_display_expected($monID);


     }
   

   if ($debug=='Y'){
     echo $qry . '<br>-------------------------------------------<br>';
   }
 }  
 
 function search_and_display_expected($monID){
   
 }




  function connectToDb(){
    $database="dev-mysql-mrh";
    $dbun="webRoot";
    $dbpw="webR00t";
    mysql_connect($database, $dbun, $dbpw) or die(mysql_error());
    mysql_select_db("dbFirstMonitor");
  }

  function buildHead(){
     echo '';
     
  }
  function buildBody(){
     echo '<div style="position: absolute; width:100%; height: 100%;">
              <div style="position: relative; width: 80%; height: 90%; left: 10%; border: 0px;">';
  }
  function buildEndBody(){
     echo '</div></div>';
     
  }
  function buildMenu(){
  //   echo '<div style="position: relative; width:100%; height: 30px; border: 1px solid black;">';
  //          echo '<a href="__Forms/enterMonitor.php">Enter New Monitor</a>';
  //   echo '</div>';
  }


?>
