<?php
 $debug='N';
  connectToDb(); 
  buildBody();
  buildMenu();
    getCounts($debug); 
  buildEndBody();  
  
  
  function getCounts($debug){
    
   echo "<h3>Folder File Counts</h3>";
    echo "<table style='border: 1px solid black; border-collapse: collapse;'>";
    echo "<tr style='border: 1px solid black;'><th style='border: 1px solid black;'>Monitor Name</th><th style='border: 1px solid black;'>Host</th><th style='border: 1px solid black;'>Path</th><th style='border: 1px solid black;'>Count</th></tr>";
    $qry = "SELECT tblPaths.file_name as 'file_name', tblMonitor.threshold as 'threshold', tblMonitor.monitorID as 'monitorID',tblMonitor.monitor_name as 'MonitorName',
                   tblCount.countID as 'countID',tblHosts.host_name as 'host_name', tblHosts.username as 'username',tblHosts.password as 'password',
                   tblHosts.hostID as 'hostID', tblHosts.hosttypeID as 'hosttypeID', tblPaths.pathID as 'pathID',tblPaths.path as 'path'
            FROM tblMonitor
            INNER JOIN tblCount ON tblMonitor.countID = tblCount.countID
            INNER JOIN tblHosts ON tblMonitor.hostID = tblHosts.hostID
            INNER JOIN tblPaths ON tblMonitor.pathID = tblPaths.pathID
            WHERE tblMonitor.countID > '1' AND tblMonitor.active ='Y'";
    $result = mysql_query($qry);
    while($rw = mysql_fetch_array($result)){
       $cnt = doCount($rw['monitorID'],$rw['host_name'],"count",$rw['threshold'],$debug); 
       if ($cnt > $rw['threshold']){
        echo '<tr style="border: 1px solid black;">';
         echo '<td style="border: 1px solid black;">' . $rw['MonitorName'] . '</td>';
         echo '<td style="border: 1px solid black;">' . $rw['host_name'] . '</td>';
         echo '<td style="border: 1px solid black;">' . $rw['path'] . '</td>';
           showCount($rw['monitorID'],$rw['host_name'],"count",$rw['threshold'],$debug);
        echo '</tr>';
       }
    }
    echo "</table>";


    if ($debug=='Y'){
       echo "<hr>";
       echo $qry;
       echo "<br><hr>";
       echo "<hr>";
       echo $cnt;
       echo "<br><hr>";
    }

  }
  function doCount($monID,$hostname,$ext,$threshold,$debug){
    $cmd = "cat ../tmp/$monID.$hostname.$ext ";
    $count =  exec($cmd);
     return $count;
  }
  function showCount($monID,$hostname,$ext,$threshold,$debug){
    $cmd = "cat ../tmp/$monID.$hostname.$ext";
    $count =  exec($cmd);
    if ($count < $threshold) {
      echo '<td style="border: 1px solid black;"><div style="background-color: #D0f5A9;"><center>' . $count . '</center></div><td>';
    }else{
      echo '<td style="border: 1px solid black;"><div style="background-color: red;"><center>' . $count . '</center></div><td>';
    }

    if ($debug=='Y'){
       echo "<hr>";
       echo $cmd;
       echo "<br><hr>";
    }
  }
  function doGrep($mnt,$path,$file,$grep_statement,$hostname,$monitorID,$debug){
     $cmd = "cat $mnt$file | $grep_statement > /var/www/html/FirstMonitor/tmp/$monitorID.$hostname.grep &";
     exec($cmd);
    if ($debug=='Y'){
       echo "<hr>";
       echo $cmd;
       echo "<br><hr>";
    }
  }
  function umount($umount_path, $debug){
    $cmd = "sudo umount $umount_path";
    exec($cmd);
    if ($debug=='Y'){
       echo "<hr>";
       echo $cmd;
       echo "<br><hr>";
    }
  }
  function mountWindows($mountTo, $hostName, $path, $userName, $password, $debug){
    $cmd = "sudo mount -t cifs //$hostName/$path $mountTo -o username=$userName,password=$password,domain=firsthealth.org";
    echo exec($cmd);
    if ($debug=='Y'){
       echo "<hr>";
       echo $cmd;
       echo "<br><hr>";
    }
  }
  function lookupID($tbl, $idColumn, $id, $valueColumn){
    $qry = "select $valueColumn from $tbl where $idColumn='$id'";
    $result = mysql_query($qry);
    while($rw = mysql_fetch_array($result)){
      return $rw[$valueColumn];
    } 
  }
  function connectToDb(){
    $database="dev-mysql-mrh";
    $dbun="webRoot";
    $dbpw="webR00t";
    mysql_connect($database, $dbun, $dbpw) or die(mysql_error());
    mysql_select_db("dbFirstMonitor");
  }

  function buildHead(){
     echo '';
     
  }
  function buildBody(){
     echo '<div style="position: absolute; width:100%; height: 100%;">
              <div style="position: relative; width: 80%; height: 90%; left: 10%; border: 0px;">';
  }
  function buildEndBody(){
     echo '</div></div>';
     
  }
  function buildMenu(){
  //   echo '<div style="position: relative; width:100%; height: 30px; border: 1px solid black;">';
  //          echo '<a href="__Forms/enterMonitor.php">Enter New Monitor</a>';
  //   echo '</div>';
  }


?>
