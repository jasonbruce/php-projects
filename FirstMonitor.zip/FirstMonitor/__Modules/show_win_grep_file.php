<?php
  $file_name = $_GET['file_name'];  
  echo "<h2>File Contents</h2>";
  echo "<h3><i>$file_name</i></h3>";
  echo "<hr>";

  $lines = file_get_contents("tmp/$file_name");
  $convert = explode("\n", $lines); //create array separate by new line

for ($i=0;$i<count($convert);$i++) 
{
    echo $convert[$i].'<br>'; //write value by index
}

?>
