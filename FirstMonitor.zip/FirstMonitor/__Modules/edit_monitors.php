<?php
 $debug='N';
  connectToDb(); 
  buildBody();
  buildMenu();
    getMonitors($debug); 
  buildEndBody();  
  
  
  function getMonitors($debug){
    
   echo "<h3>Windows Greps</h3>";
    echo "<table style='border: 1px solid black; border-collapse: collapse;'>";
    echo "<tr style='border: 1px solid black;'>
             <th style='border: 1px solid black;'>Action</th>
             <th style='border: 1px solid black;'>ID#</th>
             <th style='border: 1px solid black;'>Monitor Name</th>
             <th style='border: 1px solid black;'>Description</th>
             <th style='border: 1px solid black;'>Active</th>
             <th style='border: 1px solid black;'>Line Count</th>
             <th style='border: 1px solid black;'>Threshold</th>
             <th style='border: 1px solid black;'>Email</th>
             <th style='border: 1px solid black;'>Email To</th>
             <th style='border: 1px solid black;'>Expect</th>
          </tr>";
    $qry = "SELECT * from tblMonitor";
    $result = mysql_query($qry);
    while($rw = mysql_fetch_array($result)){
        echo "<form action=edit_monitors.php method=post>";
        echo '<tr style="border: 1px solid black;">';
         echo '<td style="border: 1px solid black;"><input type=submit value=Save></td>';
         
         echo '<td style="border: 1px solid black;">
                   <input type=hidden name=monitorID value="' . $rw['monitorID'] . '">
                   <input type=hidden name=action value="monitor_edit">
              ' . $rw['monitorID'] . '</td>';
         echo '<td style="border: 1px solid black;"><input type=text value="' . $rw['monitor_name'] . '  " name="monitor_name"  style="border: 1px solid black;"></td>';
         echo '<td style="border: 1px solid black;"><input type=text value="' . $rw['description'] . '   " name="description"   style="border: 1px solid black;"></td>';
         echo '<td style="border: 1px solid black;"><input type=text value="' . $rw['active'] . '        " name="active"        style="border: 1px solid black;width: 40px;"></td>';
         echo '<td style="border: 1px solid black;"><input type=text value="' . $rw['line_count'] . '    " name="line_count"    style="border: 1px solid black;width: 40px;"></td>';
         echo '<td style="border: 1px solid black;"><input type=text value="' . $rw['threshold'] . '     " name="threshold"     style="border: 1px solid black;width: 40px;"></td>';
         echo '<td style="border: 1px solid black;"><input type=text value="' . $rw['email'] . '         " name="email"         style="border: 1px solid black;width: 40px;"></td>';
         echo '<td style="border: 1px solid black;"><input type=text value="' . $rw['email_to'] . '      " name="email_to"      style="border: 1px solid black;"></td>';
         echo '<td style="border: 1px solid black;"><input type=text value="' . $rw['expect'] . '        " name="expect"        style="border: 1px solid black;width: 40px;"></td>';
        echo "</form></tr>";
        echo '<tr style="border: 1px solid black;"> <div style="position: absolute; right: 0px;">';
           display_grep_row($debug, $rw['grepID'], $rw['monitorID']);
        echo "</div></tr>";
    }
    echo "</table>";
    if ($debug=='Y'){
       echo "<hr>";
       echo $qry;
       echo "<br><hr>";
    }

  }
  function display_grep_row($debug, $grepID, $monitorID){
      $i = 0;
      $query = "select * from tblGrep where grepID='$grepID'";
      $rslt = mysql_query($query);
         while($row = mysql_fetch_array($rslt)){
          if ($i == 0){
           echo '<table style="border-collapse: collapse;">';
           echo "<tr style='border: 1px solid black;'>
             <th style='border: 1px solid black;'>Action</th>
             <th style='border: 1px solid black;'>ID#</th>
             <th style='border: 1px solid black;'>Grep Statement</th>
             <th style='border: 1px solid black;'>Description</th>
             <th style='border: 1px solid black;'>Active</th>
             <th style='border: 1px solid black;'>Host ID</th>
            </tr>";
          }
           echo "<form action=edit_monitors.php method=post>";
             echo '<tr style="border: 1px solid black; background-color: yellow;">';
             echo '<td style="border: 1px solid black;"><input type=submit value=Save></td>';
             echo '<td style="border: 1px solid black;">
                   <input type=hidden name=grepID value="' . $grepID . '">
                   <input type=hidden name=action value="grep_edit">
                  ' . $grepID . '</td>';
             echo '<td style="border: 1px solid black;"><input type=text value="' . $row['grep_statement'] . '  " name="grep_statement"  style="background-color: yellow;border: 1px solid black;"></td>';
             echo '<td style="border: 1px solid black;"><input type=text value="' . $row['description'] . '     " name="description"     style="background-color: yellow;border: 1px solid black;"></td>';
             echo '<td style="border: 1px solid black;"><input type=text value="' . $row['active'] . '          " name="active"          style="background-color: yellow;border: 1px solid black;width: 40px;"></td>';
             echo '<td style="border: 1px solid black;"><input type=text value="' . $row['hostID'] . '          " name="hostID"          style="background-color: yellow;border: 1px solid black;width: 40px;"></td>';
           echo "</form></tr>";
          $i = $i + 1;
         }
      echo '</table><br>';
  }
  function doCount($monID,$hostname,$ext,$threshold,$debug){
    $cmd = "cat /var/www/html/FirstMonitor/tmp/$monID.$hostname.$ext | wc -l";
    $count =  exec($cmd);
     return $count;
  }
  function showCount($monID,$hostname,$ext,$threshold,$debug){
    $cmd = "cat /var/www/html/FirstMonitor/tmp/$monID.$hostname.$ext | wc -l";
    $count =  exec($cmd);
    if ($count < $threshold) {
      echo '<td style="border: 1px solid black;"><div style="background-color: #D0f5A9;"><center>' . $count . '</center></div><td>';
    }else{
      echo '<td style="border: 1px solid black;"><div style="background-color: red;"><center>' . $count . '</center></div><td>';
    }

    if ($debug=='Y'){
       echo "<hr>";
       echo $cmd;
       echo "<br><hr>";
    }
  }
  function doGrep($mnt,$path,$file,$grep_statement,$hostname,$monitorID,$debug){
     $cmd = "cat $mnt$file | $grep_statement > /var/www/html/FirstMonitor/tmp/$monitorID.$hostname.grep &";
     exec($cmd);
    if ($debug=='Y'){
       echo "<hr>";
       echo $cmd;
       echo "<br><hr>";
    }
  }
  function umount($umount_path, $debug){
    $cmd = "sudo umount $umount_path";
    exec($cmd);
    if ($debug=='Y'){
       echo "<hr>";
       echo $cmd;
       echo "<br><hr>";
    }
  }
  function mountWindows($mountTo, $hostName, $path, $userName, $password, $debug){
    $cmd = "sudo mount -t cifs //$hostName/$path $mountTo -o username=$userName,password=$password,domain=firsthealth.org";
    echo exec($cmd);
    if ($debug=='Y'){
       echo "<hr>";
       echo $cmd;
       echo "<br><hr>";
    }
  }
  function lookupID($tbl, $idColumn, $id, $valueColumn){
    $qry = "select $valueColumn from $tbl where $idColumn='$id'";
    $result = mysql_query($qry);
    while($rw = mysql_fetch_array($result)){
      return $rw[$valueColumn];
    } 
  }
  function connectToDb(){
    $database="dev-mysql-mrh";
    $dbun="webRoot";
    $dbpw="webR00t";
    mysql_connect($database, $dbun, $dbpw) or die(mysql_error());
    mysql_select_db("dbFirstMonitor");
  }

  function buildHead(){
     echo '';
     
  }
  function buildBody(){
     echo '<div style="position: absolute; width:100%; height: 100%;">
              <div style="position: relative; width: 80%; height: 90%; left: 10%; border: 0px;">';
  }
  function buildEndBody(){
     echo '</div></div>';
     
  }
  function buildMenu(){
  //   echo '<div style="position: relative; width:100%; height: 30px; border: 1px solid black;">';
  //          echo '<a href="__Forms/enterMonitor.php">Enter New Monitor</a>';
  //   echo '</div>';
  }


?>
