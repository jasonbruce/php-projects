<?php

  $debug='Y';
  connectToDb();
  $action = $_POST['action'];

  if ($action == 'new'){
     insert_schedule();
  }
  if ($action == 'save'){
     update_schedule();
  }
  
  echo "<table>";
   echo "<tr>";
     echo "<td>";
        echo "ACTION";
     echo "</td>";
     echo "<td>";
        echo "SERVER";
     echo "</td>";
     echo "<td>";
        echo "START TIME";
     echo "</td>";
     echo "<td>";
        echo "END TIME";
     echo "</td>";
     echo "<td>";
        echo "DESCRIPTION";
     echo "</td>";
     echo "<td>";
        echo "ACTIVE";
     echo "</td>";
     echo "<td>";
     echo "</td>";
    echo "</tr>";
   




  $query = "SELECT * FROM tbl_schedules";
  $result = mysql_query($query);
  while ($row = mysql_fetch_array($result)){
   echo "<tr>";
     echo "<td>";
        echo '<form action=time_schedule.php method=post style="display: inline;">';
        echo "<input type=hidden name=action value=save>";
        $schedID = $row['scheduleID'];
        echo "<input type=hidden name=scheduleID value=$schedID>";
        echo "<input type=submit value=Save>";
     echo "</td>";
     echo "<td>";
         display_servers($row['serverID']);
     echo "</td>";
     echo "<td>";
        echo '<input type=text value="' . $row['start_time'] . '" name=start_time>';
     echo "</td>";
     echo "<td>";
        echo '<input type=text value="' . $row['end_time'] . '" name=end_time>';
     echo "</td>";
     echo "<td>";
        echo '<input type=text value="' . $row['description'] . '" name=description>';
     echo "</td>";
     echo "<td>";
        display_active($row['active']);
     echo "</td>";
     echo "<td>";
     echo "</td>";
    echo "</form></tr>";
  }
   echo '<tr style="border-top: 1px solid black;">';
     echo '<td style="border-top: 3px solid black;">';
        echo '<form action=time_schedule.php method=post style="display: inline;">';
        echo "<input type=hidden name=action value=new>";
        echo "<input type=submit value=Add>";
     echo "</td>";
     echo '<td style="border-top: 3px solid black;">';
         display_servers('');
     echo "</td>";
     echo '<td style="border-top: 3px solid black;">';
        echo '<input type=text value="0000-00-00 00:00:00" name=start_time>';
     echo "</td>";
     echo '<td style="border-top: 3px solid black;">';
        echo '<input type=text value="0000-00-00 00:00:00" name=end_time>';
     echo "</td>";
     echo '<td style="border-top: 3px solid black;">';
        echo '<input type=text value="" name=description>';
     echo "</td>";
     echo '<td style="border-top: 3px solid black;">';
        display_active('Y');
     echo "</td>";
     echo "<td>";
     echo "</td>";
    echo "</form></tr>";
  echo "</table>"; 
     function insert_schedule(){
       $sid          = $_POST['serverID'];
       $stime        = $_POST['start_time'];
       $etime        = $_POST['end_time'];
       $description  = $_POST['description'];
       $active       = $_POST['active'];
       $qry = "INSERT INTO tbl_schedules (serverID, start_time, end_time, description, active) VALUES ('$sid','$stime','$etime','$description','$active')"; 
       connectToDb();
       mysql_query($qry); 
     }
     
     function update_schedule(){
       $sid          = $_POST['serverID'];
       $schID        = $_POST['scheduleID'];
       $stime        = $_POST['start_time'];
       $etime        = $_POST['end_time'];
       $description  = $_POST['description'];
       $active       = $_POST['active'];
       $qry = "UPDATE tbl_schedules set serverID='$sid', start_time='$stime', end_time='$etime', description='$description', active='$active' where scheduleID='$schID'"; 
       connectToDb();
       mysql_query($qry); 
     }

     function display_active($active){
           echo "<select name=active>";
               if ($active == 'Y'){
                 echo "<option value='Y' selected>Y</option>";
               }else{
                 echo "<option value=Y>Y</option>";
               }
               if ($active == 'N'){
                 echo "<option value='N' selected>N</option>";
               }else{
                 echo "<option value=N>N</option>";
               }
           echo "</select>";
     }
     function display_servers($serverID){
           echo "<select name=serverID>";
           $qry='select * from tbl_servers';
           $rslt = mysql_query($qry);
           while ($rw = mysql_fetch_array($rslt)){
               $sid = $rw['server_id'];
               $sname = $rw['ip'];
               if ($sid == $serverID){
                 echo "<option value=$sid selected>$sname</option>";
               }else{
                 echo "<option value=$sid>$sname</option>";
               }
           } 
           echo "</select>";
     }



      function update_server($serverID, $value, $debug){
         connectToDb(); 
         $qry = "UPDATE tbl_servers set email='$value' where server_id='$serverID'"; 
         mysql_query($qry); 
         if ($debug='Y'){
            echo 'Query:   ' . $qry .'<br>';
          }
      }

      function connectToDb(){
          $database="dev-mysql-mrh";
          $dbun="webRoot";
          $dbpw="webR00t";
          mysql_connect($database, $dbun, $dbpw) or die(mysql_error());
          mysql_select_db("dbPHPMonitor");
      }


      function check_schedule($server_id, $debug){
          connectToDb();
          $rightNow = date("H:i");
          $qry = "SELECT * FROM tbl_schedules WHERE serverID='$server_id'";
          $rslt = mysql_query($qry);
          while($rw = mysql_fetch_array($rslt)){
               $schedStart = $rw['start_time']; 
               $schedEnd = $rw['end_time']; 
          }

          $startHour = substr($schedStart,11,2);
          $endHour = substr($schedEnd,11,2);
          $startMinute = substr($schedStart,14,2);
          $endMinture = substr($schedEnd,14,2);
          $nowHour = substr($rightNow,0,2);
          $nowMinute = substr($rightNow,3,2);

          $schedStart = mktime($startHour,$startMinute,0,0,0,0);
          $schedEnd = mktime($endHour,$endMinute,0,0,0,0);
          $rightNow = mktime($nowHour,$nowMinute,0,0,0,0);


          if ($schedStart != '' && $schedEnd != ''){
            if ($rightNow < $schedEnd AND $rightNow > $schedStart){
               $rtn = "no";
            }else{
               $rtn = "yes";
            }
             
          }
          if ($debug='Y'){
            echo 'RightNow:   ' . $rightNow .'<br>';
            echo 'SchedStart: ' . $schedStart .'<br>';
            echo 'SchedEnd:   ' . $schedEnd .'<br>';
          }
          return $rtn;
      }















?>
