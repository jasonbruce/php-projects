<?php
 $debug='N';
  connectToDb(); 
  buildHead();
  buildBody();
  buildMenu();
    getGreps($debug); 






  buildEndBody();  
  
  
  
  
  
  
  
  
  
  
  
  
  
  function getGreps($debug){
    
   echo "<div><h1>Windows Greps</h1></div>";
    echo "<table style='border: 1px solid black; border-collapse: collapse;'>";
    echo "<tr style='border: 1px solid black;'><th></th><th style='border: 1px solid black;'>Monitor Name</th><th style='border: 1px solid black;'>Host</th><th style='border: 1px solid black;'>File</th><th style='border: 1px solid black;'>Grep Command</th><th style='border: 1px solid black;'>Line Count</th></tr>";
    $qry = "SELECT tblPaths.file_name as 'file_name',tblMonitor.threshold as 'threshold', tblMonitor.line_count as 'line_count', tblMonitor.monitorID as 'monitorID',tblMonitor.monitor_name as 'MonitorName',tblGrep.grepID as 'grepID',tblGrep.grep_statement as 'grep_statement',tblHosts.host_name as 'host_name',tblHosts.username as 'username',tblHosts.password as 'password',tblHosts.hostID as 'hostID', tblHosts.hosttypeID as 'hosttypeID', tblPaths.pathID as 'pathID',tblPaths.path as 'path' 
            FROM tblMonitor 
             INNER JOIN tblGrep  ON tblMonitor.grepID = tblGrep.grepID 
             INNER JOIN tblHosts ON tblMonitor.hostID = tblHosts.hostID 
             INNER JOIN tblPaths ON tblMonitor.pathID = tblPaths.pathID 
            WHERE tblMonitor.grepID > '1' AND tblMonitor.active ='Y'";
    $result = mysql_query($qry);
    while($rw = mysql_fetch_array($result)){
       echo '<tr style="border: 1px solid black;">';
        echo '<td style="border: 1px solid black;"><a href="tmp/'.$rw['monitorID'] .'.'.$rw['host_name'] .'.grep">View</a></td>';
        echo '<td style="border: 1px solid black;">' . $rw['MonitorName'] . '</td>';
        echo '<td style="border: 1px solid black;">' . $rw['host_name'] . '</td>';
        echo '<td style="border: 1px solid black;">' . $rw['file_name'] . '</td>';
        echo '<td style="border: 1px solid black;">' . $rw['grep_statement'] . '</td>';
        if ($rw['line_count'] == 'Y'){
           doCount($rw['monitorID'],$rw['host_name'],"grep",$rw['threshold'],$debug); 
        }else{
           echo '<td style="border: 1px solid black;"><div style="background-color: #D0f5A9;"><center>NA</center></div><td>';
        }
       echo '</tr>';
    }
    echo "</table>";


    if ($debug=='Y'){
       echo "<hr>";
       echo $qry;
       echo "<br><hr>";
    }

  }
  function doCount($monID,$hostname,$ext,$threshold,$debug){
    $cmd = "cat tmp/$monID.$hostname.$ext | wc -l";
    $count =  exec($cmd);
    if ($count < $threshold) {
      echo '<td style="border: 1px solid black;"><div style="background-color: #D0f5A9;"><center>' . $count . '</center></div><td>';
    }else{
      echo '<td style="border: 1px solid black;"><div style="background-color: red;"><center>' . $count . '</center></div><td>';
    }

    if ($debug=='Y'){
       echo "<hr>";
       echo $cmd;
       echo "<br><hr>";
    }
  }
  function doGrep($mnt,$path,$file,$grep_statement,$hostname,$monitorID,$debug){
     $cmd = "cat $mnt$file | $grep_statement > /var/www/html/FirstMonitor/tmp/$monitorID.$hostname.grep &";
     exec($cmd);
    if ($debug=='Y'){
       echo "<hr>";
       echo $cmd;
       echo "<br><hr>";
    }

  }
  function umount($umount_path, $debug){
    $cmd = "sudo umount $umount_path";
    exec($cmd);
    if ($debug=='Y'){
       echo "<hr>";
       echo $cmd;
       echo "<br><hr>";
    }
  }
  function mountWindows($mountTo, $hostName, $path, $userName, $password, $debug){
    $cmd = "sudo mount -t cifs //$hostName/$path $mountTo -o username=$userName,password=$password,domain=firsthealth.org";
    echo exec($cmd);
    if ($debug=='Y'){
       echo "<hr>";
       echo $cmd;
       echo "<br><hr>";
    }
  }
  function lookupID($tbl, $idColumn, $id, $valueColumn){
    $qry = "select $valueColumn from $tbl where $idColumn='$id'";
    $result = mysql_query($qry);
    while($rw = mysql_fetch_array($result)){
      return $rw[$valueColumn];
    } 
  }
  function connectToDb(){
    $database="dev-mysql-mrh";
    $dbun="webRoot";
    $dbpw="webR00t";
    mysql_connect($database, $dbun, $dbpw) or die(mysql_error());
    mysql_select_db("dbFirstMonitor");
  }

  function buildHead(){
     echo '';
     
  }
  function buildBody(){
     echo '<div style="position: absolute; width:100%; height: 100%;">
              <div style="position: relative; width: 80%; height: 90%; left: 10%;">';

          
  }
  function buildEndBody(){
     echo '</div></div>';
     
  }
  function buildMenu(){
     echo '<div style="position: relative; width:100%; height: 30px; border: 1px solid black;">';
            echo '<a href="__Forms/enterMonitor.php">Enter New Monitor</a>';
     echo '</div>';
  }


?>
