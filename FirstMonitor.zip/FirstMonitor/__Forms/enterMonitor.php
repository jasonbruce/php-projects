<?php
 $debug='Y';

 connectToDb();
 $action = $_POST['action'];



 switch ($action) {
   case "monitor_name_submitted":
     showHostNameForm($_POST['monitor_name'], $_POST['monitor_description'],$_POST['line_count'],$_POST['threshold'],$_POST['email'],$_POST['email_to']);
     break;
   case "host_submitted":
     showPathForm($_POST['un'], $_POST['pw'], $_POST['monitor_name'], $_POST['monitor_description'],$_POST['host_name'],$_POST['hostTypeID'],$_POST['host_description'],$_POST['line_count'],$_POST['threshold'],$_POST['email'],$_POST['email_to']);
     break;
   case "path_submitted":
     showGrepForm($_POST['un'], $_POST['pw'], $_POST['monitor_name'], $_POST['monitor_description'],$_POST['host_name'],$_POST['hostTypeID'],$_POST['host_description'],$_POST['path'],$_POST['path_description'],$_POST['file_name'],$_POST['line_count'],$_POST['threshold'],$_POST['email'],$_POST['email_to']);
     break;
   case "grep_submitted":
     showSummaryForm($_POST['un'], $_POST['pw'], $_POST['monitor_name'], $_POST['monitor_description'],$_POST['host_name'],$_POST['hostTypeID'],$_POST['host_description'],$_POST['path'],$_POST['path_description'], $_POST['grep_command'],$_POST['file_name'],$_POST['line_count'],$_POST['threshold'],$_POST['email'],$_POST['email_to']);
     break;
   case "summary_submitted":
     insert_grep($_POST['un'], $_POST['pw'], $_POST['monitor_name'], $_POST['monitor_description'],$_POST['host_name'],$_POST['hostTypeID'],$_POST['host_description'],$_POST['path'],$_POST['path_description'], $_POST['grep_command'],$_POST['file_name'],$_POST['line_count'],$_POST['threshold'],$_POST['email'],$_POST['email_to']);
     break;
   default:
     showMonitorForm();
 }


 if ($debug=='y'){
   echo "<br><hr><br>";
   echo $action;
   echo "<br><hr>";
 }
   function insert_grep($username,$password,$monitor_name, $monitor_description, $host_name, $hosttypeID, $host_description, $path, $path_description,$grep_command,$file_name,$line_count,$threshold,$email,$email_to){
      $hostID='';
      $pathID='';
      $grepID='';
      $monitor_name 		= mysql_real_escape_string($monitor_name);
      $monitor_description 	= mysql_real_escape_string($monitor_description);
      $host_name 		= mysql_real_escape_string($host_name);
      $hosttypeID	 	= mysql_real_escape_string($hosttypeID);
      $host_description 	= mysql_real_escape_string($host_description);
      $path 			= mysql_real_escape_string($path);
      $path_description 	= mysql_real_escape_string($path_description);
      $grep_command 		= mysql_real_escape_string($grep_command);
      $password                 = $password;
      $file_name 		= mysql_real_escape_string($file_name);



      $qry = "INSERT INTO tblHosts (host_name, description,hosttypeID,active,username,password) VALUES ('$host_name','$host_description','$hosttypeID','Y','$username','$password')";
        mysql_query($qry);
        $hostID = mysql_insert_id();
      $qry = "INSERT INTO tblPaths (path,description,hostID,active,file_name) VALUES ('$path','$path_description','$hostID','Y','$file_name')";
        mysql_query($qry);
        $pathID = mysql_insert_id();
      $qry = "INSERT INTO tblGrep (grep_statement,pathID,hostID,description,active) VALUES ('$grep_command','$pathID','$hostID','','Y')";
        mysql_query($qry);
        $grepID = mysql_insert_id();
      $qry = "INSERT INTO tblMonitor (monitor_name,description,active,grepID,pathID,hostID,line_count,threshold,email,email_to) VALUES ('$monitor_name','$monitor_description','Y','$grepID','$pathID','$hostID','$line_count','$threshold','$email','$email_to')";
        mysql_query($qry);
       echo '<br><hr><b>Count Monitor has been entered!</b>';
   }
   function showSummaryForm($username,$password,$monitor_name, $monitor_description, $host_name, $hosttypeID, $host_description, $path, $path_description,$grep_command, $file_name,$line_count,$threshold,$email,$email_to){
    echo "<br><form action=enterMonitor.php method=post>";
       echo "<table>";
       echo "<tr>";
       echo "<td><label>Monitor Name:</label></td><td>$monitor_name</td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Host Name:</label></td><td>$host_name</td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Path:</label></td><td>$path</td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>File:</label></td><td>$file_name</td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Grep:</label></td><td>$grep_command</td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><input type=submit value=Next></td>";
       echo "</tr>";
       echo "</table>";
       echo "<input type=hidden name=action 			value=summary_submitted>";
       echo '<input type=hidden name=monitor_name 		value="'. $monitor_name .'">';
       echo '<input type=hidden name=monitor_description 	value="'. $monitor_description .'">';
       echo '<input type=hidden name=un 			value="'. $username .'">';
       echo '<input type=hidden name=pw 			value="'. $password .'">';
       echo '<input type=hidden name=host_name 			value="'. $host_name .'">';
       echo '<input type=hidden name=hosttypeID 		value="'. $hosttypeID .'">';
       echo '<input type=hidden name=host_description 		value="'. $host_description .'">';
       echo '<input type=hidden name=path 			value="'. $path .'">';
       echo '<input type=hidden name=path_description 		value="'. $path_description .'">';
       echo '<input type=hidden name=grep_command 		value="'. $grep_command .'">';
       echo '<input type=hidden name=file_name 			value="'. $file_name .'">';
       echo '<input type=hidden name=line_count			value="'. $line_count .'">';
       echo '<input type=hidden name=threshold 			value="'. $threshold .'">';
       echo '<input type=hidden name=email 			value="'. $email .'">';
       echo '<input type=hidden name=email_to 			value="'. $email_to .'">';
    echo "</form>";
  }


  function showGrepForm($username,$password,$monitor_name, $monitor_description, $host_name, $hosttypeID, $host_description, $path, $path_description,$file_name,$line_count,$threshold,$email,$email_to){
    echo "<br><form action=enterMonitor.php method=post>";
       echo "<table>";
       echo "<tr>";
       echo "<td><label>Monitor Name:</label></td><td>$monitor_name</td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Host Name:</label></td><td>$host_name</td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Path:</label></td><td>$path</td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Grep Command:</label></td><td><input type=text name=grep_command></td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><input type=submit value=Next></td>";
       echo "</tr>";
       echo "</table>";
       echo "<input type=hidden name=action 			value=grep_submitted>";
       echo '<input type=hidden name=monitor_name               value="'. $monitor_name .'">';
       echo '<input type=hidden name=monitor_description        value="'. $monitor_description .'">';
       echo '<input type=hidden name=un                         value="'. $username .'">';
       echo '<input type=hidden name=pw                         value="'. $password .'">';
       echo '<input type=hidden name=host_name                  value="'. $host_name .'">';
       echo '<input type=hidden name=hosttypeID                 value="'. $hosttypeID .'">';
       echo '<input type=hidden name=host_description           value="'. $host_description .'">';
       echo '<input type=hidden name=path                       value="'. $path .'">';
       echo '<input type=hidden name=path_description           value="'. $path_description .'">';    
       echo '<input type=hidden name=file_name                  value="'. $file_name .'">';
       echo '<input type=hidden name=line_count                 value="'. $line_count .'">';
       echo '<input type=hidden name=threshold                  value="'. $threshold .'">';
       echo '<input type=hidden name=email                      value="'. $email .'">';
       echo '<input type=hidden name=email_to                   value="'. $email_to .'">';

    echo "</form>";
  }
  function showPathForm($username,$password,$monitor_name, $monitor_description, $host_name, $hosttypeID, $host_description,$line_count,$threshold,$email,$email_to){
    echo "<br><form action=enterMonitor.php method=post>";
       echo "<table>";
       echo "<tr>";
       echo "<td><label>Monitor Name:</label></td><td>$monitor_name</td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Host Name:</label></td><td>$host_name</td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Path:</label></td><td>";
            show_drop_down("tblPaths","path","pathID","path");
       echo "</td></tr>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>File:</label></td><td><input type=text name=file_name></td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Description:</label></td><td><textarea name=path_description></textarea></td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><input type=submit value=Next></td>";
       echo "</tr>";
       echo "</table>";
       echo "<input type=hidden name=action value=path_submitted>";
       echo '<input type=hidden name=monitor_name               value="'. $monitor_name .'">';
       echo '<input type=hidden name=monitor_description        value="'. $monitor_description .'">';
       echo '<input type=hidden name=un                         value="'. $username .'">';
       echo '<input type=hidden name=pw                         value="'. $password .'">';
       echo '<input type=hidden name=host_name                  value="'. $host_name .'">';
       echo '<input type=hidden name=hosttypeID                 value="'. $hosttypeID .'">';
       echo '<input type=hidden name=host_description           value="'. $host_description .'">';
       echo '<input type=hidden name=line_count                 value="'. $line_count .'">';
       echo '<input type=hidden name=threshold                  value="'. $threshold .'">';
       echo '<input type=hidden name=email                      value="'. $email .'">';
       echo '<input type=hidden name=email_to                   value="'. $email_to .'">';
    echo "</form>";
  }
  function show_drop_down($tbl,$display_value,$id_value,$ddName){
    $qry = "SELECT * from $tbl";
    $result = mysql_query($qry);
    echo "<select name='$ddName'>";
    while($rw = mysql_fetch_array($result)){
        $disp = $rw[$display_value];
        $val  = $rw[$id_value]; 
       echo "<option value=$val>$disp</option>";
    }
    echo "</select>";
  }
  function showHostNameForm($monitor_name, $monitor_description,$line_count,$threshold,$email,$email_to){
    echo "<br><form action=enterMonitor.php method=post>";
       echo "<table>";
       echo "<tr>";
       echo "<td><label>Monitor Name:</label></td><td>$monitor_name</td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Host Name:</label></td><td>";
            show_drop_down("tblHosts","host_name","hostID","host_name");
       echo "</td></tr>";
       echo "<tr>";
       echo "<td><label>User Name:</label></td><td><input type=text name=un></td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Password:</label></td><td><input type=password name=pw></td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Description:</label></td><td><textarea name=host_description></textarea></td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Host OS Type:</label></td><td>";
            buildDropDown("tblHostTypes","hostTypeID","","WINDOWS","host_type_name","hosttypeID");
       echo "</td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><input type=submit value=Next></td>";
       echo "</tr>";
       echo "</table>";
       echo "<input type=hidden name=action value=host_submitted>";
       echo '<input type=hidden name=monitor_name               value="'. $monitor_name .'">';
       echo '<input type=hidden name=monitor_description        value="'. $monitor_description .'">';
       echo '<input type=hidden name=line_count                 value="'. $line_count .'">';
       echo '<input type=hidden name=threshold                  value="'. $threshold .'">';
       echo '<input type=hidden name=email                      value="'. $email .'">';
       echo '<input type=hidden name=email_to                   value="'. $email_to .'">';
    echo "</form>";
  }

  function showMonitorForm(){
    echo "<br><form action=enterMonitor.php method=post>";
       echo "<table>";
       echo "<tr>";
       echo "<td><label>Monitor Name:</label></td><td><input type=text name=monitor_name></td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Count Lines:</label></td><td><select name=line_count><option>Y</option><option>N</option></select></td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Alert Threshold #:</label></td><td><input type=text name=threshold></td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Email Alerts:</label></td><td><select name=email><option>Y</option><option>N</option></select></td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Email To:</label></td><td><input type=text name=email_to value=@firsthealth.org></td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><label>Description:</label></td><td><textarea name=monitor_description></textarea></td>";
       echo "</tr>";
       echo "<tr>";
       echo "<td><input type=submit value=Next></td>";
       echo "</tr>";
       echo "</table>";
       echo "<input type=hidden name=action value=monitor_name_submitted>";
    echo "</form>";
  }

  






  function buildDropDown($tbl, $ddName, $ddClass, $selected, $display_column, $value_column){
   $qry = "select * from $tbl";
   echo '<select name="' . $ddName .'" class="' . $ddClass . '">';
   $result = mysql_query($qry);
    while($rw = mysql_fetch_array($result)){
      if ($rw[$display_column] == $selected || $rw[$value_column] == $selected){
        echo '<option value=' . $rw[$value_column] . ' selected>' . $rw[$display_column] . '</option>';
      }else{
        echo '<option value=' . $rw[$value_column] . '>' . $rw[$display_column] . '</option>';
      }
    }
   echo '</select>';
  }
  function connectToDb(){
    $database="dev-mysql-mrh";
    $dbun="webRoot";
    $dbpw="webR00t";
    mysql_connect($database, $dbun, $dbpw) or die(mysql_error());
    mysql_select_db("dbFirstMonitor");
  }








?>
