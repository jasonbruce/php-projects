<?php
/**
 * PHP Server Monitor
 * Monitor your servers and websites.
 *
 * This file is part of PHP Server Monitor.
 * PHP Server Monitor is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * PHP Server Monitor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with PHP Server Monitor.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @package     phpservermon
 * @author      Klemens Häckel <http://clickdimension.wordpress.com/>
 * @copyright   Copyright (c) 2008-2014 Pepijn Over <pep@neanderthal-technology.com>
 * @license     http://www.gnu.org/licenses/gpl.txt GNU GPL v3
 * @version     Release: v3.0.1
 * @link        http://www.phpservermonitor.org/
 **/

$sm_lang = array(
	'name' => 'Español - Spanish',
	'locale' => array('es_ES.UTF-8', 'es_ES', 'spanish', 'esp'),
	'system' => array(
		'title' => 'Server Monitor',
		'install' => 'Install',
		'action' => 'Acción',
		'save' => 'Guardar',
		'edit' => 'Modificar',
		'delete' => 'Eliminar',
		'deleted' => 'Registro eliminado',
		'date' => 'Fecha',
		'message' => 'Mensaje',
		'yes' => 'Si',
		'no' => 'No',
		'edit' => 'Modificar',
		'insert' => 'Insertar',
		'add_new' => 'Agregar nuevo',
		'update_available' => 'Hay una nueva versión ({version}) disponible en <a href="http://www.phpservermonitor.org" target="_blank">http://www.phpservermonitor.org</a>.',
		'back_to_top' => 'Back to top',
		'go_back' => 'Go back',
		// date/time format according the strftime php function format parameter http://php.net/manual/function.strftime.php
		'short_day_format' => '%B %e',
		'long_day_format' => '%B %e, %Y',
		'yesterday_format' => 'Yesterday at %k:%M',
		'other_day_format' => '%A at %k:%M',
		'never' => 'Never',
		'hours_ago' => '%d hours ago',
		'an_hour_ago' => 'about an hour ago',
		'minutes_ago' => '%d minutes ago',
		'a_minute_ago' => 'about a minute ago',
		'seconds_ago' => '%d seconds ago',
		'a_second_ago' => 'a second ago',
	),
	'menu' => array(
		'config' => 'Configurar',
		'server' => 'Servidores',
		'server_log' => 'Log',
		'server_status' => 'Status',
		'server_update' => 'Actualizar',
		'user' => 'Usuarios',
		'help' => 'Ayuda',
	),
	'users' => array(
		'user' => 'Usuario',
		'name' => 'Nombre',
		'user_name' => 'Username',
		'password' => 'Password',
		'password_repeat' => 'Password repeat',
		'password_leave_blank' => 'Leave blank to keep unchanged',
		'level' => 'Level',
		'level_10' => 'Administrator',
		'level_20' => 'User',
		'level_description' => '<b>Administrators</b> have full access: they can manage servers, users and edit the global configuration.<br/><b>Users</b> can only view and run the updater for the servers that have been assigned to them.',
		'mobile' => 'Mobil',
		'email' => 'Email',
		'updated' => 'Usuario actualizado.',
		'inserted' => 'Usuario ingresado.',
		'profile' => 'Profile',
		'profile_updated' => 'Your profile has been updated.',
		'error_user_name_bad_length' => 'Usernames must be between 2 and 64 characters.',
		'error_user_name_invalid' => 'The username may only contain alphabetic characters (a-z, A-Z), digits (0-9) and underscores (_).',
		'error_user_name_exists' => 'The given username already exists in the database.',
		'error_user_email_bad_length' => 'Email addresses must be between 5 and 255 characters.',
		'error_user_email_invalid' => 'The email address is invalid.',
		'error_user_level_invalid' => 'The given user level is invalid.',
		'error_user_no_match' => 'The user could not be found in the database.',
		'error_user_password_invalid' => 'The entered password is invalid.',
		'error_user_password_no_match' => 'The entered passwords do not match.',
	),
	'log' => array(
		'title' => 'Registro Log',
		'type' => 'Tipo',
		'status' => 'Estado',
		'email' => 'Email',
		'sms' => 'SMS',
	),
	'servers' => array(
		'server' => 'Servidores',
		'label' => 'Titulo',
		'domain' => 'Domain/IP',
		'port' => 'Port',
		'type' => 'Tipo',
		'type_website' => 'Website',
		'type_service' => 'Service',
		'pattern' => 'Search string/pattern',
		'pattern_description' => 'If this pattern is not found on the website, the server will be marked offline. Regular expressions are allowed.',
		'last_check' => 'Ultima verificación',
		'last_online' => 'Última vez en línea',
		'monitoring' => 'Monitoreo',
		'send_email' => 'Email',
		'send_sms' => 'SMS',
		'updated' => 'Servidor arctualizado.',
		'inserted' => 'Servidor ingresado.',
		'latency' => 'Tiempo de respuesta',
		'latency_max' => 'Tiempo de respuesta (maximum)',
		'latency_min' => 'Tiempo de respuesta (minimum)',
		'latency_avg' => 'Tiempo de respuesta (average)',
		'year' => 'Year',
		'month' => 'Month',
		'week' => 'Week',
		'day' => 'Day',
		'hour' => 'Hour',
		'warning_threshold' => 'Warning threshold',
		'warning_threshold_description' => 'Number of failed checks required before it is marked offline.',
		'chart_last_week' => 'Last week',
		'chart_history' => 'History',
		// Charts date format according jqPlot date format  http://www.jqplot.com/docs/files/plugins/jqplot-dateAxisRenderer-js.html
		'chart_day_format' => '%Y-%m-%d',
		'chart_long_date_format' => '%Y-%m-%d %H:%M:%S',
		'chart_short_date_format' => '%m/%d %H:%M',
		'chart_short_time_format' => '%H:%M',
	),
	'config' => array(
		'general' => 'General',
		'language' => 'Idioma',
		'show_update' => 'Comprobar actualizaciones semanalmente ?',
		'email_status' => 'Habilitar envio de email ?',
		'email_from_email' => 'Email desde dirección',
		'email_from_name' => 'Email desde nombre',
		'email_smtp' => 'Enable SMTP',
		'email_smtp_host' => 'SMTP host',
		'email_smtp_port' => 'SMTP port',
		'email_smtp_username' => 'SMTP username',
		'email_smtp_password' => 'SMTP password',
		'email_smtp_noauth' => 'Leave blank for no authentication',
		'sms_status' => 'Habilitar envio de SMS ?',
		'sms_gateway' => 'SMS Gateway',
		'sms_gateway_mosms' => 'Mosms',
		'sms_gateway_mollie' => 'Mollie',
		'sms_gateway_spryng' => 'Spryng',
		'sms_gateway_inetworx' => 'Inetworx',
		'sms_gateway_clickatell' => 'Clickatell',
        'sms_gateway_textmarketer' => 'Textmarketer',
		'sms_gateway_username' => 'Gateway username',
		'sms_gateway_password' => 'Gateway password',
		'sms_from' => 'Número origen del SMS',
		'alert_type' => 'Cuando desea recibir notificaciones ?<br/>',
        'alert_type_description' => '<b>...  Al cambiar el estado:</b> '.
		    'p.ej. online -> offline o offline -> online.<br/>'.
		    '<br /><b>Offline:</b> '.
		    'Recibirá una notificación cuando el servidor va fuera de línea.'.
		    'Se envia un sólo mensaje cuando el CronJob detecta la caída por primera vez.<br/>'.
		    '<br><b>Siempre:</b> '.
		    'Se le enviará una notificación, cada vez que se ejecuta el script o el CronJob, '.
		    'aunqué el servicio puede haber estado fuera de línea por varias horas antes.',
		'alert_type_status' => 'Cambio de estado',
		'alert_type_offline' => 'Offline',
		'alert_type_always' => 'Siempre',
		'log_status' => 'Log status',
		'log_status_description' => 'Al setear TRUE (marcar) se protocolan todos los estados.',
		'log_email' => 'Enviar Log via email?',
		'log_sms' => 'Enviar Log via SMS ?',
		'updated' => 'Configuración guardada.',
		'tab_email' => 'Email',
		'tab_sms' => 'SMS',
		'tab_log' => 'Log',
		'settings_email' => 'Email',
		'settings_sms' => 'Mensaje SMS',
		'settings_notification' => 'Notificación',
		'settings_log' => 'Log',
		'auto_refresh' => 'Refrescar automáticamente página de servidores',
		'auto_refresh_servers' =>
			'Refrescar automáticamente página de servidores.<br/>'.
			'<span class="small">'.
			'Tiempo en segundos, indicar "0" para no actualizar.'.
			'</span>',
		'seconds' => 'seconds',
	),
	// for newlines in the email messages use <br/>
	'notifications' => array(
		'off_sms' => 'Servidor \'%LABEL%\' está fuera de línea: ip=%IP%, port=%PORT%. error=%ERROR%',
		'off_email_subject' => 'Importante: Servidor \'%LABEL%\' está fuera de línea',
		'off_email_body' => "No posible conectar al servidor:<br/><br/>Servidor: %LABEL%<br/>IP: %IP%<br/>Port: %PORT%<br/>Error: %ERROR%<br/>Fecha: %DATE%",
		'on_sms' => 'Servidor \'%LABEL%\' ya está de nuevo funcionando en línea: ip=%IP%, port=%PORT%',
		'on_email_subject' => 'Importante: Servidor \'%LABEL%\' ya está de nuevo en línea',
		'on_email_body' => "Servidor '%LABEL%' ya está funcionando en línea de nuevo:<br/><br/>Servidor: %LABEL%<br/>IP: %IP%<br/>Port: %PORT%<br/>Fecha: %DATE%",
	),
	'login' => array(
		'welcome_usermenu' => 'Welcome, %user_name%',
		'title_sign_in' => 'Please sign in',
		'title_forgot' => 'Forgot your password?',
		'title_reset' => 'Reset your password',
		'submit' => 'Submit',
		'remember_me' => 'Remember me',
		'login' => 'Login',
		'logout' => 'Logout',
		'username' => 'Username',
		'password' => 'Password',
		'password_repeat' => 'Repeat password',
		'password_forgot' => 'Forgot password?',
		'password_reset' => 'Reset password',
		'password_reset_email_subject' => 'Reset your password for PHP Server Monitor',
		'password_reset_email_body' => 'Please use the following link to reset your password. Please note it expires in 1 hour.<br/><br/>%link%',
		'error_user_incorrect' => 'The provided username could not be found.',
		'error_login_incorrect' => 'The information is incorrect.',
		'error_login_passwords_nomatch' => 'The provided passwords do not match.',
		'error_reset_invalid_link' => 'The reset link you provided is invalid.',
		'success_password_forgot' => 'An email has been sent to you with information how to reset your password.',
		'success_password_reset' => 'Your password has been reset successfully. Please login.',
	),
);
