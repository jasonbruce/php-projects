<?php
define('PSM_DB_HOST', 'dev-mysql-mrh');
define('PSM_DB_NAME', 'dbHCIMonitor');
define('PSM_DB_USER', 'webRoot');
define('PSM_DB_PASS', 'webR00t');
define('PSM_DB_PREFIX', 'tbl_');
?>
