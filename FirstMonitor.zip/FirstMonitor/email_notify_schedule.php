<?php

 $debug='N';
  connectToDb();
  $query = "SELECT * FROM tbl_schedules where active='Y'";
  $result = mysql_query($query);
  while ($row = mysql_fetch_array($result)){
    $server_ID = $row['serverID'];
    $email_option = check_schedule($server_ID, $debug);
    update_server($server_ID, $email_option, $debug);
    echo "<br>Email Option: $email_option";
  }
  
      function update_server($serverID, $value, $debug){
         connectToDb(); 
         $qry = "UPDATE tbl_servers set email='$value' where server_id='$serverID'"; 
         mysql_query($qry); 
         if ($debug='Y'){
            echo 'Query:   ' . $qry .'<br>';
          }
      }

      function connectToDb(){
          $database="dev-mysql-mrh";
          $dbun="webRoot";
          $dbpw="webR00t";
          mysql_connect($database, $dbun, $dbpw) or die(mysql_error());
          mysql_select_db("dbPHPMonitor");
      }


      function check_schedule($server_id, $debug){
          connectToDb();
          $rightNow = date("H:i");
          $qry = "SELECT * FROM tbl_schedules WHERE serverID='$server_id'";
          $rslt = mysql_query($qry);
          while($rw = mysql_fetch_array($rslt)){
               $schedStart = $rw['start_time']; 
               $schedEnd = $rw['end_time']; 
          }

          $startHour = substr($schedStart,11,2);
          $endHour = substr($schedEnd,11,2);
          $startMinute = substr($schedStart,14,2);
          $endMinture = substr($schedEnd,14,2);
          $nowHour = substr($rightNow,0,2);
          $nowMinute = substr($rightNow,3,2);

          $schedStart = mktime($startHour,$startMinute,0,0,0,0);
          $schedEnd = mktime($endHour,$endMinute,0,0,0,0);
          $rightNow = mktime($nowHour,$nowMinute,0,0,0,0);


          if ($schedStart != '' && $schedEnd != ''){
            if ($rightNow < $schedEnd AND $rightNow > $schedStart){
               $rtn = "no";
            }else{
               $rtn = "yes";
            }
             
          }
          if ($debug='Y'){
            echo 'RightNow:   ' . $rightNow .'<br>';
            echo 'SchedStart: ' . $schedStart .'<br>';
            echo 'SchedEnd:   ' . $schedEnd .'<br>';
          }
          return $rtn;
      }















?>
