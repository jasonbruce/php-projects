<?php










 

  function grep_logs(){
      $i = 0;
      $qry = "select * from tblGreps where active='Y'";
      $result = mysql_query($qry);
        while ($row = mysql_fetch_array($result)){
          
        }

  }
  function count_files(){


  }




  function connectToDb(){
    $database="dev-mysql-mrh";
    $dbun="webRoot";
    $dbpw="webR00t";
    mysql_connect($database, $dbun, $dbpw) or die(mysql_error());
    mysql_select_db("dbFirstMonitor");
  }
?>
