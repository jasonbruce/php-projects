<?php    


   echo $_SESSION['FirstMerge-username'][0];











$rtn = authenticate("jbruce", "River123");
echo $rtn;
echo '<br>';
echo $_SESSION['user'];
echo '<br>------------<bR>';

function authenticate($user, $password) {
    // Active Directory server
    $ldap_host = "dc1-mrh.firsthealth.org";
 
    // Active Directory DN
    $ldap_dn = "CN=Ontap\, Development,OU=Development,OU=Information Systems,OU=MRH,DC=firsthealth,DC=org";
 
    // Active Directory user group
    $ldap_user_group = "Users";
 
    // Active Directory manager group
    $ldap_manager_group = "WebManagers";
 
    // Domain, for purposes of constructing $user
    $ldap_usr_dom = "@firsthealth.org";
 
    // connect to active directory
    $ldap = ldap_connect($ldap_host);
 
    // verify user and password
    if($bind = @ldap_bind($ldap, $user . $ldap_usr_dom, $password)) {
        // valid
        // check presence in groups
        $filter = "(sAMAccountName=" . $user . ")";
        $attr = array("memberof");
        echo $ldap_dn . '<br>';
        $result = ldap_search($ldap, $ldap_dn, $filter, $attr) or exit("Unable to search LDAP server");
        $entries = ldap_get_entries($ldap, $result);
        $rst = ldap_unbind($ldap);
        echo $rst . '<br>';
 
        // check groups
        foreach($entries[0]['memberof'] as $grps) {
            // is manager, break loop
            if (strpos($grps, $ldap_manager_group)) { $access = 2; break; }
            // is user
            if (strpos($grps, $ldap_user_group)) $access = 1;
        }
 
        if ($access != 0) {
            // establish session variables
            $_SESSION['user'] = $user;
            $_SESSION['access'] = $access;
            return true;
        } else {
            // user has no rights
            return false;
        }
 
    } else {
        echo "err-here";
        // invalid name or password
        return false;
    }
}
?>
