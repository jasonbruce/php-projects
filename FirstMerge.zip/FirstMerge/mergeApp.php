<?php
  headTag();
  session_start();
  $action     = $_POST['action'];
  $cqmFile    = $_FILES["cqm_file"]["name"];
  $wellFile   = $_FILES["wellsoft_file"]["name"];
  $mtFile     = $_FILES["medstracker_file"]["name"];
  $picisFile  = $_FILES["picis_file"]["name"];
  $facility   = $_POST['facility'];
  connectToDb();
  date_default_timezone_set('America/New_York'); 
  show_menu($action,$cqmFile,$wellFile,$picisFile,$facility,$mtFile);

  switch ($action) {
     case "":
       build_select_facility_form();
       break;
     case "facility_selected":
	build_input_form_cqm();
//        log_text("Facility Selected");
        break;
     case "cqm_submitted":
        upload_files_cqm();
        build_input_form_wellsoft();
//        log_text("cqm uploaded");
        break;
     case "wellsoft_submitted":
        upload_files_wellsoft();
        build_input_form_medstracker();
//        log_text("wellsoft uploaded");
        break;
     case "medstracker_submitted":
        upload_files_medstracker();
        if ($facility == 'MRH' || $facility == 'HCH'){
        	build_input_form_picis();
        }else{
          build_select_facility_form();
        }
//        log_text("medstracker uploaded");
        break;
     case "picis_submitted":
        upload_files_picis();
        build_select_facility_form();
//        log_text("picis uploaded");
        break;
     case "clear_log":
        clear_log();
        build_select_facility_form();
        break;
     case "do_merge":
        if ($facility == '') { $facility = $_SESSION['FirstMerge-facility']; }
        log_text($facility);
        do_merge($facility);
        build_select_facility_form();
        break;
     case "do_export":
        export_data();
        build_select_facility_form();
        break;
     case "merge_and_export":
        merge_and_export($facility);
        build_select_facility_form();
	break;
     case "validate_merge":
        validate_merge();
	break;
     case "clean_up_output_folder":
       clean_up_output_folder();
       build_select_facility_form();
       break;
  }
  echo '</body></html>';






// -----------------------------------------------------------------------
// ---------------------FUNCTIONS-----------------------------------------
// ---------------------FUNCTIONS-----------------------------------------
// -----------------------------------------------------------------------
  function do_merge($facility){
    //------------------  delete legancy data if it exists
    delete_table("CQM");
    delete_table("WELLSOFT");
    delete_table("MEDSTRACKER");
    delete_table("PICIS");
    delete_table("RECORD1");
    log_text("Deleted Tables");
    //------------------  create tables
    create_table("CQM");
    create_table("WELLSOFT");
    create_table("MEDSTRACKER");
    create_table("PICIS");
    create_table("RECORD1");
    log_text("Created Tables");
    //------------------   upload files
    parse_files();
    //------------------   Run Merge Queries
    record_one_logic();
    merge_record_field("45", "CQM", "WELLSOFT", "1");
    log_text("Updated RT 5 F45 from CQM into Wellsoft table");
    merge_record_type('5', 'WELLSOFT');
    log_text("Updated Record type 5  from Wellsoft");
//    merge_record_type('4', 'MEDSTRACKER');
//    		log_text("Updated Record type 4 from Medstracker");
//    merge_record_type('7', 'MEDSTRACKER');
//    		log_text("Updated Record type 7 from Medstracker");
    merge_record_field("9", "WELLSOFT", "CQM", "1");
    log_text("Updated Record 9 from Wellsoft");
    merge_record_field("11", "WELLSOFT", "CQM", "1");
    log_text("Updated Record 11 from Wellsoft");
    merge_record_field("13", "WELLSOFT", "CQM", "1");
    log_text("Updated Record 13 from Wellsoft");
    merge_record_field("14", "WELLSOFT", "CQM", "1");
    log_text("Updated Record 14 from Wellsoft");
    if ($facility == "MRH" || $facility == "HCH"){
      add_picis_data();
      merge_record_type('13', 'PICIS');
      log_text("PICIS data updated");
    }
   log_text("!!MERGE COMPLETED!!");
  }

  function headTag(){
    echo '
         <html>
         <head>
           <link rel="stylesheet" type="text/css" href="FirstMerge.css" media="all">
           <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />  
           <script src="http://code.jquery.com/jquery-1.9.1.js"></script>  
           <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>  
           <link rel="stylesheet" href="/resources/demos/style.css" />
         </head>
         <body>
    ';

  }
  function validate_merge(){
   echo "<br><div class='div_form_merge'>";
     show_action_buttons();
     show_ws_data_RT1();
     show_ws_data_RT5();
   echo '<br><br><hr width="50%"><br></div>'; 
  }
  function show_ws_data_RT5(){
   echo '<br><center>RT5 - Field 45<br><br> <table class="validation_tbl">';
      echo '<tr>';
        echo '<th>CQM F1</th>';
        echo '<th>WS F1</th>';
        echo '<th>CQM F2</th>';
        echo '<th>WS F2</th>';
        echo '<th>CQM F45</th>';
        echo '<th>WS F45</th>';
      echo '</tr>';
    $query = "select CQM.Field1 as 'cqm f1', WELLSOFT.Field1  as 'ws f1', CQM.Field2 as 'cqm f2', WELLSOFT.Field2  as 'ws f2', CQM.Field45 as 'cqm f45',  WELLSOFT.Field45  as 'ws f45' from CQM inner JOIN WELLSOFT ON CQM.Field1 = WELLSOFT.Field1 where (CQM.Field2='5' AND WELLSOFT.Field2='5') order by CQM.Field1 desc LIMIT 0, 500";
    $result = mysql_query($query);
    while ($row = mysql_fetch_array($result)){
      echo '<tr>';

        echo '<td>' . $row['cqm f1']  . '</td>';
        echo '<td>' . $row['ws f1']   . '</td>';
        echo '<td>' . $row['cqm f2']  . '</td>';
        echo '<td>' . $row['ws f2']   . '</td>';
        $color = "";
        if ($row['cqm f45'] != $row['ws f45']){
           $color = '#EE82EE';
        } else {
           $color = '#98FB98';
        }
        echo '<td style="background-color: ' . $color . '">' . $row['cqm f45']  . '</td>';
        echo '<td style="background-color: ' . $color . '">' . $row['ws f45']   . '</td>';
      echo '</tr>';
   }
   echo '</table></center>';
  }

  function show_ws_data_RT1(){
   echo '<br><center>RT1 - Fields 9,11,13,14,23 <br><br> <table class="validation_tbl">';    
      echo '<tr>';
        echo '<th>CQM F1</th>';
        echo '<th>WS F1</th>';
        echo '<th>CQM F2</th>';
        echo '<th>WS F2</th>';
        echo '<th>CQM F9</th>';
        echo '<th>WS F9</th>';
        echo '<th>CQM F11</th>';
        echo '<th>WS F11</th>';
        echo '<th>CQM F13</th>';
        echo '<th>WS F13</th>';
        echo '<th>CQM F14</th>';
        echo '<th>WS F14</th>';
        echo '<th>CQM F23</th>';
        echo '<th>WS F23</th>';
      echo '</tr>';
    $query = "select CQM.Field1 as 'cqm f1', WELLSOFT.Field1  as 'ws f1', CQM.Field2 as 'cqm f2', WELLSOFT.Field2  as 'ws f2', CQM.Field9 as 'cqm f9',  WELLSOFT.Field9  as 'ws f9', CQM.Field11 as 'cqm f11', WELLSOFT.Field11  as 'ws f11', CQM.Field13 as 'cqm f13', WELLSOFT.Field13  as 'ws f13', CQM.Field14 as 'cqm f14', WELLSOFT.Field14  as 'ws f14', CQM.Field23 as 'cqm f23', WELLSOFT.Field23  as 'ws f23'  from CQM inner JOIN WELLSOFT ON CQM.Field1 = WELLSOFT.Field1 where (CQM.Field2='1' AND WELLSOFT.Field2='1') order by CQM.Field1 desc LIMIT 0, 500";
    $result = mysql_query($query);
    while ($row = mysql_fetch_array($result)){
      echo '<tr>';

        echo '<td>' . $row['cqm f1']  . '</td>';
        echo '<td>' . $row['ws f1']   . '</td>';
        echo '<td>' . $row['cqm f2']  . '</td>';
        echo '<td>' . $row['ws f2']   . '</td>';
        $color = "";
        if ($row['cqm f9'] != $row['ws f9']){
           $color = '#EE82EE'; 
        } else {
           $color = '#98FB98'; 
        }
        echo '<td style="background-color: ' . $color . '">' . $row['cqm f9']  . '</td>';
        echo '<td style="background-color: ' . $color . '">' . $row['ws f9']   . '</td>';
        $color = "";
        if ($row['cqm f11'] != $row['ws f11']){
           $color = '#EE82EE';
        } else {
           $color = '#98FB98';
        }
        echo '<td style="background-color: ' . $color . '">' . $row['cqm f11'] . '</td>';
        echo '<td style="background-color: ' . $color . '">' . $row['ws f11']  . '</td>';
        $color = "";
        if ($row['cqm f13'] != $row['ws f13']){
           $color = '#EE82EE';
        } else {
           $color = '#98FB98';
        }
        echo '<td style="background-color: ' . $color . '">' . $row['cqm f13'] . '</td>';
        echo '<td style="background-color: ' . $color . '">' . $row['ws f13']  . '</td>';
        $color = "";
        if ($row['cqm f14'] != $row['ws f14']){
           $color = '#EE82EE';
        } else {
           $color = '#98FB98';
        }
        echo '<td style="background-color: ' . $color . '">' . $row['cqm f14'] . '</td>';
        echo '<td style="background-color: ' . $color . '">' . $row['ws f14']  . '</td>';
        $color = "";
        if ($row['cqm f23'] != $row['ws f23']){
           $color = '#EE82EE';
        } else {
           $color = '#98FB98';
        }
        echo '<td style="background-color: ' . $color . '">' . $row['cqm f23'] . '</td>';
        echo '<td style="background-color: ' . $color . '">' . $row['ws f23']  . '</td>';
        $color = "";

      echo '</tr>';
    } 
    echo '</table></center>';
  }

function merge_and_export(){
     do_merge($facility);
     export_data();
  }
  function clean_up_output_folder(){
    $path = "output_file/*.sorted.txt";
    exec("rm $path");
    $path = "../uploads/cqm.txt";
    exec("rm $path");
    $path = "../uploads/picis.txt";
    exec("rm $path");
    $path = "../uploads/medstracker.txt";
    exec("rm $path");
    $path = "../uploads/wellsoft.txt";
    exec("rm $path");
  }  
  function show_menu($action,$cqmFile,$wellFile,$picisFile,$facility,$medstrackerFile){
     echo "<div class='menuDiv'><br><b>ACTION:</b> $action<BR>";
     if ($facility != '') {
      $_SESSION['FirstMerge-facility'] = $facility;
      echo '<b>FACILITY:</b> ' . $facility . ' <br>';
     } else {
      $facility = $_SESSION['fIRStMerge-facility'];
      echo '<b>FACILITY:</b> ' . $facility . ' <br>';
     }
     if ($cqmFile != '') {
      $_SESSION['FirstMerge-cqmFile'] = $cqmFile;
      echo '<b>CQM FILE:</b> ' . $cqmFile . ' <br>';
     } else {
      $cqmFile = $_SESSION['FirstMerge-cqmFile'];
      echo '<b>CQM FILE:</b> ' . $cqmFile . ' <br>';
     }
     if ($wellFile != '') {
      $_SESSION['FirstMerge-wellFile'] = $wellFile;
      echo '<b>WELLSOFT:</b> ' . $wellFile . ' <br>';
     } else {
      $wellFile = $_SESSION['FirstMerge-wellFile'];
      echo '<b>WELLSOFT:</b> ' . $wellFile . ' <br>';
     }
     if ($picisFile != '') {
      $_SESSION['FirstMerge-picisFile'] = $picisFile;
      echo '<b>PICIS FILE:</b> ' . $picisFile . ' <br>';
     } else {
      $picisFile = $_SESSION['FirstMerge-picisFile'];
      echo '<b>PICIS FILE:</b> ' . $picisFile . ' <br>';
     }
     if ($medstrackerFile != '') {
      $_SESSION['FirstMerge-medstrackerFile'] = $medstrackerFile;
      echo '<b>MEDSTRACKER FILE:</b> ' . $medstrackerFile . ' <br>';
     } else {
      $medstrackerFile = $_SESSION['FirstMerge-medstrackerFile'];
      echo '<b>MEDSTRACKER FILE:</b> ' . $medstrackerFile . ' <br>';
     }
   echo '</div>';
  }
  function show_action_buttons(){

    echo '<div id="progressbar_container" class="progressbar_container"><div id="progressbar" class="pbar"></div></div>';
    echo '<div class="div_action"><center><table class="tbl_nav">';
     echo '<tr><td>';
         show_start_over_form();
     echo '</td>';
     echo '<td>';
         show_do_merge_form();
     echo '</td>';
     echo '<td>';
         show_do_export_form();
     echo '</td>';
     echo '<td>';
         show_merge_and_export_form();
     echo '</td>';
     echo '<td>';
         show_validate_merge_form();
     echo '</td>';
     echo '<td>';
         show_clear_log_form();
     echo '</td>';
     echo '<td>';
         show_clean_up_folder_form();
     echo '</td></tr>';
   echo '</table></center>
            <script>
             $("form").submit(function(event){
               $("#progressbar_container").css("display", "block");
               $(function() {
                  $( "#progressbar" ).progressbar({
                    value: false
                  });
               });
            });
           </script>
    </div>';
  }
  function show_merge_and_export_form(){
   echo '<form action=mergeApp.php method=post><input type=hidden name=action value="merge_and_export"><input type=submit class=btn value="Merge & Export"></form>';
  }
  function show_start_over_form(){
   echo '<form action=mergeApp.php method=post><input type=hidden name=action value=""><input type=submit class=btn value="Start Over"></form>';
  }
  function show_clear_log_form(){
   echo '<form action=mergeApp.php method=post><input type=hidden name=action value=clear_log><input type=submit class=btn value="Clear Log"></form>';
  }
  function show_clean_up_folder_form(){
   echo '<form action=mergeApp.php method=post><input type=hidden name=action value=clean_up_output_folder><input type=submit class=btn value="Clean Files"></form>';
  }
  function show_do_merge_form(){
   echo '<form action=mergeApp.php method=post><input type=hidden name=action value=do_merge><input type=submit class=btn value="Merge Files"></form>';
  }
  function show_do_export_form(){
   echo '<form action=mergeApp.php method=post><input type=hidden name=action value=do_export><input type=submit class=btn value="Export File"></form>';
  }
  function show_validate_merge_form(){
   echo '<form action=mergeApp.php method=post><input type=hidden name=action value=validate_merge><input type=submit class=btn id="sub" value="Validate Merge"></form>';
  }
  function export_data1(){
   $query = "select * INTO OUTFILE '/var/www/html/FirstMerge/output_file/test.txt' FIELDS ESCAPED BY '\t' LINES TERMINATED BY '\r\n' from CQM";
   log_text($query);
   mysql_query($query) or die(mysql_error());
  }
  function export_data(){
   $facility = $_SESSION['FirstMerge-facility'];
   $query = "SELECT COUNT(Field1) as count from CQM";
   $result = mysql_query($query);
    while ($row = mysql_fetch_array($result)){
      $count = $row['count'];
    }
   $i = 1;
   log_text($i);

   $query = "SELECT * from CQM";
   $fileData = '';
   $result = mysql_query($query);
    while ($row = mysql_fetch_array($result)){
        $i = $i +1;
        update_log($i . ' - ' . $count . '--' . $row['Field1']);

		$Field1=$row['Field1'];
		$Field2=$row['Field2'];
		$Field3=$row['Field3'];
		$Field4=$row['Field4'];
		$Field5=$row['Field5'];
		$Field6=$row['Field6'];
		$Field7=$row['Field7'];
		$Field8=$row['Field8'];
		$Field9=$row['Field9'];
		$Field10=$row['Field10'];
		$Field11=$row['Field11'];
		$Field12=$row['Field12'];
		$Field13=$row['Field13'];
		$Field14=$row['Field14'];
		$Field15=$row['Field15'];
		$Field16=$row['Field16'];
		$Field17=$row['Field17'];
		$Field18=$row['Field18'];
		$Field19=$row['Field19'];
		$Field20=$row['Field20'];
		$Field21=$row['Field21'];
		$Field22=$row['Field22'];
		$Field23=$row['Field23'];
		$Field24=$row['Field24'];
		$Field25=$row['Field25'];
		$Field26=$row['Field26'];
		$Field27=$row['Field27'];
		$Field28=$row['Field28'];
		$Field29=$row['Field29'];
		$Field30=$row['Field30'];
		$Field31=$row['Field31'];
		$Field32=$row['Field32'];
		$Field33=$row['Field33'];
		$Field34=$row['Field34'];
		$Field35=$row['Field35'];
		$Field36=$row['Field36'];
		$Field37=$row['Field37'];
		$Field38=$row['Field38'];
		$Field39=$row['Field39'];
		$Field40=$row['Field40'];
		$Field41=$row['Field41'];
		$Field42=$row['Field42'];
		$Field43=$row['Field43'];
		$Field44=$row['Field44'];
		$Field45=$row['Field45'];
		$Field46=$row['Field46'];
		$Field47=$row['Field47'];
		$Field48=$row['Field48'];
		$Field49=$row['Field49'];
		$Field50=$row['Field50'];
		$Field51=$row['Field51'];
		$Field52=$row['Field52'];
		$Field53=$row['Field53'];
		$Field54=$row['Field54'];
		$Field55=$row['Field55'];
		$Field56=$row['Field56'];
		$Field57=$row['Field57'];
		$Field58=$row['Field58'];
		$Field59=$row['Field59'];
		$Field60=$row['Field60'];
		$Field61=$row['Field61'];
		$Field62=$row['Field62'];
		$Field63=$row['Field63'];
		$Field64=$row['Field64'];
		$Field65=$row['Field65'];
		$Field66=$row['Field66'];
		$Field67=$row['Field67'];
		$Field68=$row['Field68'];
		$Field69=$row['Field69'];
		$Field70=$row['Field70'];
		$Field71=$row['Field71'];
		$Field72=$row['Field72'];
		$Field73=$row['Field73'];
		$Field74=$row['Field74'];
		$Field75=$row['Field75'];

		$fileData .= "$Field1\t";
		$fileData .= "$Field2\t";
		$fileData .= "$Field3\t";
		$fileData .= "$Field4\t";
		$fileData .= "$Field5\t";
		$fileData .= "$Field6\t";
		$fileData .= "$Field7\t";
		$fileData .= "$Field8\t";
		$fileData .= "$Field9\t";
		$fileData .= "$Field10\t";
		$fileData .= "$Field11\t";
		$fileData .= "$Field12\t";
		$fileData .= "$Field13\t";
		$fileData .= "$Field14\t";
		$fileData .= "$Field15\t";
		$fileData .= "$Field16\t";
		$fileData .= "$Field17\t";
		$fileData .= "$Field18\t";
		$fileData .= "$Field19\t";
		$fileData .= "$Field20\t";
		$fileData .= "$Field21\t";
		$fileData .= "$Field22\t";
		$fileData .= "$Field23\t";
		$fileData .= "$Field24\t";
		$fileData .= "$Field25\t";
		$fileData .= "$Field26\t";
		$fileData .= "$Field27\t";
		$fileData .= "$Field28\t";
		$fileData .= "$Field29\t";
		$fileData .= "$Field30\t";
		$fileData .= "$Field31\t";
		$fileData .= "$Field32\t";
		$fileData .= "$Field33\t";
		$fileData .= "$Field34\t";
		$fileData .= "$Field35\t";
		$fileData .= "$Field36\t";
		$fileData .= "$Field37\t";
		$fileData .= "$Field38\t";
		$fileData .= "$Field39\t";
		$fileData .= "$Field40\t";
		$fileData .= "$Field41\t";
		$fileData .= "$Field42\t";
		$fileData .= "$Field43\t";
		$fileData .= "$Field44\t";
		$fileData .= "$Field45\t";
		$fileData .= "$Field46\t";
		$fileData .= "$Field47\t";
		$fileData .= "$Field48\t";
		$fileData .= "$Field49\t";
		$fileData .= "$Field50\t";
		$fileData .= "$Field51\t";
		$fileData .= "$Field52\t";
		$fileData .= "$Field53\t";
		$fileData .= "$Field54\t";
		$fileData .= "$Field55\t";
		$fileData .= "$Field56\t";
		$fileData .= "$Field57\t";
		$fileData .= "$Field58\t";
		$fileData .= "$Field59\t";
		$fileData .= "$Field60\t";
		$fileData .= "$Field61\t";
		$fileData .= "$Field62\t";
		$fileData .= "$Field63\t";
		$fileData .= "$Field64\t";
		$fileData .= "$Field65\t";
		$fileData .= "$Field66\t";
		$fileData .= "$Field67\t";
		$fileData .= "$Field68\t";
		$fileData .= "$Field69\t";
		$fileData .= "$Field70\t";
		$fileData .= "$Field71\t";
		$fileData .= "$Field72\t";
		$fileData .= "$Field73\t";
		$fileData .= "$Field74\t";
		$fileData .= "$Field75i\r\n";
    }
  create_output($fileData, "$facility.txt");   
  }
  function check_form(){
    $RET = "true";
    return $RET;
  }
  function add_picis_data(){
    $strFields = "Field1 ";
    for ($i=2; $i<=75; $i++){
      $strFields = $strFields .  ', Field' . $i . ' ';
    }
    $query = "SELECT distinct(Field1) from CQM";
    $result = mysql_query($query);
    while ($row = mysql_fetch_array($result)){
      $fld1 = $row['Field1'];
      $qry = "INSERT INTO CQM ($strFields) SELECT $strFields FROM PICIS where Field1 = '$fld1'";
      mysql_query($qry) or die(mysql_error());
    }
    
  }
  function record_one_logic(){
    $query = "SELECT Field1 from CQM where Field2='1'";
    $result = mysql_query($query);
      while($row = mysql_fetch_array($result)){
        $field1 = $row['Field1'];
        $qry = "insert into RECORD1 (Field1) values ('$field1')";
        mysql_query($qry);
      }
    log_text("Put record 1 data into record 1 table");    
    $query = "DELETE from CQM where Field1 not in (SELECT Field1 from RECORD1)";    
    mysql_query($query);
    log_text("Removed records without a record 1");
  }
  function merge_record_field($fieldNumber, $fromTbl, $toTbl, $joinField){
    $query = "SELECT count(distinct(Field1)) as count  from $fromTbl where Field2='1'";
    $result = mysql_query($query);
    while($row = mysql_fetch_array($result)){
       $count = $row['count'];
    }
    $query = "SELECT distinct(Field1) from CQM where Field2='1'";
    $result = mysql_query($query);
    $i = 1;
    log_text("Updating Field: $fieldNumber");
    log_text($i . '-' . $count);
    while($row = mysql_fetch_array($result)){
        $fld1 = $row['Field1'];
        $qy = "SELECT Field1, Field$fieldNumber FROM $fromTbl where Field1='$fld1' and Field2='1'";
        $rs = mysql_query($qy);
        while($rw = mysql_fetch_array($rs)){
          $strValue = $rw['Field' . $fieldNumber];
          $strField1Value = $rw['Field1'];
           if ($strValue != ''){
               if ($fieldNumber == '45'){
                 $query = "UPDATE WELLSOFT set Field45 = '$strValue' where Field1 = '$strField1Value' and Field2 = '5'";
               }else{
                 $query = "UPDATE CQM set Field$fieldNumber = '$strValue' where Field1 = '$strField1Value' AND Field2 = '1'";
               } 
             $i = $i + 1;
             update_log($i . ' - ' . $count . '--' .  $strField1Value . ' ' . $strValue);
             mysql_query($query);
           }
        }
    }
             $i=$i -1;
             update_log($i . ' - ' . $count . '--' .  $strField1Value . ' ' . $strValue);
  }
  function legacy____merge_record_field($fieldNumber, $fromTbl, $toTbl, $joinField){
    $query = "SELECT count(distinct(Field1)) as count  from $fromTbl where Field2='1'";
    $result = mysql_query($query);
    while($row = mysql_fetch_array($result)){
       $count = $row['count'];
    }
    $query = "SELECT distinct(Field1), Field$fieldNumber from $fromTbl where Field2='1'";
    $result = mysql_query($query);
    $i = 1;
    log_text("Updating Field: $fieldNumber");
    log_text($i . '-' . $count);
    while($row = mysql_fetch_array($result)){
        $strValue = $row['Field' . $fieldNumber];
        $strField1Value = $row['Field1'];
        if ($strValue != ''){
	   $query = "UPDATE CQM set Field$fieldNumber = '$strValue' where Field1 = '$strField1Value' AND Field2 = '1'";
           $i = $i + 1;
           update_log($i . ' - ' . $count . '--' .  $strField1Value . ' ' . $strValue);
           mysql_query($query);
        }
    }
  }
  function merge_record_type($record_type, $frmTable){

    $i = 1;
    log_text("Updating CQM Table with Record type: $record_type");
    log_text("$i");

    $strFields = "Field1 ";
    for ($i=2; $i<=75; $i++){
      $strFields = $strFields .  ', Field' . $i . ' ';
    }
    $query = "SELECT distinct(Field1) from CQM";
    $result = mysql_query($query);
    while ($row = mysql_fetch_array($result)){
      $fld1 = $row['Field1'];
      $qry = "select * from $frmTable where Field1='$fld1' and Field2='$record_type'";
      $rs = mysql_query($qry) or die(mysql_error());
      while ($rw = mysql_fetch_array($rs)){
           if ($rw['Field1'] != ''){
                update_log($i);
                $i = $i + 1;
                $Field1=$rw['Field1'];
                $Field2=$rw['Field2'];
                $Field3=$rw['Field3'];
                $Field4=$rw['Field4'];
                $Field5=$rw['Field5'];
                $Field6=$rw['Field6'];
                $Field7=$rw['Field7'];
                $Field8=$rw['Field8'];
                $Field9=$rw['Field9'];
                $Field10=$rw['Field10'];
                $Field11=$rw['Field11'];
                $Field12=$rw['Field12'];
                $Field13=$rw['Field13'];
                $Field14=$rw['Field14'];
                $Field15=$rw['Field15'];
                $Field16=$rw['Field16'];
                $Field17=$rw['Field17'];
                $Field18=$rw['Field18'];
                $Field19=$rw['Field19'];
                $Field20=$rw['Field20'];
                $Field21=$rw['Field21'];
                $Field22=$rw['Field22'];
                $Field23=$rw['Field23'];
                $Field24=$rw['Field24'];
                $Field25=$rw['Field25'];
                $Field26=$rw['Field26'];
                $Field27=$rw['Field27'];
                $Field28=$rw['Field28'];
                $Field29=$rw['Field29'];
                $Field30=$rw['Field30'];
                $Field31=$rw['Field31'];
                $Field32=$rw['Field32'];
                $Field33=$rw['Field33'];
                $Field34=$rw['Field34'];
                $Field35=$rw['Field35'];
                $Field36=$rw['Field36'];
                $Field37=$rw['Field37'];
                $Field38=$rw['Field38'];
                $Field39=$rw['Field39'];
                $Field40=$rw['Field40'];
                $Field41=$rw['Field41'];
                $Field42=$rw['Field42'];
                $Field43=$rw['Field43'];
                $Field44=$rw['Field44'];
                $Field45=$rw['Field45'];
                $Field46=$rw['Field46'];
                $Field47=$rw['Field47'];
                $Field48=$rw['Field48'];
                $Field49=$rw['Field49'];
                $Field50=$rw['Field50'];
                $Field51=$rw['Field51'];
                $Field52=$rw['Field52'];
                $Field53=$rw['Field53'];
                $Field54=$rw['Field54'];
                $Field55=$rw['Field55'];
                $Field56=$rw['Field56'];
                $Field57=$rw['Field57'];
                $Field58=$rw['Field58'];
                $Field59=$rw['Field59'];
                $Field60=$rw['Field60'];
                $Field61=$rw['Field61'];
                $Field62=$rw['Field62'];
                $Field63=$rw['Field63'];
                $Field64=$rw['Field64'];
                $Field65=$rw['Field65'];
                $Field66=$rw['Field66'];
                $Field67=$rw['Field67'];
                $Field68=$rw['Field68'];
                $Field69=$rw['Field69'];
                $Field70=$rw['Field70'];
                $Field71=$rw['Field71'];
                $Field72=$rw['Field72'];
                $Field73=$rw['Field73'];
                $Field74=$rw['Field74'];
                $Field75=$rw['Field75']; 

                $qy = "INSERT INTO CQM ($strFields) VALUES ('$Field1','$Field2','$Field3','$Field4','$Field5','$Field6','$Field7','$Field8','$Field9','$Field10','$Field11','$Field12','$Field13','$Field14','$Field15','$Field16','$Field17','$Field18','$Field19','$Field20','$Field21','$Field22','$Field23','$Field24','$Field25','$Field26','$Field27','$Field28','$Field29','$Field30','$Field31','$Field32','$Field33','$Field34','$Field35','$Field36','$Field37','$Field38','$Field39','$Field40','$Field41','$Field42','$Field43','$Field44','$Field45','$Field46','$Field47','$Field48','$Field49','$Field50','$Field51','$Field52','$Field53','$Field54','$Field55','$Field56','$Field57','$Field58','$Field59','$Field60','$Field61','$Field62','$Field63','$Field64','$Field65','$Field66','$Field67','$Field68','$Field69','$Field70','$Field71','$Field72','$Field73','$Field74','$Field75')";
                mysql_query($qy);
            }
      }
    }

  }
  function update_log($str){
     $command = "head -n -1 logs/thelog.txt > logs/tmp.txt";
     exec($command);
     $command = "mv logs/tmp.txt logs/thelog.txt";
     exec($command);
     log_text($str);
  }
  function parse_files(){
     $CQM         = "../uploads/cqm.txt";
     $PICIS       = "../uploads/picis.txt";
     $WELLSOFT    = "../uploads/wellsoft.txt";
     $MEDSTRACKER = "../uploads/medstracker.txt";
     $facility    = $_SESSION['FirstMerge-facility'];
     parseFile("CQM", $CQM);
     log_text("CQM Imported into the CQM table");
     parseFile("WELLSOFT", $WELLSOFT);
     log_text("Wellsoft Imported into wellsoft table");
     parseFile("MEDSTRACKER", $MEDSTRACKER);
     log_text("Medstracker Imported into medstracker table");
     if ($facility == 'MRH' || $facility == 'HCH'){
      parseFile("PICIS", $PICIS);
      log_text("PICIS Imported into picis table");
     }
     
  }
  function parseFile($tblName, $file){
    //------------------------------------------------------
    //---- the picis file has random characters in the file, to handle this we clear them out below
    //------------------------------------------------------
    if ($tblName=='PICIS'){
       $command = "/var/www/html/FirstMerge/bin/removeChars ../uploads/picis.txt ../uploads/picis_tmp.txt";
       exec($command); 
       $command = "mv ../uploads/picis_tmp.txt ../uploads/picis.txt";
       exec($command); 
       log_text("removed special characters from picis file");
    }
    
    
    $file_name = "../uploads/$file";
    $handle = fopen($file_name, "r");
    $lines = explode("\n", fread($handle, filesize($file_name)));
    fclose($handle);
    foreach ($lines as $line){
      $data = explode("\t", $line);
         insert_into_tbl($tblName, $data);
    }
  }
  function insert_into_tbl($tbl, $fields){
    $strFields = "Field1 ";
    for ($i=2; $i<=75; $i++){
      $strFields = $strFields .  ', Field' . $i . ' ';
    }
    if ($tbl == 'WELLSOFT') { 
         $strValues = substr($fields[0], 0, 10); 
    }else{
      if ($tbl == 'PICIS'){
         $strValues = substr($fields[0], -10);
      }else{
         $strValues = "'$fields[0]'";  
      }
    }
    for ($i=1; $i<=74; $i++){
      $tempVal = mysql_real_escape_string($fields[$i]);
      $strValues = "$strValues, '$tempVal'";
    }
    $strValues = $strValues;
    $query = "INSERT INTO $tbl ($strFields) VALUES ($strValues) ";
    mysql_query($query); 
  }
  function upload_files_cqm(){
     $CQM      = $_FILES["cqm_file"]["name"]; 
     upload_file('cqm_file', $CQM, "cqm.txt");
  }
  function upload_files_wellsoft(){
     $wellsoft      = $_FILES["wellsoft_file"]["name"];
     upload_file('wellsoft_file', $wellsoft, "wellsoft.txt");
  }
  function upload_files_picis(){
     $picis      = $_FILES["picis_file"]["name"];
     upload_file('picis_file', $picis, "picis.txt");
  }
  function upload_files_medstracker(){
     $medstracker  = $_FILES["medstracker_file"]["name"];
     upload_file('medstracker_file', $medstracker, "medstracker.txt");
  }

  function upload_file($inputName, $file, $completeName){
    $fileName = $_FILES[$inputName]["name"];
    move_uploaded_file($_FILES[$inputName]["tmp_name"],"../uploads/" . $completeName);
    log_text($completeName . ' has been uploaded');
  }
  function build_select_facility_form(){
   echo "<br><div class='div_form'>";
   show_action_buttons();
   echo "<div class='div_form_content'><div class='div_header'>Select Facility</div><form action=mergeApp.php method=post>";
   echo "<input type=hidden name=action value=facility_selected>";
   echo "<table>";
      echo "<tr>";
      echo "<td><label>Select Facility</label></td>
        <td>
          <select name=facility size=4  onchange='this.form.submit()'>
          <option>MRH</option>
          <option>MMH</option>
          <option>RMH</option>
          <option>HCH</option>
          </select>
        </td>";
      echo "</tr>";
   echo "</table>";
   echo "</form>";
    echo "</div></div>";
  }
  function build_input_form_cqm(){
    $facility = $_POST['facility'];
   echo "<br><div class='div_form'>";
   show_action_buttons();
    echo "<div class='div_form_content'><div class='div_header'>Select CQM File</div><form action=mergeApp.php method=post enctype='multipart/form-data'>";
    echo "<input type=hidden name=action value='cqm_submitted'>";
    echo "<input type=hidden name=facility value='$facility'>";
    echo "<table>";
        echo "<tr>";
           echo "<td><label>CQM</label></td>
                 <td><input type=file name='cqm_file' multiple></td>";
        echo "</tr>";
        echo "<tr>";
          echo "<td></td>";
          echo "<td><input type=submit class=btn value='Upload'></td>";
        echo "</tr>";
    echo "</table>";
    echo "</form>";
    echo "</div></div>";
  }
  function build_input_form_medstracker(){
    $facility = $_POST['facility'];
   echo "<br><div class='div_form'>";
   show_action_buttons();
    echo "<div class='div_form_content'><div class='div_header'>Select MedsTracker File</div><form action=mergeApp.php method=post enctype='multipart/form-data'>";
    echo "<input type=hidden name=action value='medstracker_submitted'>";
    echo "<input type=hidden name=facility value='$facility'>";
    echo "<table>";
        echo "<tr>";
           echo "<td><label>MedsTracker</label></td>
                 <td><input type=file name='medstracker_file' multiple></td>";
        echo "</tr>";
        echo "<tr>";
          echo "<td></td>";
          echo "<td><input type=submit class=btn value='Upload'></td>";
        echo "</tr>";
    echo "</table>";
    echo "</form>";
    echo "</div></div>";
  }
  function build_input_form_wellsoft(){
    $facility = $_POST['facility'];
   echo "<br><div class='div_form'>";
   show_action_buttons();
    echo "<div class='div_form_content'><div class='div_header'>Select Wellsoft File</div><form action=mergeApp.php method=post enctype='multipart/form-data'>";
    echo "<input type=hidden name=action value='wellsoft_submitted'>";
    echo "<input type=hidden name=facility value='$facility'>";
    echo "<table>";
        echo "<tr>";
           echo "<td><label>Wellsoft</label></td>
                 <td><input type=file name='wellsoft_file' multiple></td>";
        echo "</tr>";
        echo "<tr>";
          echo "<td></td>";
          echo "<td><input type=submit class=btn value='Upload'></td>";
        echo "</tr>";
    echo "</table>";
    echo "</form>";
    echo "</div></div>";
  }
  function build_input_form_picis(){
   $facility = $_POST['facility'];
   echo "<br><div class='div_form'>";
   show_action_buttons();
    echo "<div class='div_form_content'><div class='div_header'>Select Picis File</div><form action=mergeApp.php method=post enctype='multipart/form-data'>";
    echo "<input type=hidden name=action value='picis_submitted'>";
    echo "<input type=hidden name=facility value='$facility'>";
    echo "<table>";
        echo "<tr>";
           echo "<td><label>Picis</label></td>
                 <td><input type=file name='picis_file' multiple></td>";
        echo "</tr>";
        echo "<tr>";
          echo "<td></td>";
          echo "<td><input type=submit class=btn value='Upload'></td>";
        echo "</tr>";
    echo "</table>";
    echo "</form>";
    echo "</div></div>";
  }
  function connectToDb(){
    $database="dev-mysql-mrh";
    $dbun="webRoot";
    $dbpw="webR00t";
    mysql_connect($database, $dbun, $dbpw) or die(mysql_error());
    mysql_select_db("dbFirstMerge");
  }
  function delete_table($tblName){
    $query = "DROP TABLE IF EXISTS $tblName";
    mysql_query($query) or die(mysql_error());    
//    log_text($query);
  }
  function create_table($tblName){
    $strFields = "Field1 text";
    for ($i=2; $i<=75; $i++){
      $strFields = $strFields .  ', Field' . $i . ' text';
    }
    $query = "CREATE TABLE $tblName ( $strFields )";
    mysql_query($query) or die(mysql_error());
 //   log_text($tblName . ' has been created');
  }
  function clear_log(){
    $file = "logs/thelog.txt";
    exec("cat /dev/null > $file");
  }
  function log_text($txtToLog){
    $file = "logs/thelog.txt";
    $formatted_date = date("m.d.y H:i:s");
    $txt  = "$formatted_date | $txtToLog\r";
    exec("echo '$txt' >> $file");
  }
  function create_output($dataToWrite, $fileName){
    $formatted_date = date("mdyHis");
    $fileName = 'output_file/' . $formatted_date . '_' . $fileName;
    file_put_contents($fileName, $dataToWrite);
    exec("sort -k1,1 -nk2,2 $fileName > $fileName.sorted.txt");
    exec("rm -rf $fileName");
    $fileName = "$fileName.sorted.txt";
    log_text("<a href='$fileName'>$fileName</a>");
  }

?>
