<?php
$handle = @fopen("logs/thelog.txt", "r");
if ($handle) {
    while (($buffer = fgets($handle, 4096)) !== false) {
        echo "<font color=white>$buffer</font>";
                echo '<br>';
    }
    if (!feof($handle)) {
        echo "Error: unexpected fail";
    }
    fclose($handle);
}
?>

